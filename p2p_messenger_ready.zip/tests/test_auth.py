"""Юнит-тесты для auth.py — регистрация и вход по нику/паролю."""

import sys
import tempfile
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from p2p_messenger import auth as auth_module
from p2p_messenger.auth import AccountStore, AuthError
from p2p_messenger.config import Config


class TestAccountStore(unittest.TestCase):
    def setUp(self):
        self._tmp = tempfile.TemporaryDirectory()
        self._orig_config = auth_module.CONFIG
        auth_module.CONFIG = Config(data_dir=Path(self._tmp.name))
        self.store = AccountStore()

    def tearDown(self):
        auth_module.CONFIG = self._orig_config
        self._tmp.cleanup()

    def test_register_and_login(self):
        self.store.register("Neo", "wakeupneo123", tcp_port=5100)
        account = self.store.verify("Neo", "wakeupneo123")
        self.assertEqual(account.nickname, "Neo")

    def test_login_is_case_insensitive_for_nickname(self):
        self.store.register("Trinity", "redpill123", tcp_port=5100)
        account = self.store.verify("trinity", "redpill123")
        self.assertEqual(account.nickname, "Trinity")

    def test_wrong_password_rejected(self):
        self.store.register("Morpheus", "thereisnospoon", tcp_port=5100)
        with self.assertRaises(AuthError):
            self.store.verify("Morpheus", "wrongpass")

    def test_duplicate_nickname_rejected(self):
        self.store.register("Smith", "agentagent", tcp_port=5100)
        with self.assertRaises(AuthError):
            self.store.register("smith", "anotherpass", tcp_port=5101)

    def test_short_password_rejected(self):
        with self.assertRaises(AuthError):
            self.store.register("Cypher", "123", tcp_port=5100)

    def test_invalid_nickname_rejected(self):
        with self.assertRaises(AuthError):
            self.store.register("a!b", "validpassword", tcp_port=5100)

    def test_login_unknown_nickname_rejected(self):
        with self.assertRaises(AuthError):
            self.store.verify("Ghost", "whatever123")

    def test_password_never_stored_in_plaintext(self):
        self.store.register("Tank", "supersecretpw", tcp_port=5100)
        raw = (Path(self._tmp.name) / "accounts.json").read_text(encoding="utf-8")
        self.assertNotIn("supersecretpw", raw)


if __name__ == "__main__":
    unittest.main()
