"""Юнит-тесты для crypto_utils.py — RSA-рукопожатие и AES-GCM сессии."""

import os
import sys
import tempfile
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from p2p_messenger import crypto_utils
from p2p_messenger.config import Config
from p2p_messenger.crypto_utils import CascadeCipher, CryptoError, SessionCipher


class TestRSAKeypair(unittest.TestCase):
    def setUp(self):
        # Подменяем каталог данных на временный, чтобы не трогать реальный ~/.p2p_messenger
        self._tmp = tempfile.TemporaryDirectory()
        self._orig_config = crypto_utils.CONFIG
        crypto_utils.CONFIG = Config(data_dir=Path(self._tmp.name))

    def tearDown(self):
        crypto_utils.CONFIG = self._orig_config
        self._tmp.cleanup()

    def test_keypair_created_and_reloaded(self):
        priv1, pub1 = crypto_utils.load_or_create_rsa_keypair("alice", "correct horse battery")
        pem1 = crypto_utils.public_key_to_pem(pub1)

        # Повторная загрузка тем же паролем должна вернуть тот же ключ.
        priv2, pub2 = crypto_utils.load_or_create_rsa_keypair("alice", "correct horse battery")
        pem2 = crypto_utils.public_key_to_pem(pub2)

        self.assertEqual(pem1, pem2)

    def test_wrong_password_fails_to_decrypt_private_key(self):
        crypto_utils.load_or_create_rsa_keypair("eve", "right-password")
        with self.assertRaises(CryptoError):
            crypto_utils.load_or_create_rsa_keypair("eve", "wrong-password")

    def test_rsa_encrypt_decrypt_roundtrip(self):
        priv, pub = crypto_utils.load_or_create_rsa_keypair("bob", "hunter2-hunter2")
        secret = b"session-key-material-32-bytes!!"
        ciphertext = crypto_utils.rsa_encrypt(pub, secret)
        self.assertNotEqual(ciphertext, secret)
        decrypted = crypto_utils.rsa_decrypt(priv, ciphertext)
        self.assertEqual(decrypted, secret)

    def test_different_identities_get_different_keys(self):
        _, pub_a = crypto_utils.load_or_create_rsa_keypair("carol", "password-carol")
        _, pub_b = crypto_utils.load_or_create_rsa_keypair("dave", "password-dave")
        self.assertNotEqual(
            crypto_utils.public_key_to_pem(pub_a), crypto_utils.public_key_to_pem(pub_b)
        )


class TestSessionCipher(unittest.TestCase):
    def test_encrypt_decrypt_roundtrip(self):
        key = crypto_utils.generate_session_key()
        cipher = SessionCipher(key)
        plaintext = "Привет, мир! 🔐".encode("utf-8")

        blob = cipher.encrypt(plaintext)
        self.assertIsInstance(blob, str)

        decrypted = cipher.decrypt(blob)
        self.assertEqual(decrypted, plaintext)

    def test_tampered_ciphertext_fails_auth(self):
        key = crypto_utils.generate_session_key()
        cipher = SessionCipher(key)
        blob = cipher.encrypt(b"secret message")

        tampered = bytearray(bytes.fromhex(blob))
        tampered[-1] ^= 0xFF  # портим последний байт (тег GCM)
        tampered_hex = bytes(tampered).hex()

        with self.assertRaises(CryptoError):
            cipher.decrypt(tampered_hex)

    def test_wrong_key_fails(self):
        cipher_a = SessionCipher(crypto_utils.generate_session_key())
        cipher_b = SessionCipher(crypto_utils.generate_session_key())
        blob = cipher_a.encrypt(b"top secret")
        with self.assertRaises(CryptoError):
            cipher_b.decrypt(blob)


class TestCascadeCipher(unittest.TestCase):
    """CascadeCipher применяет 5 методов шифрования подряд к каждому
    сообщению (см. crypto_utils.py) - в т.ч. и к одному короткому."""

    def test_roundtrip_short_single_message(self):
        # Именно короткое одиночное сообщение - каскад не должен от него
        # "экономить" и обязан прогнать все 5 слоёв как обычно.
        key = crypto_utils.generate_session_key()
        cipher = CascadeCipher(key)
        plaintext = "Привет!".encode("utf-8")

        blob = cipher.encrypt(plaintext)
        self.assertIsInstance(blob, str)
        self.assertEqual(cipher.decrypt(blob), plaintext)

    def test_roundtrip_empty_and_long_messages(self):
        cipher = CascadeCipher(crypto_utils.generate_session_key())
        for plaintext in (b"", b"x", os.urandom(200_000)):
            blob = cipher.encrypt(plaintext)
            self.assertEqual(cipher.decrypt(blob), plaintext)

    def test_output_is_much_larger_due_to_five_layers(self):
        # У каждого из 5 слоёв свои IV/nonce и (для 3 из них) свой
        # HMAC-тег, так что результат заметно длиннее, чем у одного AES-GCM.
        key = crypto_utils.generate_session_key()
        plaintext = b"hello"
        cascade_blob = CascadeCipher(key).encrypt(plaintext)
        single_blob = SessionCipher(key).encrypt(plaintext)
        self.assertGreater(len(cascade_blob), len(single_blob) * 3)

    def test_tampered_ciphertext_fails_auth(self):
        cipher = CascadeCipher(crypto_utils.generate_session_key())
        blob = cipher.encrypt(b"secret message")
        tampered = bytearray(bytes.fromhex(blob))
        tampered[0] ^= 0xFF
        with self.assertRaises(CryptoError):
            cipher.decrypt(bytes(tampered).hex())

    def test_wrong_key_fails(self):
        cipher_a = CascadeCipher(crypto_utils.generate_session_key())
        cipher_b = CascadeCipher(crypto_utils.generate_session_key())
        blob = cipher_a.encrypt(b"top secret")
        with self.assertRaises(CryptoError):
            cipher_b.decrypt(blob)

    def test_associated_data_must_match(self):
        cipher = CascadeCipher(crypto_utils.generate_session_key())
        blob = cipher.encrypt(b"data", associated_data=b"header-v1")
        self.assertEqual(cipher.decrypt(blob, associated_data=b"header-v1"), b"data")
        with self.assertRaises(CryptoError):
            cipher.decrypt(blob, associated_data=b"header-v2")


if __name__ == "__main__":
    unittest.main()
