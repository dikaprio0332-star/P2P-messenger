"""
Интеграционный тест: два реальных узла Peer поднимаются на localhost,
устанавливают TCP-соединение, проходят RSA/AES рукопожатие и обмениваются
зашифрованными сообщениями и файлом. Никаких моков сети — используются
настоящие сокеты на 127.0.0.1, только порты берутся свободные.
"""

import queue
import shutil
import socket
import sys
import tempfile
import time
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from p2p_messenger import config as config_module
from p2p_messenger.peer import Peer


def free_tcp_port() -> int:
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        s.bind(("127.0.0.1", 0))
        return s.getsockname()[1]


class TestEndToEndMessaging(unittest.TestCase):
    def setUp(self):
        # Изолируем файловое хранилище (ключи/история/контакты) во временном каталоге.
        self._tmp = tempfile.TemporaryDirectory()
        self._orig_config = config_module.CONFIG
        config_module.CONFIG = config_module.Config(data_dir=Path(self._tmp.name))
        # peer.py и storage.py импортировали CONFIG по значению в момент импорта модуля,
        # поэтому патчим их локальные ссылки тоже.
        import p2p_messenger.crypto_utils as crypto_utils_module
        import p2p_messenger.storage as storage_module
        import p2p_messenger.network as network_module
        import p2p_messenger.peer as peer_module

        crypto_utils_module.CONFIG = config_module.CONFIG
        storage_module.CONFIG = config_module.CONFIG
        network_module.CONFIG = config_module.CONFIG
        peer_module.CONFIG = config_module.CONFIG

        self.port_a = free_tcp_port()
        self.port_b = free_tcp_port()

        self.alice = Peer(name="alice_test", tcp_port=self.port_a, key_password="alice-pw-123")
        self.bob = Peer(name="bob_test", tcp_port=self.port_b, key_password="bob-pw-123")

        self.alice_events: "queue.Queue[str]" = queue.Queue()
        self.bob_events: "queue.Queue[str]" = queue.Queue()
        self.alice.on_chat_message = lambda name, text: self.alice_events.put((name, text))
        self.bob.on_chat_message = lambda name, text: self.bob_events.put((name, text))

        self.alice.start()
        self.bob.start()

    def tearDown(self):
        self.alice.stop()
        self.bob.stop()
        config_module.CONFIG = self._orig_config
        self._tmp.cleanup()

    def test_handshake_and_encrypted_chat(self):
        name = self.alice.connect_to("127.0.0.1", self.port_b)
        self.assertEqual(name, "bob_test")

        # Дождаться, пока Bob тоже увидит установленную сессию (событие асинхронно).
        deadline = time.time() + 3
        while "alice_test" not in self.bob.get_active_sessions() and time.time() < deadline:
            time.sleep(0.05)
        self.assertIn("alice_test", self.bob.get_active_sessions())

        self.alice.send_chat("bob_test", "Привет, Боб!")
        received_name, received_text = self.bob_events.get(timeout=3)
        self.assertEqual(received_name, "alice_test")
        self.assertEqual(received_text, "Привет, Боб!")

        self.bob.send_chat("alice_test", "Привет, Алиса!")
        received_name2, received_text2 = self.alice_events.get(timeout=3)
        self.assertEqual(received_name2, "bob_test")
        self.assertEqual(received_text2, "Привет, Алиса!")

        # История должна сохраниться на диск с обеих сторон.
        alice_history = self.alice.history.read_all("bob_test")
        self.assertTrue(any(r["text"] == "Привет, Боб!" and r["direction"] == "out" for r in alice_history))

    def test_file_transfer(self):
        self.alice.connect_to("127.0.0.1", self.port_b)
        deadline = time.time() + 3
        while "alice_test" not in self.bob.get_active_sessions() and time.time() < deadline:
            time.sleep(0.05)

        src_dir = Path(self._tmp.name) / "src"
        src_dir.mkdir()
        src_file = src_dir / "hello.txt"
        payload = ("Тестовое содержимое файла. " * 500).encode("utf-8")  # достаточно для нескольких chunk'ов
        src_file.write_bytes(payload)

        self.alice.send_file("bob_test", str(src_file), chunk_size=1024)

        received_path = config_module.CONFIG.data_dir / "received_files" / "hello.txt"
        deadline = time.time() + 5
        while not received_path.exists() and time.time() < deadline:
            time.sleep(0.1)

        self.assertTrue(received_path.exists())
        self.assertEqual(received_path.read_bytes(), payload)


if __name__ == "__main__":
    unittest.main()
