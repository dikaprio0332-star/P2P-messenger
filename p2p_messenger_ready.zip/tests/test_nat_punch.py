"""
Тест инвайт-кода: два узла Peer подключаются друг к другу БЕЗ вызова
connect_to() напрямую по известному адресу — только через
generate_invite_code()/connect_via_invite(), как это делает веб-интерфейс
через /api/invite-code. Роутер с UPnP в тестовом окружении недоступен,
поэтому код опирается на локальный (LAN) адрес — именно этот путь и
проверяем: даже без UPnP-роутера подключение между узлами в одной сети
обязано срабатывать.
"""

import queue
import socket
import sys
import tempfile
import threading
import time
import unittest
from pathlib import Path
from unittest.mock import patch

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from p2p_messenger import config as config_module
from p2p_messenger.nat_punch import InviteCode
from p2p_messenger.peer import Peer

# В реальности alice и bob работают на разных хостах с разными IP.
# В тестовом окружении оба процесса делят один и тот же loopback-адрес,
# из-за чего ОС видит подключения "туда" и "обратно" как один и тот же
# 4-tuple (127.0.0.1:X <-> 127.0.0.1:Y неотличимо от обратного
# направления на одной машине) - это артефакт теста на одном хосте, а не
# баг пробива. Поэтому здесь явно разносим "локальные" адреса пиров на
# 127.0.0.1 и 127.0.0.2, как если бы это были два разных хоста в одной
# сети (127.0.0.0/8 целиком назначен loopback, оба адреса локальны).
_FAKE_LOCAL_IPS = {"alice_invite": "127.0.0.1", "bob_invite": "127.0.0.2"}


def free_tcp_port() -> int:
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        s.bind(("127.0.0.1", 0))
        return s.getsockname()[1]


class TestInviteCodeConnection(unittest.TestCase):
    def setUp(self):
        self._tmp = tempfile.TemporaryDirectory()
        self._orig_config = config_module.CONFIG
        config_module.CONFIG = config_module.Config(data_dir=Path(self._tmp.name))

        import p2p_messenger.crypto_utils as crypto_utils_module
        import p2p_messenger.storage as storage_module
        import p2p_messenger.network as network_module
        import p2p_messenger.peer as peer_module

        crypto_utils_module.CONFIG = config_module.CONFIG
        storage_module.CONFIG = config_module.CONFIG
        network_module.CONFIG = config_module.CONFIG
        peer_module.CONFIG = config_module.CONFIG

        self.port_a = free_tcp_port()
        self.port_b = free_tcp_port()

        self.alice = Peer(name="alice_invite", tcp_port=self.port_a, key_password="alice-pw-123")
        self.bob = Peer(name="bob_invite", tcp_port=self.port_b, key_password="bob-pw-123")

        self.alice_events: "queue.Queue[str]" = queue.Queue()
        self.bob_events: "queue.Queue[str]" = queue.Queue()
        self.alice.on_chat_message = lambda name, text: self.alice_events.put((name, text))
        self.bob.on_chat_message = lambda name, text: self.bob_events.put((name, text))

        self.alice.start()
        self.bob.start()

    def tearDown(self):
        self.alice.stop()
        self.bob.stop()
        config_module.CONFIG = self._orig_config
        self._tmp.cleanup()

    def test_invite_code_roundtrip_contains_local_address(self):
        # Без UPnP-роутера внешний адрес остаётся None, но локальный
        # адрес и порт обязаны быть в коде всегда - иначе LAN-сценарий
        # (самый частый в реальности - оба в одном Wi-Fi) не сработает.
        code = self.alice.generate_invite_code()
        invite = InviteCode.decode(code)
        self.assertEqual(invite.name, "alice_invite")
        self.assertEqual(invite.local_port, self.port_a)
        self.assertTrue(invite.local_ip)

    def test_connect_via_invite_without_any_server(self):
        """
        Ключевой сценарий из бага: оба узла одновременно инициируют
        подключение по инвайт-коду друг друга (simultaneous open), без
        сигнального сервера и без ручного connect_to(address, port).
        """
        with patch(
            "p2p_messenger.nat_punch.get_local_ip",
            side_effect=[_FAKE_LOCAL_IPS["alice_invite"], _FAKE_LOCAL_IPS["bob_invite"]],
        ):
            code_a = self.alice.generate_invite_code()
            code_b = self.bob.generate_invite_code()

        results = {}

        def alice_side():
            try:
                results["alice"] = self.alice.connect_via_invite(code_b, timeout=8)
            except Exception as exc:  # noqa: BLE001
                results["alice"] = exc

        def bob_side():
            try:
                results["bob"] = self.bob.connect_via_invite(code_a, timeout=8)
            except Exception as exc:  # noqa: BLE001
                results["bob"] = exc

        t1 = threading.Thread(target=alice_side)
        t2 = threading.Thread(target=bob_side)
        t1.start()
        t2.start()
        t1.join(timeout=10)
        t2.join(timeout=10)

        self.assertEqual(results.get("alice"), "bob_invite",
                          f"Пробив со стороны alice не удался: {results.get('alice')!r}")
        self.assertEqual(results.get("bob"), "alice_invite",
                          f"Пробив со стороны bob не удался: {results.get('bob')!r}")

        # И раз рукопожатие прошло - шифрованный чат должен работать как обычно.
        self.alice.send_chat("bob_invite", "Привет без сервера!")
        name, text = self.bob_events.get(timeout=5)
        self.assertEqual(name, "alice_invite")
        self.assertEqual(text, "Привет без сервера!")


if __name__ == "__main__":
    unittest.main()
