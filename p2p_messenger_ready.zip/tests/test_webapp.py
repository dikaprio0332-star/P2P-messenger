"""
Интеграционный тест веб-слоя: два "браузера" (два независимых Flask test
client, каждый со своей cookie-сессией) регистрируются, устанавливают
настоящее зашифрованное P2P-соединение по localhost и обмениваются
сообщением — всё исключительно через HTTP API, как это делал бы реальный
браузер поверх app.js.
"""

import sys
import tempfile
import time
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from p2p_messenger import config as config_module


class TestWebApp(unittest.TestCase):
    def setUp(self):
        self._tmp = tempfile.TemporaryDirectory()
        self._orig_config = config_module.CONFIG
        config_module.CONFIG = config_module.Config(data_dir=Path(self._tmp.name))

        import p2p_messenger.crypto_utils as crypto_utils_module
        import p2p_messenger.storage as storage_module
        import p2p_messenger.network as network_module
        import p2p_messenger.peer as peer_module
        import p2p_messenger.auth as auth_module
        import p2p_messenger.webapp as webapp_module

        for mod in (crypto_utils_module, storage_module, network_module, peer_module, auth_module, webapp_module):
            mod.CONFIG = config_module.CONFIG

        self.webapp_module = webapp_module
        self.app = webapp_module.create_app()
        self.app.testing = True

    def tearDown(self):
        # Явно останавливаем все узлы, поднятые за тест: иначе их
        # daemon-потоки (в т.ч. discovery) продолжают жить и могут писать
        # в уже удалённый временный каталог следующего теста.
        self.app.peer_registry.stop_all()
        config_module.CONFIG = self._orig_config
        self._tmp.cleanup()

    def test_register_connect_and_chat_over_http(self):
        client_alice = self.app.test_client()
        client_bob = self.app.test_client()

        r1 = client_alice.post(
            "/api/register",
            json={"nickname": "alice_web", "password": "alicepass123"},
        )
        self.assertEqual(r1.status_code, 200, r1.get_json())
        self.assertTrue(r1.get_json()["ok"])

        r2 = client_bob.post(
            "/api/register",
            json={"nickname": "bob_web", "password": "bobpass123"},
        )
        self.assertEqual(r2.status_code, 200, r2.get_json())
        # Порт выдан сервером автоматически - никто его не передавал.
        port_bob = r2.get_json()["port"]
        self.assertIsInstance(port_bob, int)

        # Сессии независимы: у alice ещё нет активных подключений.
        sessions = client_alice.get("/api/sessions").get_json()["sessions"]
        self.assertEqual(sessions, [])

        # Alice подключается к Bob напрямую по TCP через HTTP-эндпоинт.
        r3 = client_alice.post("/api/connect", json={"address": "127.0.0.1", "port": port_bob})
        self.assertEqual(r3.status_code, 200, r3.get_json())
        self.assertEqual(r3.get_json()["peer"], "bob_web")

        deadline = time.time() + 3
        while time.time() < deadline:
            sessions = client_bob.get("/api/sessions").get_json()["sessions"]
            if "alice_web" in sessions:
                break
            time.sleep(0.05)
        self.assertIn("alice_web", sessions)

        # Alice шлёт сообщение через REST.
        r4 = client_alice.post("/api/send", json={"peer": "bob_web", "text": "Привет через веб!"})
        self.assertEqual(r4.status_code, 200, r4.get_json())

        # Bob получает его через polling-эндпоинт событий.
        deadline = time.time() + 3
        found = None
        while time.time() < deadline:
            events = client_bob.get("/api/events?since=0").get_json()["events"]
            chat_events = [e for e in events if e["kind"] == "chat"]
            if chat_events:
                found = chat_events[0]
                break
            time.sleep(0.05)

        self.assertIsNotNone(found, "Bob не получил сообщение через /api/events")
        self.assertEqual(found["peer"], "alice_web")
        self.assertEqual(found["text"], "Привет через веб!")

    def test_connect_via_invite_code_over_http(self):
        """
        Тот же сценарий, что и test_register_connect_and_chat_over_http,
        но без /api/connect по известному адресу: оба "браузера"
        генерируют инвайт-код через GET /api/invite-code и обмениваются
        им через POST /api/invite-code — как это делает модалка в
        app.js, без какого-либо сигнального сервера.
        """
        import threading
        from unittest.mock import patch

        client_alice = self.app.test_client()
        client_bob = self.app.test_client()

        client_alice.post(
            "/api/register",
            json={"nickname": "alice_inv", "password": "alicepass123"},
        )
        client_bob.post(
            "/api/register",
            json={"nickname": "bob_inv", "password": "bobpass123"},
        )

        # Как и в tests/test_nat_punch.py: в одном тестовом процессе оба
        # узла делят один и тот же loopback-адрес, поэтому явно разносим
        # их "локальные" IP на 127.0.0.1/127.0.0.2, эмулируя два разных
        # хоста в одной сети (в проде get_local_ip() сама вернёт разные
        # адреса для разных машин).
        with patch(
            "p2p_messenger.nat_punch.get_local_ip",
            side_effect=["127.0.0.1", "127.0.0.2"],
        ):
            r1 = client_alice.get("/api/invite-code")
            r2 = client_bob.get("/api/invite-code")
        self.assertEqual(r1.status_code, 200, r1.get_json())
        self.assertEqual(r2.status_code, 200, r2.get_json())
        code_alice = r1.get_json()["invite_code"]
        code_bob = r2.get_json()["invite_code"]

        results = {}

        def alice_connects():
            resp = client_alice.post("/api/invite-code", json={"invite_code": code_bob})
            results["alice"] = resp.get_json()

        def bob_connects():
            resp = client_bob.post("/api/invite-code", json={"invite_code": code_alice})
            results["bob"] = resp.get_json()

        t1 = threading.Thread(target=alice_connects)
        t2 = threading.Thread(target=bob_connects)
        t1.start()
        t2.start()
        t1.join(timeout=15)
        t2.join(timeout=15)

        self.assertTrue(results.get("alice", {}).get("ok"), results.get("alice"))
        self.assertEqual(results["alice"]["peer"], "bob_inv")
        self.assertTrue(results.get("bob", {}).get("ok"), results.get("bob"))
        self.assertEqual(results["bob"]["peer"], "alice_inv")

        r_send = client_alice.post("/api/send", json={"peer": "bob_inv", "text": "Без сервера тоже работает"})
        self.assertEqual(r_send.status_code, 200, r_send.get_json())

        deadline = time.time() + 3
        found = None
        while time.time() < deadline:
            events = client_bob.get("/api/events?since=0").get_json()["events"]
            chat_events = [e for e in events if e["kind"] == "chat"]
            if chat_events:
                found = chat_events[0]
                break
            time.sleep(0.05)

        self.assertIsNotNone(found, "Bob не получил сообщение после подключения по инвайт-коду")
        self.assertEqual(found["text"], "Без сервера тоже работает")

        # История также должна быть доступна через REST.
        hist = client_alice.get("/api/history/bob_inv").get_json()["history"]
        self.assertTrue(any(h["text"] == "Без сервера тоже работает" for h in hist))

    def test_login_requires_correct_password(self):
        client = self.app.test_client()
        client.post("/api/register", json={"nickname": "carol_web", "password": "correctpass"})
        client.post("/api/logout")

        bad = client.post("/api/login", json={"nickname": "carol_web", "password": "wrongpass"})
        self.assertEqual(bad.status_code, 400)

        good = client.post("/api/login", json={"nickname": "carol_web", "password": "correctpass"})
        self.assertEqual(good.status_code, 200)

    def test_unauthenticated_requests_rejected(self):
        client = self.app.test_client()
        resp = client.get("/api/sessions")
        self.assertEqual(resp.status_code, 401)


if __name__ == "__main__":
    unittest.main()
