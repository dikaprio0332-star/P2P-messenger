"""
Интеграционный тест веб-слоя: два "браузера" (два независимых Flask test
client, каждый со своей cookie-сессией) регистрируются, устанавливают
настоящее зашифрованное P2P-соединение по localhost и обмениваются
сообщением — всё исключительно через HTTP API, как это делал бы реальный
браузер поверх app.js.
"""

import socket
import sys
import tempfile
import time
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from p2p_messenger import config as config_module


def free_tcp_port() -> int:
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        s.bind(("127.0.0.1", 0))
        return s.getsockname()[1]


class TestWebApp(unittest.TestCase):
    def setUp(self):
        self._tmp = tempfile.TemporaryDirectory()
        self._orig_config = config_module.CONFIG
        config_module.CONFIG = config_module.Config(data_dir=Path(self._tmp.name))

        import p2p_messenger.crypto_utils as crypto_utils_module
        import p2p_messenger.storage as storage_module
        import p2p_messenger.network as network_module
        import p2p_messenger.peer as peer_module
        import p2p_messenger.auth as auth_module
        import p2p_messenger.webapp as webapp_module

        for mod in (crypto_utils_module, storage_module, network_module, peer_module, auth_module, webapp_module):
            mod.CONFIG = config_module.CONFIG

        self.webapp_module = webapp_module
        self.app = webapp_module.create_app()
        self.app.testing = True

    def tearDown(self):
        # Явно останавливаем все узлы, поднятые за тест: иначе их
        # daemon-потоки (в т.ч. discovery) продолжают жить и могут писать
        # в уже удалённый временный каталог следующего теста.
        self.app.peer_registry.stop_all()
        config_module.CONFIG = self._orig_config
        self._tmp.cleanup()

    def test_register_connect_and_chat_over_http(self):
        client_alice = self.app.test_client()
        client_bob = self.app.test_client()

        port_alice = free_tcp_port()
        port_bob = free_tcp_port()

        r1 = client_alice.post(
            "/api/register",
            json={"nickname": "alice_web", "password": "alicepass123", "port": port_alice},
        )
        self.assertEqual(r1.status_code, 200, r1.get_json())
        self.assertTrue(r1.get_json()["ok"])

        r2 = client_bob.post(
            "/api/register",
            json={"nickname": "bob_web", "password": "bobpass123", "port": port_bob},
        )
        self.assertEqual(r2.status_code, 200, r2.get_json())

        # Сессии независимы: у alice ещё нет активных подключений.
        sessions = client_alice.get("/api/sessions").get_json()["sessions"]
        self.assertEqual(sessions, [])

        # Alice подключается к Bob напрямую по TCP через HTTP-эндпоинт.
        r3 = client_alice.post("/api/connect", json={"address": "127.0.0.1", "port": port_bob})
        self.assertEqual(r3.status_code, 200, r3.get_json())
        self.assertEqual(r3.get_json()["peer"], "bob_web")

        deadline = time.time() + 3
        while time.time() < deadline:
            sessions = client_bob.get("/api/sessions").get_json()["sessions"]
            if "alice_web" in sessions:
                break
            time.sleep(0.05)
        self.assertIn("alice_web", sessions)

        # Alice шлёт сообщение через REST.
        r4 = client_alice.post("/api/send", json={"peer": "bob_web", "text": "Привет через веб!"})
        self.assertEqual(r4.status_code, 200, r4.get_json())

        # Bob получает его через polling-эндпоинт событий.
        deadline = time.time() + 3
        found = None
        while time.time() < deadline:
            events = client_bob.get("/api/events?since=0").get_json()["events"]
            chat_events = [e for e in events if e["kind"] == "chat"]
            if chat_events:
                found = chat_events[0]
                break
            time.sleep(0.05)

        self.assertIsNotNone(found, "Bob не получил сообщение через /api/events")
        self.assertEqual(found["peer"], "alice_web")
        self.assertEqual(found["text"], "Привет через веб!")

        # История также должна быть доступна через REST.
        hist = client_alice.get("/api/history/bob_web").get_json()["history"]
        self.assertTrue(any(h["text"] == "Привет через веб!" for h in hist))

    def test_login_requires_correct_password(self):
        client = self.app.test_client()
        port = free_tcp_port()
        client.post("/api/register", json={"nickname": "carol_web", "password": "correctpass", "port": port})
        client.post("/api/logout")

        bad = client.post("/api/login", json={"nickname": "carol_web", "password": "wrongpass"})
        self.assertEqual(bad.status_code, 400)

        good = client.post("/api/login", json={"nickname": "carol_web", "password": "correctpass"})
        self.assertEqual(good.status_code, 200)

    def test_unauthenticated_requests_rejected(self):
        client = self.app.test_client()
        resp = client.get("/api/sessions")
        self.assertEqual(resp.status_code, 401)


if __name__ == "__main__":
    unittest.main()
