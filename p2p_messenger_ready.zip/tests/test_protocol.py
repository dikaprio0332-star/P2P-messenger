"""Юнит-тесты для protocol.py — кадрирование и (де)сериализация сообщений."""

import io
import sys
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from p2p_messenger.protocol import Envelope, MessageType, ProtocolError, unpack_stream


class FakeSocket:
    """Имитирует sock.recv(n), отдавая данные из буфера кусками произвольного размера."""

    def __init__(self, data: bytes, chunk_size: int = 3):
        self._buf = data
        self._chunk_size = chunk_size

    def recv(self, n: int) -> bytes:
        if not self._buf:
            return b""
        take = min(n, self._chunk_size, len(self._buf))
        out, self._buf = self._buf[:take], self._buf[take:]
        return out


class TestEnvelope(unittest.TestCase):
    def test_roundtrip(self):
        env = Envelope(type=MessageType.CHAT.value, payload={"ciphertext": "abcd"}, sender="alice")
        raw = env.to_bytes()

        sock = FakeSocket(raw, chunk_size=5)
        decoded = unpack_stream(sock.recv, max_size=1_000_000)

        self.assertEqual(decoded.type, MessageType.CHAT.value)
        self.assertEqual(decoded.payload["ciphertext"], "abcd")
        self.assertEqual(decoded.sender, "alice")
        self.assertEqual(decoded.msg_id, env.msg_id)

    def test_handles_fragmented_stream(self):
        """Убеждаемся, что kадрирование работает, даже если recv() отдаёт по 1 байту."""
        env = Envelope(type=MessageType.PING.value)
        raw = env.to_bytes()
        sock = FakeSocket(raw, chunk_size=1)
        decoded = unpack_stream(sock.recv, max_size=1_000_000)
        self.assertEqual(decoded.type, MessageType.PING.value)

    def test_rejects_oversized_message(self):
        env = Envelope(type=MessageType.CHAT.value, payload={"x": "y" * 100})
        raw = env.to_bytes()
        sock = FakeSocket(raw)
        with self.assertRaises(ProtocolError):
            unpack_stream(sock.recv, max_size=10)  # заведомо меньше реального размера

    def test_connection_closed_mid_frame_raises(self):
        env = Envelope(type=MessageType.PING.value)
        raw = env.to_bytes()
        truncated = raw[:-2]  # обрубаем конец, имитируя разрыв соединения
        sock = FakeSocket(truncated)
        with self.assertRaises(ProtocolError):
            unpack_stream(sock.recv, max_size=1_000_000)


if __name__ == "__main__":
    unittest.main()
