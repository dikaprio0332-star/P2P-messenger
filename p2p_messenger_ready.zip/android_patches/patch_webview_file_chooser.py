#!/usr/bin/env python3
"""
Патч для python-for-android (bootstrap "webview"): добавляет поддержку
<input type="file"> (фото/видео/любой файл) внутри системного WebView.

ПОЧЕМУ ЭТО НУЖНО
-----------------
Стандартный webview-бутстрап p4a создаёт android.webkit.WebView, но не
задаёт ему WebChromeClient с переопределённым onShowFileChooser(). Без
этого метода клик по <input type="file"> в WebView НИЧЕГО не делает —
системный диалог выбора файла/камеры просто не открывается. Это никак
не связано с Flask/JS-кодом мессенджера (он рабочий и правильный — в
обычном браузере всё открывается штатно) — это ограничение самого
android.webkit.WebView без явной настройки на Java-уровне.

ЧТО ДЕЛАЕТ СКРИПТ
-----------------
Находит PythonActivity.java внутри локально скачанного p4a (появляется
там только после первой попытки "buildozer android debug", даже если
сама сборка на этом шаге упала) и добавляет:
  1. нужные import'ы;
  2. поле-колбэк для передачи выбранного файла обратно в WebView;
  3. webView.setWebChromeClient(...) с onShowFileChooser();
  4. onActivityResult(...), который отдаёт результат выбора в WebView
     (если такой метод уже есть в файле — код аккуратно вставляется
     внутрь него, а не дублируется).

Патч идемпотентен: повторный запуск на уже пропатченном файле ничего
не ломает (скрипт видит маркер и выходит).

КАК ЗАПУСКАТЬ
-------------
    python3 android_patches/patch_webview_file_chooser.py

Ищет файл автоматически в стандартном пути buildozer
(.buildozer/android/platform/python-for-android/...). Если не находит —
можно передать путь вручную:

    python3 android_patches/patch_webview_file_chooser.py /путь/к/PythonActivity.java

После патча — обычная пересборка: buildozer android debug (или
android_debug/deploy).

Подробности и когда именно это запускать — см. android_patches/README.md
"""

from __future__ import annotations

import sys
from pathlib import Path

MARKER = "// >>> p2p_messenger file-chooser patch"

DEFAULT_SEARCH_ROOTS = [
    Path(".buildozer/android/platform/python-for-android"),
    Path.home() / ".buildozer/android/platform/python-for-android",
]

TARGET_RELATIVE = Path(
    "pythonforandroid/bootstraps/webview/build/src/main/java/org/kivy/android/PythonActivity.java"
)

IMPORTS_BLOCK = f"""{MARKER}: imports
import android.content.Intent;
import android.net.Uri;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
// <<< p2p_messenger file-chooser patch: imports
"""

FIELDS_BLOCK = f"""{MARKER}: fields
    private ValueCallback<Uri[]> p2pFileChooserCallback;
    private static final int P2P_FILE_CHOOSER_REQUEST_CODE = 51426;
    // <<< p2p_messenger file-chooser patch: fields
"""

# Метод, который вешает обработчик выбора файла на WebView. Вызывается из
# onCreate() уже ПОСЛЕ того, как бутстрап сам создал и настроил WebView
# (webView.loadUrl(...) к этому моменту уже вызван/будет вызван позже —
# нам достаточно, что объект webView существует и доступен как this.webView
# или через getWebView()/mWebView в зависимости от версии бутстрапа).
HELPER_METHOD_BLOCK = f"""
    {MARKER}: helper method
    private void p2pSetupFileChooser(WebView wv) {{
        if (wv == null) {{
            return;
        }}
        wv.setWebChromeClient(new WebChromeClient() {{
            @Override
            public boolean onShowFileChooser(WebView webView,
                                              ValueCallback<Uri[]> filePathCallback,
                                              FileChooserParams fileChooserParams) {{
                if (p2pFileChooserCallback != null) {{
                    p2pFileChooserCallback.onReceiveValue(null);
                }}
                p2pFileChooserCallback = filePathCallback;
                Intent intent;
                try {{
                    intent = fileChooserParams.createIntent();
                }} catch (Exception e) {{
                    intent = new Intent(Intent.ACTION_GET_CONTENT);
                    intent.addCategory(Intent.CATEGORY_OPENABLE);
                    intent.setType("*/*");
                }}
                try {{
                    startActivityForResult(intent, P2P_FILE_CHOOSER_REQUEST_CODE);
                }} catch (android.content.ActivityNotFoundException e) {{
                    p2pFileChooserCallback = null;
                    return false;
                }}
                return true;
            }}
        }});
    }}
    // <<< p2p_messenger file-chooser patch: helper method
"""

ON_ACTIVITY_RESULT_BODY = f"""
        {MARKER}: onActivityResult body
        if (requestCode == P2P_FILE_CHOOSER_REQUEST_CODE) {{
            if (p2pFileChooserCallback == null) {{
                return;
            }}
            Uri[] results = null;
            if (resultCode == android.app.Activity.RESULT_OK && data != null) {{
                results = WebChromeClient.FileChooserParams.parseResult(resultCode, data);
            }}
            p2pFileChooserCallback.onReceiveValue(results);
            p2pFileChooserCallback = null;
            return;
        }}
        // <<< p2p_messenger file-chooser patch: onActivityResult body
"""

NEW_ON_ACTIVITY_RESULT_METHOD = f"""
    {MARKER}: new onActivityResult override
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {{
        super.onActivityResult(requestCode, resultCode, data);
{ON_ACTIVITY_RESULT_BODY}
    }}
    // <<< p2p_messenger file-chooser patch: new onActivityResult override
"""


def find_target_file(explicit_path: str | None) -> Path:
    if explicit_path:
        p = Path(explicit_path)
        if not p.is_file():
            sys.exit(f"Файл не найден: {p}")
        return p

    for root in DEFAULT_SEARCH_ROOTS:
        candidate = root / TARGET_RELATIVE
        if candidate.is_file():
            return candidate

    # Более широкий поиск на случай нестандартной структуры .buildozer
    for root in DEFAULT_SEARCH_ROOTS:
        if root.is_dir():
            matches = list(root.rglob("PythonActivity.java"))
            webview_matches = [m for m in matches if "webview" in str(m)]
            if webview_matches:
                return webview_matches[0]

    sys.exit(
        "Не нашёл pythonforandroid/bootstraps/webview/.../PythonActivity.java.\n"
        "Сначала выполните хотя бы одну попытку сборки (buildozer android debug),\n"
        "чтобы p4a скачался в .buildozer/ — даже если сама сборка на этом шаге\n"
        "упадёт, файл уже появится на диске. Либо передайте путь к файлу вручную:\n"
        "  python3 patch_webview_file_chooser.py /путь/к/PythonActivity.java"
    )


def patch(path: Path) -> None:
    text = path.read_text(encoding="utf-8")

    if MARKER in text:
        print(f"Уже пропатчено, пропускаю: {path}")
        return

    original = text

    # 1) imports — вставляем после последнего существующего import
    import_lines = [ln for ln in text.splitlines() if ln.strip().startswith("import ")]
    if not import_lines:
        sys.exit("Не нашёл ни одного 'import' в файле — структура файла неожиданная, патч остановлен.")
    last_import = import_lines[-1]
    text = text.replace(last_import, last_import + "\n" + IMPORTS_BLOCK, 1)

    # 2) поле-класс: вставляем сразу после объявления класса
    class_marker = None
    for line in text.splitlines():
        if line.strip().startswith("public class PythonActivity"):
            class_marker = line
            break
    if class_marker is None:
        sys.exit("Не нашёл 'public class PythonActivity ...' — структура файла неожиданная, патч остановлен.")
    text = text.replace(class_marker, class_marker + "\n" + FIELDS_BLOCK, 1)

    # 3) helper-метод — добавляем перед последней закрывающей скобкой файла (конец класса)
    last_brace_idx = text.rfind("}")
    if last_brace_idx == -1:
        sys.exit("Не нашёл закрывающую скобку класса — структура файла неожиданная, патч остановлен.")
    text = text[:last_brace_idx] + HELPER_METHOD_BLOCK + "\n" + text[last_brace_idx:]

    # 4) вызов p2pSetupFileChooser(...) внутри onCreate, сразу после super.onCreate(...)
    if "super.onCreate(savedInstanceState);" in text:
        text = text.replace(
            "super.onCreate(savedInstanceState);",
            "super.onCreate(savedInstanceState);\n"
            f"        {MARKER}: hook into onCreate\n"
            "        p2pSetupFileChooserDeferred();\n"
            f"        // <<< p2p_messenger file-chooser patch: hook into onCreate",
            1,
        )
        # Т.к. WebView в разных версиях бутстрапа создаётся не сразу в onCreate,
        # а может появляться чуть позже (после загрузки assets), навешиваем
        # обработчик отложенно и с повтором, пока не найдём поле WebView.
        deferred_method = f"""
    {MARKER}: deferred setup
    private void p2pSetupFileChooserDeferred() {{
        final android.os.Handler handler = new android.os.Handler(android.os.Looper.getMainLooper());
        final Runnable[] attempt = new Runnable[1];
        final int[] tries = {{0}};
        attempt[0] = new Runnable() {{
            @Override
            public void run() {{
                WebView wv = p2pFindWebView();
                if (wv != null) {{
                    p2pSetupFileChooser(wv);
                    return;
                }}
                tries[0]++;
                if (tries[0] < 100) {{
                    handler.postDelayed(attempt[0], 100);
                }}
            }}
        }};
        handler.post(attempt[0]);
    }}

    private WebView p2pFindWebView() {{
        try {{
            java.lang.reflect.Field[] fields = this.getClass().getDeclaredFields();
            for (java.lang.reflect.Field f : fields) {{
                if (WebView.class.isAssignableFrom(f.getType())) {{
                    f.setAccessible(true);
                    Object val = f.get(this);
                    if (val instanceof WebView) {{
                        return (WebView) val;
                    }}
                }}
            }}
        }} catch (Exception e) {{
            // игнорируем — просто попробуем ещё раз позже
        }}
        return null;
    }}
    // <<< p2p_messenger file-chooser patch: deferred setup
"""
        last_brace_idx = text.rfind("}")
        text = text[:last_brace_idx] + deferred_method + "\n" + text[last_brace_idx:]
    else:
        sys.exit(
            "Не нашёл 'super.onCreate(savedInstanceState);' в onCreate() — структура файла "
            "неожиданная, патч остановлен (чтобы не сломать сборку молча)."
        )

    # 5) onActivityResult — если уже есть, вставляем тело внутрь; если нет — добавляем новый метод
    if "protected void onActivityResult(" in text or "void onActivityResult(" in text:
        # Ищем сигнатуру метода и вставляем наш блок сразу после открывающей { метода
        idx = text.find("onActivityResult(")
        brace_idx = text.find("{", idx)
        if brace_idx == -1:
            sys.exit("Нашёл onActivityResult(...), но не нашёл его тело — патч остановлен.")
        text = text[: brace_idx + 1] + ON_ACTIVITY_RESULT_BODY + text[brace_idx + 1 :]
    else:
        last_brace_idx = text.rfind("}")
        text = text[:last_brace_idx] + NEW_ON_ACTIVITY_RESULT_METHOD + "\n" + text[last_brace_idx:]

    path.write_text(text, encoding="utf-8")
    print(f"Пропатчено: {path}")
    print(f"(резервная копия не создавалась — оригинал был:\n{'-'*40}\nдлина {len(original)} симв., теперь {len(text)} симв.)")


if __name__ == "__main__":
    explicit = sys.argv[1] if len(sys.argv) > 1 else None
    target = find_target_file(explicit)
    patch(target)
