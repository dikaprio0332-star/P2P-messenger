"""
Низкоуровневый сетевой слой: TCP-сервер, принимающий входящие соединения,
и обёртка Connection над сокетом, реализующая отправку/приём Envelope
по протоколу из protocol.py.

Этот модуль ничего не знает о шифровании или бизнес-логике чата — он
занимается только байтами и сокетами (принцип единственной ответственности).
"""

from __future__ import annotations

import logging
import socket
import threading
from typing import Callable, Optional

from .config import CONFIG
from .protocol import Envelope, ProtocolError, unpack_stream

logger = logging.getLogger("p2p_messenger.network")


class Connection:
    """
    Обёртка над одним TCP-сокетом, соединяющим нас с одним пиром.

    Толстая обёртка нужна, чтобы:
      - гарантировать потокобезопасную отправку (лок на send)
      - предоставить удобный send_envelope()/recv_envelope()
      - централизованно закрывать сокет один раз
    """

    def __init__(self, sock: socket.socket, address: tuple[str, int]):
        self.sock = sock
        self.address = address
        self._send_lock = threading.Lock()
        self._closed = False
        self.peer_name: Optional[str] = None  # заполняется после HELLO

    def send_envelope(self, envelope: Envelope) -> None:
        data = envelope.to_bytes()
        with self._send_lock:
            if self._closed:
                raise ProtocolError("Попытка отправить данные в закрытое соединение")
            self.sock.sendall(data)

    def recv_envelope(self) -> Envelope:
        return unpack_stream(self.sock.recv, CONFIG.max_message_size)

    def close(self) -> None:
        if self._closed:
            return
        self._closed = True
        try:
            self.sock.shutdown(socket.SHUT_RDWR)
        except OSError:
            pass
        try:
            self.sock.close()
        except OSError:
            pass

    @property
    def is_closed(self) -> bool:
        return self._closed

    def __repr__(self) -> str:
        name = self.peer_name or "?"
        return f"<Connection peer={name} addr={self.address}>"


class TCPServer:
    """
    Слушает входящие TCP-соединения и для каждого запускает отдельный
    поток-обработчик через переданный callback `on_connection`.
    """

    def __init__(self, port: int, on_connection: Callable[[Connection], None]):
        self.port = port
        self.on_connection = on_connection
        self._server_sock: Optional[socket.socket] = None
        self._stop_event = threading.Event()
        self._thread: Optional[threading.Thread] = None

    def start(self) -> None:
        self._server_sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        self._server_sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        self._server_sock.bind(("0.0.0.0", self.port))
        self._server_sock.listen(16)
        self._server_sock.settimeout(1.0)

        self._thread = threading.Thread(target=self._accept_loop, daemon=True, name="tcp-accept")
        self._thread.start()
        logger.info("TCP сервер слушает порт %s", self.port)

    def _accept_loop(self) -> None:
        while not self._stop_event.is_set():
            try:
                client_sock, addr = self._server_sock.accept()
            except socket.timeout:
                continue
            except OSError:
                break
            conn = Connection(client_sock, addr)
            threading.Thread(
                target=self._safe_handle, args=(conn,), daemon=True, name=f"conn-{addr}"
            ).start()

    def _safe_handle(self, conn: Connection) -> None:
        try:
            self.on_connection(conn)
        except (OSError, ProtocolError) as exc:
            # Обрыв соединения в процессе работы - штатная ситуация, не ошибка уровня приложения.
            logger.debug("Соединение %s завершилось: %s", conn.address, exc)
            conn.close()
        except Exception:
            logger.exception("Ошибка обработки входящего соединения %s", conn.address)
            conn.close()

    def stop(self) -> None:
        self._stop_event.set()
        if self._server_sock:
            try:
                self._server_sock.close()
            except OSError:
                pass


def connect_to_peer(address: str, port: int, timeout: float = CONFIG.connect_timeout_sec) -> Connection:
    """Установить исходящее TCP-соединение с пиром. Бросает OSError при неудаче."""
    sock = socket.create_connection((address, port), timeout=timeout)
    sock.settimeout(None)  # после подключения переходим на блокирующий режим для recv-цикла
    return Connection(sock, (address, port))
