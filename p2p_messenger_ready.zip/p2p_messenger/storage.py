"""
Хранилище: история переписки и список контактов на диске (JSON).

Простое, но полностью рабочее файловое хранилище — для локального
мессенджера полноценная СУБД избыточна.
"""

from __future__ import annotations

import json
import threading
import time
from pathlib import Path
from typing import Any

from .config import CONFIG


class HistoryStore:
    """Хранит историю сообщений по одному JSON-файлу на каждого собеседника."""

    def __init__(self):
        CONFIG.ensure_dirs()
        self._lock = threading.Lock()

    def _path_for(self, peer_name: str) -> Path:
        safe_name = "".join(c for c in peer_name if c.isalnum() or c in "-_") or "unknown"
        return CONFIG.history_dir / f"{safe_name}.jsonl"

    def append(
        self,
        peer_name: str,
        direction: str,
        text: str,
        timestamp: float | None = None,
        kind: str = "text",
        meta: dict[str, Any] | None = None,
    ) -> None:
        """
        direction: 'out' (мы отправили) или 'in' (мы получили).
        kind: 'text' (обычное сообщение, по умолчанию) или 'file' (вложение -
        фото/видео/произвольный файл); meta для 'file' содержит хотя бы
        filename/size/mime, чтобы веб-интерфейс мог отрисовать превью после
        перезагрузки страницы. Старые записи без kind/meta по-прежнему читаются
        нормально - JS-клиент трактует отсутствие kind как 'text'.
        """
        record: dict[str, Any] = {
            "direction": direction,
            "text": text,
            "timestamp": timestamp if timestamp is not None else time.time(),
        }
        if kind != "text":
            record["kind"] = kind
        if meta:
            record["meta"] = meta
        path = self._path_for(peer_name)
        with self._lock:
            with path.open("a", encoding="utf-8") as f:
                f.write(json.dumps(record, ensure_ascii=False) + "\n")

    def read_all(self, peer_name: str) -> list[dict[str, Any]]:
        path = self._path_for(peer_name)
        if not path.exists():
            return []
        with self._lock:
            lines = path.read_text(encoding="utf-8").splitlines()
        return [json.loads(line) for line in lines if line.strip()]


class ContactsStore:
    """Хранит известные контакты: имя -> {address, tcp_port, public_key_pem}."""

    def __init__(self):
        CONFIG.ensure_dirs()
        self._lock = threading.Lock()
        self._path = CONFIG.contacts_file
        if not self._path.exists():
            self._write({})

    def _read(self) -> dict[str, Any]:
        if not self._path.exists():
            return {}
        return json.loads(self._path.read_text(encoding="utf-8") or "{}")

    def _write(self, data: dict[str, Any]) -> None:
        self._path.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")

    def upsert(self, name: str, address: str, tcp_port: int, public_key_pem: str | None = None) -> None:
        with self._lock:
            data = self._read()
            entry = data.get(name, {})
            entry.update(
                {
                    "address": address,
                    "tcp_port": tcp_port,
                    "public_key_pem": public_key_pem or entry.get("public_key_pem"),
                    "last_seen": time.time(),
                }
            )
            data[name] = entry
            self._write(data)

    def get(self, name: str) -> dict[str, Any] | None:
        with self._lock:
            return self._read().get(name)

    def all(self) -> dict[str, Any]:
        with self._lock:
            return self._read()


class FavoritesStore:
    """
    Избранные контакты, отдельно для каждого локального аккаунта (ключ -
    ник владельца списка). Файл общий на всех локальных пользователей
    машины, как accounts.json/contacts.json - см. config.py.
    """

    def __init__(self):
        CONFIG.ensure_dirs()
        self._lock = threading.Lock()
        self._path = CONFIG.data_dir / "favorites.json"
        if not self._path.exists():
            self._write({})

    def _read(self) -> dict[str, list[str]]:
        if not self._path.exists():
            return {}
        return json.loads(self._path.read_text(encoding="utf-8") or "{}")

    def _write(self, data: dict[str, list[str]]) -> None:
        self._path.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")

    def list_for(self, owner: str) -> list[str]:
        with self._lock:
            return list(self._read().get(owner.lower(), []))

    def add(self, owner: str, peer_name: str) -> list[str]:
        with self._lock:
            data = self._read()
            key = owner.lower()
            names = data.setdefault(key, [])
            if peer_name not in names:
                names.append(peer_name)
            self._write(data)
            return list(names)

    def remove(self, owner: str, peer_name: str) -> list[str]:
        with self._lock:
            data = self._read()
            key = owner.lower()
            names = [n for n in data.get(key, []) if n != peer_name]
            data[key] = names
            self._write(data)
            return list(names)


class GroupsStore:
    """
    Группы и каналы. Хранятся в общем файле groups.json (записи с уникальным
    id). Разница группы и канала - только в правиле "кто может писать"
    (проверяется на веб-уровне в webapp.py): в канале писать может только
    владелец, в группе - любой участник. Само распространение сообщений
    по участникам тоже делает веб-слой (fan-out поверх Peer.send_chat) -
    протокол и ядро P2P-узла (peer.py/network.py/protocol.py) для этого
    не меняются.
    """

    def __init__(self):
        CONFIG.ensure_dirs()
        self._lock = threading.Lock()
        self._path = CONFIG.data_dir / "groups.json"
        if not self._path.exists():
            self._write({})

    def _read(self) -> dict[str, Any]:
        if not self._path.exists():
            return {}
        return json.loads(self._path.read_text(encoding="utf-8") or "{}")

    def _write(self, data: dict[str, Any]) -> None:
        self._path.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")

    def create(self, name: str, kind: str, owner: str, members: list[str]) -> dict[str, Any]:
        import uuid

        with self._lock:
            data = self._read()
            gid = uuid.uuid4().hex[:12]
            members_set = sorted({owner, *members})
            entry = {
                "id": gid,
                "name": name,
                "kind": kind,  # 'group' | 'channel'
                "owner": owner,
                "members": members_set,
                "created_at": time.time(),
            }
            data[gid] = entry
            self._write(data)
            return entry

    def get(self, gid: str) -> dict[str, Any] | None:
        with self._lock:
            return self._read().get(gid)

    def for_member(self, member: str) -> list[dict[str, Any]]:
        with self._lock:
            data = self._read()
        return [g for g in data.values() if member in g.get("members", [])]

    def add_member(self, gid: str, member: str) -> dict[str, Any] | None:
        with self._lock:
            data = self._read()
            entry = data.get(gid)
            if entry is None:
                return None
            if member not in entry["members"]:
                entry["members"].append(member)
                entry["members"].sort()
            data[gid] = entry
            self._write(data)
            return entry

    def remove_member(self, gid: str, member: str) -> dict[str, Any] | None:
        with self._lock:
            data = self._read()
            entry = data.get(gid)
            if entry is None:
                return None
            entry["members"] = [m for m in entry["members"] if m != member]
            data[gid] = entry
            self._write(data)
            return entry

    def delete(self, gid: str) -> None:
        with self._lock:
            data = self._read()
            data.pop(gid, None)
            self._write(data)
