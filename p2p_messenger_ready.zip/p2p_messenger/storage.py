"""
Хранилище: история переписки и список контактов на диске (JSON).

Простое, но полностью рабочее файловое хранилище — для локального
мессенджера полноценная СУБД избыточна.
"""

from __future__ import annotations

import json
import threading
import time
from pathlib import Path
from typing import Any

from .config import CONFIG


class HistoryStore:
    """Хранит историю сообщений по одному JSON-файлу на каждого собеседника."""

    def __init__(self):
        CONFIG.ensure_dirs()
        self._lock = threading.Lock()

    def _path_for(self, peer_name: str) -> Path:
        safe_name = "".join(c for c in peer_name if c.isalnum() or c in "-_") or "unknown"
        return CONFIG.history_dir / f"{safe_name}.jsonl"

    def append(self, peer_name: str, direction: str, text: str, timestamp: float | None = None) -> None:
        """direction: 'out' (мы отправили) или 'in' (мы получили)."""
        record = {
            "direction": direction,
            "text": text,
            "timestamp": timestamp if timestamp is not None else time.time(),
        }
        path = self._path_for(peer_name)
        with self._lock:
            with path.open("a", encoding="utf-8") as f:
                f.write(json.dumps(record, ensure_ascii=False) + "\n")

    def read_all(self, peer_name: str) -> list[dict[str, Any]]:
        path = self._path_for(peer_name)
        if not path.exists():
            return []
        with self._lock:
            lines = path.read_text(encoding="utf-8").splitlines()
        return [json.loads(line) for line in lines if line.strip()]


class ContactsStore:
    """Хранит известные контакты: имя -> {address, tcp_port, public_key_pem}."""

    def __init__(self):
        CONFIG.ensure_dirs()
        self._lock = threading.Lock()
        self._path = CONFIG.contacts_file
        if not self._path.exists():
            self._write({})

    def _read(self) -> dict[str, Any]:
        if not self._path.exists():
            return {}
        return json.loads(self._path.read_text(encoding="utf-8") or "{}")

    def _write(self, data: dict[str, Any]) -> None:
        self._path.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")

    def upsert(self, name: str, address: str, tcp_port: int, public_key_pem: str | None = None) -> None:
        with self._lock:
            data = self._read()
            entry = data.get(name, {})
            entry.update(
                {
                    "address": address,
                    "tcp_port": tcp_port,
                    "public_key_pem": public_key_pem or entry.get("public_key_pem"),
                    "last_seen": time.time(),
                }
            )
            data[name] = entry
            self._write(data)

    def get(self, name: str) -> dict[str, Any] | None:
        with self._lock:
            return self._read().get(name)

    def all(self) -> dict[str, Any]:
        with self._lock:
            return self._read()
