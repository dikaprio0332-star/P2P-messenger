"""
Протокол сетевого обмена.

Формат кадра на "проводе":

    [4 байта big-endian: длина полезной нагрузки N] [N байт JSON UTF-8]

Такое кадрирование (length-prefixed framing) решает классическую проблему
TCP - "склеивание"/"разрыв" сообщений в потоке байт: получатель сначала
читает 4 байта длины, затем ровно столько байт, сколько нужно, независимо
от того, как ОС разбила данные на TCP-пакеты.

Все сообщения — это словари с обязательным полем "type".
"""

from __future__ import annotations

import json
import struct
import time
import uuid
from dataclasses import dataclass, field, asdict
from enum import Enum
from typing import Any, Optional

HEADER_SIZE = 4  # bytes, unsigned int, big-endian


class MessageType(str, Enum):
    HELLO = "hello"                # первичное рукопожатие, обмен именами/публичными ключами
    HELLO_ACK = "hello_ack"        # подтверждение рукопожатия
    KEY_EXCHANGE = "key_exchange"  # передача AES-ключа сессии, зашифрованного RSA
    CHAT = "chat"                  # обычное текстовое сообщение (зашифровано)
    FILE_OFFER = "file_offer"      # предложение передать файл
    FILE_CHUNK = "file_chunk"      # кусок файла (base64, зашифрован)
    FILE_DONE = "file_done"        # конец передачи файла
    ACK = "ack"                    # подтверждение доставки
    PING = "ping"
    PONG = "pong"
    ERROR = "error"
    BYE = "bye"                    # корректное закрытие соединения


class ProtocolError(Exception):
    """Ошибка формата протокола (битые данные, превышен лимит и т.п.)."""


@dataclass
class Envelope:
    """Универсальный конверт сообщения, передаваемого между пирами."""

    type: str
    payload: dict[str, Any] = field(default_factory=dict)
    msg_id: str = field(default_factory=lambda: uuid.uuid4().hex)
    timestamp: float = field(default_factory=time.time)
    sender: Optional[str] = None

    def to_bytes(self) -> bytes:
        raw = json.dumps(asdict(self), ensure_ascii=False).encode("utf-8")
        return struct.pack("!I", len(raw)) + raw

    @staticmethod
    def from_dict(data: dict[str, Any]) -> "Envelope":
        return Envelope(
            type=data["type"],
            payload=data.get("payload", {}),
            msg_id=data.get("msg_id", uuid.uuid4().hex),
            timestamp=data.get("timestamp", time.time()),
            sender=data.get("sender"),
        )


def pack(envelope: Envelope) -> bytes:
    """Сериализовать Envelope в байты, готовые к отправке в сокет."""
    return envelope.to_bytes()


def read_exact(recv_callable, n: int) -> bytes:
    """
    Прочитать из сокета ровно n байт, накапливая по частям.

    recv_callable — функция вида sock.recv(bufsize) -> bytes.
    Бросает ProtocolError, если соединение закрылось раньше времени.
    """
    chunks = []
    remaining = n
    while remaining > 0:
        chunk = recv_callable(remaining)
        if not chunk:
            raise ProtocolError("Соединение закрыто во время чтения кадра")
        chunks.append(chunk)
        remaining -= len(chunk)
    return b"".join(chunks)


def unpack_stream(recv_callable, max_size: int) -> Envelope:
    """
    Прочитать один полный Envelope из потокового сокета.

    Использует read_exact дважды: сперва заголовок длины, потом сама
    полезная нагрузка ровно указанной длины.
    """
    header = read_exact(recv_callable, HEADER_SIZE)
    (length,) = struct.unpack("!I", header)
    if length <= 0 or length > max_size:
        raise ProtocolError(f"Некорректная длина сообщения: {length}")
    raw = read_exact(recv_callable, length)
    try:
        data = json.loads(raw.decode("utf-8"))
    except (json.JSONDecodeError, UnicodeDecodeError) as exc:
        raise ProtocolError(f"Некорректный JSON во входящем сообщении: {exc}") from exc
    return Envelope.from_dict(data)
