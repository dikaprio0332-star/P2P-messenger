"""
Криптографический слой.

Схема (классический гибридный шифр, как в TLS):

1. У каждого узла есть долговременная пара RSA-ключей (генерируется один раз
   и кэшируется на диске).
2. При установлении соединения узлы обмениваются публичными RSA-ключами.
3. Инициатор соединения генерирует случайный сессионный AES-256 ключ,
   шифрует его публичным RSA-ключом собеседника (RSA-OAEP) и отправляет.
4. Дальше вся переписка внутри сессии шифруется симметрично AES-256-GCM
   (быстро + аутентификация целостности "из коробки" через тег GCM).

Пароль аккаунта — не просто "замок на входе": он используется как ключ,
которым на диске зашифрован приватный RSA-ключ пользователя (AES-256-GCM,
ключ шифрования выводится из пароля через PBKDF2-HMAC-SHA256 с солью).
Это значит, что без правильного пароля приватный ключ невозможно
использовать, даже если получить доступ к файлам на диске.

Само содержимое сообщений (текст чата и файловые чанки) шифруется классом
CascadeCipher: КАЖДОЕ сообщение, даже одно короткое, проходит через 5
независимых методов шифрования подряд (AES-256-GCM, ChaCha20-Poly1305,
AES-256-CBC+HMAC, Camellia-256-CBC+HMAC, AES-256-CTR+HMAC) - подробности
и обоснование см. в комментарии перед классом CascadeCipher ниже.

Используется библиотека `cryptography` (реализация OpenSSL), а не
самописные примитивы — это осознанный выбор: писать свою криптографию
небезопасно и не нужно.
"""

from __future__ import annotations

import hashlib
import os
from pathlib import Path
from typing import Tuple

from cryptography.hazmat.primitives import hashes, hmac, padding as sym_padding, serialization
from cryptography.hazmat.primitives.asymmetric import padding, rsa
from cryptography.hazmat.primitives.ciphers import Cipher, algorithms, modes
from cryptography.hazmat.primitives.ciphers.aead import AESGCM, ChaCha20Poly1305
from cryptography.hazmat.primitives.kdf.hkdf import HKDF

from .config import CONFIG

# ВАЖНО: buildozer.spec намеренно не пинит версию `cryptography` (см. коммент
# там же) — из-за этого p4a подтягивает свой собственный recipe, который на
# практике собирает старую cryptography 2.8 (2019 год). В этой версии
# `rsa.generate_private_key()`, `serialization.load_pem_private_key()` и
# `serialization.load_pem_public_key()` ещё требуют ОБЯЗАТЕЛЬНЫЙ позиционный
# аргумент `backend` — без него на Android при первой попытке
# зарегистрироваться/войти (в load_or_create_rsa_keypair) сразу летит
# `TypeError: ...() missing 1 required positional argument: 'backend'`,
# и приложение вылетает. В cryptography 3.1+ backend необязателен, но
# явно передать default_backend() безопасно и на новых версиях тоже
# (просто игнорируется/deprecation-warning), поэтому это кросс-версийный фикс.
try:
    from cryptography.hazmat.backends import default_backend

    _BACKEND = default_backend()
except ImportError:  # на будущих версиях cryptography backends может не быть вовсе
    _BACKEND = None


def _with_backend(kwargs: dict) -> dict:
    if _BACKEND is not None:
        kwargs["backend"] = _BACKEND
    return kwargs

NONCE_SIZE = 12  # рекомендованный размер nonce для AES-GCM
PBKDF2_ITERATIONS = 200_000


class CryptoError(Exception):
    """Ошибка на криптографическом уровне (не удалось расшифровать и т.п.)."""


# --------------------------------------------------------------------------- #
# Вывод ключа из пароля (используется и для account-auth, и для шифрования
# приватного ключа на диске)
# --------------------------------------------------------------------------- #

def derive_key_from_password(password: str, salt: bytes, length: int = 32) -> bytes:
    """PBKDF2-HMAC-SHA256: превращает пароль + соль в криптографический ключ."""
    return hashlib.pbkdf2_hmac("sha256", password.encode("utf-8"), salt, PBKDF2_ITERATIONS, dklen=length)


# --------------------------------------------------------------------------- #
# RSA: долговременная идентичность узла, приватный ключ хранится на диске
# зашифрованным паролем аккаунта
# --------------------------------------------------------------------------- #

def load_or_create_rsa_keypair(
    identity_name: str,
    password: str,
) -> Tuple[rsa.RSAPrivateKey, rsa.RSAPublicKey]:
    """
    Загрузить пару RSA-ключей узла с диска (расшифровав приватный ключ
    паролем), либо сгенерировать новую пару и сохранить приватный ключ
    зашифрованным этим же паролем. Так связка ник+пароль становится
    настоящей криптографической личностью, а не просто формой входа.
    """
    CONFIG.ensure_dirs()
    priv_path = CONFIG.keys_dir / f"{identity_name}_private.enc"
    pub_path = CONFIG.keys_dir / f"{identity_name}_public.pem"
    salt_path = CONFIG.keys_dir / f"{identity_name}.salt"

    if priv_path.exists() and pub_path.exists() and salt_path.exists():
        salt = salt_path.read_bytes()
        key = derive_key_from_password(password, salt)
        blob = priv_path.read_bytes()
        nonce, ct = blob[:NONCE_SIZE], blob[NONCE_SIZE:]
        try:
            pem_bytes = AESGCM(key).decrypt(nonce, ct, None)
        except Exception as exc:  # noqa: BLE001
            raise CryptoError("Неверный пароль: не удалось расшифровать приватный ключ") from exc
        private_key = serialization.load_pem_private_key(
            pem_bytes, **_with_backend({"password": None})
        )
        public_key = serialization.load_pem_public_key(
            pub_path.read_bytes(), **_with_backend({})
        )
        return private_key, public_key

    private_key = rsa.generate_private_key(
        **_with_backend({"public_exponent": 65537, "key_size": CONFIG.rsa_key_size})
    )
    public_key = private_key.public_key()

    pem_bytes = private_key.private_bytes(
        encoding=serialization.Encoding.PEM,
        format=serialization.PrivateFormat.PKCS8,
        encryption_algorithm=serialization.NoEncryption(),
    )
    salt = os.urandom(16)
    key = derive_key_from_password(password, salt)
    nonce = os.urandom(NONCE_SIZE)
    ct = AESGCM(key).encrypt(nonce, pem_bytes, None)

    salt_path.write_bytes(salt)
    priv_path.write_bytes(nonce + ct)
    pub_path.write_bytes(
        public_key.public_bytes(
            encoding=serialization.Encoding.PEM,
            format=serialization.PublicFormat.SubjectPublicKeyInfo,
        )
    )
    # На unix-подобных системах ограничиваем доступ к файлам ключа.
    for p in (priv_path, salt_path):
        try:
            os.chmod(p, 0o600)
        except OSError:
            pass
    return private_key, public_key


def public_key_to_pem(public_key: rsa.RSAPublicKey) -> str:
    return public_key.public_bytes(
        encoding=serialization.Encoding.PEM,
        format=serialization.PublicFormat.SubjectPublicKeyInfo,
    ).decode("ascii")


def public_key_from_pem(pem: str) -> rsa.RSAPublicKey:
    return serialization.load_pem_public_key(pem.encode("ascii"), **_with_backend({}))


def rsa_encrypt(public_key: rsa.RSAPublicKey, data: bytes) -> bytes:
    return public_key.encrypt(
        data,
        padding.OAEP(
            mgf=padding.MGF1(algorithm=hashes.SHA256()),
            algorithm=hashes.SHA256(),
            label=None,
        ),
    )


def rsa_decrypt(private_key: rsa.RSAPrivateKey, data: bytes) -> bytes:
    try:
        return private_key.decrypt(
            data,
            padding.OAEP(
                mgf=padding.MGF1(algorithm=hashes.SHA256()),
                algorithm=hashes.SHA256(),
                label=None,
            ),
        )
    except ValueError as exc:
        raise CryptoError(f"Не удалось расшифровать RSA-payload: {exc}") from exc


# --------------------------------------------------------------------------- #
# AES-GCM: шифрование трафика внутри установленной сессии
# --------------------------------------------------------------------------- #

def generate_session_key() -> bytes:
    return AESGCM.generate_key(bit_length=CONFIG.aes_key_size * 8)


class SessionCipher:
    """Обёртка над AES-GCM для конкретной сессии с одним пиром."""

    def __init__(self, key: bytes):
        self._aead = AESGCM(key)

    def encrypt(self, plaintext: bytes, associated_data: bytes | None = None) -> str:
        """Возвращает base64-независимую hex-строку 'nonce:ciphertext'."""
        nonce = os.urandom(NONCE_SIZE)
        ct = self._aead.encrypt(nonce, plaintext, associated_data)
        return (nonce + ct).hex()

    def decrypt(self, blob_hex: str, associated_data: bytes | None = None) -> bytes:
        try:
            blob = bytes.fromhex(blob_hex)
            nonce, ct = blob[:NONCE_SIZE], blob[NONCE_SIZE:]
            return self._aead.decrypt(nonce, ct, associated_data)
        except Exception as exc:  # noqa: BLE001 - хотим обернуть любую ошибку
            raise CryptoError(f"Не удалось расшифровать сообщение: {exc}") from exc


# --------------------------------------------------------------------------- #
# Каскадное шифрование: 5 независимых методов подряд поверх одной сессии
#
# Один сессионный ключ (см. generate_session_key) через HKDF-SHA256
# разворачивается в 5 отдельных подключей — по одному на каждый метод.
# Компрометация/слабость в одном отдельно взятом алгоритме не вскрывает
# сообщение целиком, пока не сломаны все пять сразу ("оборонительная
# глубина", тот же принцип, что у cascade-шифров вроде AES+Serpent+Twofish
# в VeraCrypt). Каскад применяется к КАЖДОМУ сообщению одинаково — даже
# если это одно-единственное короткое чат-сообщение, а не поток файлов:
# экономии на "коротких" сообщениях сознательно нет, т.к. это ослабило бы
# именно то, что чаще всего и передаётся - текст.
#
# Порядок слоёв (снаружи внутрь при шифровании, реверс при расшифровке):
#   1. AES-256-GCM              (AEAD)
#   2. ChaCha20-Poly1305        (AEAD, независимый от AES дизайн шифра)
#   3. AES-256-CBC + HMAC-SHA256    (Encrypt-then-MAC, классическая схема)
#   4. Camellia-256-CBC + HMAC-SHA256 (Encrypt-then-MAC, другой блочный шифр)
#   5. AES-256-CTR + HMAC-SHA256     (Encrypt-then-MAC, поточный режим)
# --------------------------------------------------------------------------- #

_CASCADE_LAYERS = 5


def _hkdf_bytes(master_key: bytes, info: bytes, length: int) -> bytes:
    """Разворачивает мастер-ключ сессии в независимый подключ нужной длины
    (HKDF-SHA256, RFC 5869). `info` - метка слоя, гарантирует, что ключи
    разных слоёв каскада никак не связаны между собой."""
    return HKDF(algorithm=hashes.SHA256(), length=length, salt=None, info=info, **_with_backend({})).derive(
        master_key
    )


def _pkcs7_pad(data: bytes, block_size_bytes: int = 16) -> bytes:
    padder = sym_padding.PKCS7(block_size_bytes * 8).padder()
    return padder.update(data) + padder.finalize()


def _pkcs7_unpad(data: bytes, block_size_bytes: int = 16) -> bytes:
    unpadder = sym_padding.PKCS7(block_size_bytes * 8).unpadder()
    return unpadder.update(data) + unpadder.finalize()


def _aead_layer_encrypt(aead, plaintext: bytes) -> bytes:
    nonce = os.urandom(NONCE_SIZE)
    return nonce + aead.encrypt(nonce, plaintext, None)


def _aead_layer_decrypt(aead, blob: bytes, layer_name: str) -> bytes:
    try:
        nonce, ct = blob[:NONCE_SIZE], blob[NONCE_SIZE:]
        return aead.decrypt(nonce, ct, None)
    except Exception as exc:  # noqa: BLE001
        raise CryptoError(f"Каскад: слой {layer_name} не расшифрован") from exc


def _etm_encrypt(enc_key: bytes, mac_key: bytes, plaintext: bytes, algorithm_cls, pad: bool) -> bytes:
    """Encrypt-then-MAC: IV + шифртекст + HMAC-SHA256(IV || шифртекст)."""
    iv = os.urandom(16)
    data = _pkcs7_pad(plaintext) if pad else plaintext
    encryptor = Cipher(algorithm_cls(enc_key), modes.CBC(iv) if pad else modes.CTR(iv), **_with_backend({})).encryptor()
    ct = encryptor.update(data) + encryptor.finalize()
    tag = hmac.HMAC(mac_key, hashes.SHA256(), **_with_backend({}))
    tag.update(iv + ct)
    return iv + ct + tag.finalize()


def _etm_decrypt(enc_key: bytes, mac_key: bytes, blob: bytes, algorithm_cls, pad: bool, layer_name: str) -> bytes:
    try:
        iv, ct, received_tag = blob[:16], blob[16:-32], blob[-32:]
        tag = hmac.HMAC(mac_key, hashes.SHA256(), **_with_backend({}))
        tag.update(iv + ct)
        tag.verify(received_tag)  # бросает InvalidSignature при подмене/повреждении
        decryptor = Cipher(
            algorithm_cls(enc_key), modes.CBC(iv) if pad else modes.CTR(iv), **_with_backend({})
        ).decryptor()
        data = decryptor.update(ct) + decryptor.finalize()
        return _pkcs7_unpad(data) if pad else data
    except Exception as exc:  # noqa: BLE001
        raise CryptoError(f"Каскад: слой {layer_name} не расшифрован (подмена данных или неверный ключ)") from exc


class CascadeCipher:
    """
    Шифрует каждое сообщение сессии сразу пятью независимыми методами
    подряд (см. пояснение выше). Публичный интерфейс намеренно такой же,
    как у SessionCipher (encrypt/decrypt), чтобы использоваться в качестве
    прямой замены на уровне PeerSession.
    """

    def __init__(self, session_key: bytes):
        # Пять независимых подключей, каждый выведен из одного и того же
        # сессионного ключа своей уникальной меткой - слои криптографически
        # не связаны друг с другом.
        self._k1 = _hkdf_bytes(session_key, b"cascade-layer-1-aes256gcm", 32)
        self._k2 = _hkdf_bytes(session_key, b"cascade-layer-2-chacha20poly1305", 32)
        self._k3_enc = _hkdf_bytes(session_key, b"cascade-layer-3-aes256cbc-enc", 32)
        self._k3_mac = _hkdf_bytes(session_key, b"cascade-layer-3-aes256cbc-mac", 32)
        self._k4_enc = _hkdf_bytes(session_key, b"cascade-layer-4-camellia256cbc-enc", 32)
        self._k4_mac = _hkdf_bytes(session_key, b"cascade-layer-4-camellia256cbc-mac", 32)
        self._k5_enc = _hkdf_bytes(session_key, b"cascade-layer-5-aes256ctr-enc", 32)
        self._k5_mac = _hkdf_bytes(session_key, b"cascade-layer-5-aes256ctr-mac", 32)

    def encrypt(self, plaintext: bytes, associated_data: bytes | None = None) -> str:
        """
        Прогоняет сообщение через все 5 методов по очереди и возвращает
        единую hex-строку. associated_data (если передан) подмешивается
        только в самый внешний слой (AES-256-GCM) - он же расшифровывается
        первым и сразу проверит его подлинность при чтении.
        """
        blob = plaintext
        blob = _aead_layer_encrypt(ChaCha20Poly1305(self._k2), blob)
        blob = _etm_encrypt(self._k3_enc, self._k3_mac, blob, algorithms.AES256, pad=True)
        blob = _etm_encrypt(self._k4_enc, self._k4_mac, blob, algorithms.Camellia, pad=True)
        blob = _etm_encrypt(self._k5_enc, self._k5_mac, blob, algorithms.AES256, pad=False)
        nonce = os.urandom(NONCE_SIZE)
        blob = nonce + AESGCM(self._k1).encrypt(nonce, blob, associated_data)
        return blob.hex()

    def decrypt(self, blob_hex: str, associated_data: bytes | None = None) -> bytes:
        """Разворачивает все 5 слоёв в обратном порядке (снаружи внутрь)."""
        blob = bytes.fromhex(blob_hex)
        try:
            nonce, ct = blob[:NONCE_SIZE], blob[NONCE_SIZE:]
            blob = AESGCM(self._k1).decrypt(nonce, ct, associated_data)
        except Exception as exc:  # noqa: BLE001
            raise CryptoError("Каскад: слой 1 (AES-256-GCM) не расшифрован") from exc
        blob = _etm_decrypt(self._k5_enc, self._k5_mac, blob, algorithms.AES256, pad=False, layer_name="2 (AES-256-CTR)")
        blob = _etm_decrypt(self._k4_enc, self._k4_mac, blob, algorithms.Camellia, pad=True, layer_name="3 (Camellia-256-CBC)")
        blob = _etm_decrypt(self._k3_enc, self._k3_mac, blob, algorithms.AES256, pad=True, layer_name="4 (AES-256-CBC)")
        blob = _aead_layer_decrypt(ChaCha20Poly1305(self._k2), blob, "5 (ChaCha20-Poly1305)")
        return blob
