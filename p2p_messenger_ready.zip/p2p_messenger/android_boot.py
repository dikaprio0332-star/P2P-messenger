"""
Отдельная точка входа для Android-сборки (buildozer, p4a.bootstrap = webview).

КЛЮЧЕВОЕ ОТЛИЧИЕ от предыдущей версии: этот модуль импортирует ТОЛЬКО
стандартную библиотеку Python (threading, http.server, traceback, ...) —
ни Flask, ни cryptography, ни остальной пакет p2p_messenger здесь на
верхнем уровне не импортируются. Поэтому сам этот модуль физически не
может упасть при импорте.

Почему это важно. Раньше main.py делал так:

    if "ANDROID_ARGUMENT" in os.environ:
        from p2p_messenger.webapp import run_android_webapp
        sys.exit(run_android_webapp())

Импорт "p2p_messenger.webapp" транзитивно тянет за собой auth.py -> peer.py
-> crypto_utils.py -> cryptography (нативный, собранный p4a-рецептом
модуль). Если на КОНКРЕТНОМ телефоне этот нативный модуль не грузится
(несовпадение ABI, битая линковка .so — частая история именно для
cryptography под Android), процесс падает ИМЕННО на этой строке импорта —
то есть ещё до того, как успевает запуститься любая защита от сбоев,
написанная внутри webapp.py. WebView в этот момент ещё даже не пытался
ничего загрузить (или уже пытался и получил отказ) — а системный
Loading-экран p4a остаётся висеть навсегда, потому что процессу больше
некому сказать WebView, что делать дальше.

Решение: поднять HTTP-заглушку на 127.0.0.1:5000 ДО этого рискованного
импорта, средствами, которые гарантированно есть в любом Python (стандартная
библиотека). Тогда WebView гарантированно получает ответ с первой же
попытки, а если импорт или инициализация всё-таки упадут — тот же самый
сервер покажет traceback вместо вечной загрузки.
"""

from __future__ import annotations

import logging
import sys
import threading
import time
import traceback
from html import escape
from http.server import BaseHTTPRequestHandler, HTTPServer
from typing import Any, Optional

logger = logging.getLogger("p2p_messenger.android_boot")

HOST = "127.0.0.1"
PORT = 5000

# ------------------------------------------------------------------------- #
# Пошаговый файловый лог загрузки.
#
# ПОЧЕМУ ЭТО ДОБАВЛЕНО: раньше при зависании (не исключении) мы могли
# показать только "где-то внутри import/create_app()" — стек потока в
# момент истечения тайм-аута, но не историю ДО этого момента. Если
# зависание вызвано тем, что нативный код держит GIL не отпуская его, то
# даже HTTP-заглушка на порту 5000 может не успевать отвечать (см. также
# /__boot_log ниже — по тому, отвечает он или нет, можно отличить "завис
# только импорт" от "завис вообще весь процесс"). Каждый шаг импорта
# логируется В ФАЙЛ (не только в logcat, который на телефоне без adb не
# посмотреть) сразу же, с flush — так что даже если после какого-то шага
# всё намертво зависнет, в файле останется точная отметка последнего
# УСПЕШНО завершившегося шага, а значит — и то, на каком шаге застряли.
# Это ДОБАВЛЕНИЕ, а не изменение существующей логики импорта/тайм-аута —
# ничего в поведении загрузки не меняется, только видимость происходящего.
_LOG_PATH = None
try:
    import os as _os

    _log_dir = _os.environ.get("ANDROID_PRIVATE") or _os.environ.get("ANDROID_ARGUMENT") or "."
    _LOG_PATH = _os.path.join(_log_dir, "boot_debug.log")
except Exception:  # noqa: BLE001 - логирование не должно само стать причиной сбоя
    _LOG_PATH = None


def _debug_log(msg: str) -> None:
    line = "%s %s\n" % (time.strftime("%H:%M:%S"), msg)
    try:
        logger.info(msg)
    except Exception:  # noqa: BLE001
        pass
    if not _LOG_PATH:
        return
    try:
        with open(_LOG_PATH, "a", encoding="utf-8") as f:
            f.write(line)
            f.flush()
            _os.fsync(f.fileno())
    except Exception:  # noqa: BLE001
        pass

# Сколько ждать "from .webapp import create_app" + create_app() до того,
# как считать это зависанием (а не просто медленным стартом) и показать
# диагностику вместо бесконечного "Запуск узла…". По наблюдениям на
# реальных устройствах инициализация занимает <1с; 12с — большой запас.
INIT_TIMEOUT_SEC = 12.0

# ВИДИМАЯ на экране метка версии этого файла. ЕДИНСТВЕННАЯ цель — чтобы
# при пересборке было видно ГЛАЗАМИ, попал ли новый android_boot.py в APK,
# без adb/unzip/logcat: если после установки новой сборки в правом нижнем
# углу экрана "Запуск узла…" эта строка не изменилась — значит собрался
# и/или установился старый код (проблема кэша buildozer/CI или переустановки
# APK), а не баг в самой логике загрузки. Меняйте эту строку при каждой
# правке файла (например на дату/время правки).
BOOT_CODE_MARKER = "boot-diag-2026-08-27-v3"

_BOOT_PAGE = """<!doctype html>
<html lang="ru"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>WIRE P2P Messenger</title>
<style>
  body{background:#0f0f12;color:#eaeaea;font-family:sans-serif;
       display:flex;align-items:center;justify-content:center;
       height:100vh;margin:0;text-align:center;position:relative}
  .spinner{width:36px;height:36px;border-radius:50%;
           border:3px solid #333;border-top-color:#7c7cff;
           animation:spin 0.8s linear infinite;margin:0 auto 16px}
  @keyframes spin{to{transform:rotate(360deg)}}
  #elapsed{margin-top:8px;color:#888;font-size:12px}
  #marker{position:fixed;right:8px;bottom:8px;color:#444;font-size:10px;
          font-family:monospace}
</style></head>
<body><div>
  <div class="spinner"></div>
  <div>Запуск узла…</div>
  <div id="elapsed">0 сек</div>
  <div style="margin-top:14px"><a href="/__boot_log" style="color:#7c7cff;font-size:12px">Показать лог загрузки</a></div>
</div>
<div id="marker">__MARKER__</div>
<script>
var t0 = Date.now();
var elapsedEl = document.getElementById('elapsed');
(function poll(){
  elapsedEl.textContent = Math.round((Date.now() - t0) / 1000) + ' сек';
  fetch('/__boot_status', {cache:'no-store'}).then(function(r){return r.json();}).then(function(d){
    if (d.status === 'ready') { location.replace(d.redirect || '/'); }
    else if (d.status === 'error') { location.reload(); }
    else { setTimeout(poll, 400); }
  }).catch(function(){ setTimeout(poll, 600); });
})();
</script></body></html>""".replace("__MARKER__", BOOT_CODE_MARKER)


def _error_page(tb: str) -> str:
    return (
        "<!doctype html><html lang=\"ru\"><head><meta charset=\"utf-8\">"
        "<meta name=\"viewport\" content=\"width=device-width, initial-scale=1\">"
        "<title>Ошибка запуска</title>"
        "<style>body{background:#1a0f0f;color:#f4d6d6;font-family:monospace;"
        "font-size:13px;padding:16px;white-space:pre-wrap;word-break:break-word}"
        "h1{color:#ff8080;font-size:16px;font-family:sans-serif}"
        "button{margin-top:12px;padding:8px 14px;font-size:14px}"
        "#marker{position:fixed;right:8px;bottom:8px;color:#663;font-size:10px;"
        "font-family:monospace}</style></head>"
        "<body><h1>Не удалось запустить узел</h1><pre id=\"tb\">" + escape(tb) + "</pre>"
        "<button onclick=\"navigator.clipboard&&navigator.clipboard.writeText("
        "document.getElementById('tb').innerText)\">Скопировать текст ошибки</button>"
        "<div id=\"marker\">" + escape(BOOT_CODE_MARKER) + "</div>"
        "</body></html>"
    )


class _BootHandler(BaseHTTPRequestHandler):
    """Обслуживает и /__boot_status (JSON для JS-опроса), и саму страницу."""

    protocol_version = "HTTP/1.0"  # без keep-alive — сокет освобождается сразу после ответа
    boot_state: "_BootState"  # выставляется через functools.partial-подобную фабрику ниже

    def _reply(self, body: str, ctype: str = "text/html; charset=utf-8") -> None:
        data = body.encode("utf-8")
        try:
            self.send_response(200)
            self.send_header("Content-Type", ctype)
            self.send_header("Content-Length", str(len(data)))
            self.send_header("Connection", "close")
            self.end_headers()
            self.wfile.write(data)
        except OSError:
            pass

    def do_GET(self) -> None:  # noqa: N802 - имя метода задано BaseHTTPRequestHandler
        state = self.boot_state
        if self.path.startswith("/__boot_status"):
            if state.error:
                status = "error"
            elif state.ready.is_set():
                status = "ready"
            else:
                status = "loading"
            self._reply('{"status": "%s"}' % status, ctype="application/json")
            return
        if self.path.startswith("/__boot_log"):
            # Если ЭТОТ запрос тоже не отвечает (вечно крутится в браузере) —
            # значит завис не только импорт, а весь процесс целиком
            # (GIL занят нативным кодом) — само по себе важный диагноз.
            text = "(лог-файл недоступен: %s)" % _LOG_PATH
            if _LOG_PATH:
                try:
                    with open(_LOG_PATH, "r", encoding="utf-8") as f:
                        text = f.read() or "(лог пуст — ни один шаг ещё не записан)"
                except FileNotFoundError:
                    text = "(лог-файл ещё не создан — ни один шаг не записан)"
                except OSError as exc:
                    text = "(не удалось прочитать лог: %s)" % exc
            self._reply(
                "<pre style='white-space:pre-wrap;word-break:break-word;"
                "font-family:monospace;font-size:12px;padding:12px'>" + escape(text) + "</pre>",
                ctype="text/html; charset=utf-8",
            )
            return
        self._reply(_error_page(state.error) if state.error else _BOOT_PAGE)

    def log_message(self, fmt: str, *args: Any) -> None:
        logger.debug("boot-заглушка: " + fmt, *args)


class _BootState:
    def __init__(self) -> None:
        self.ready = threading.Event()
        self.error: Optional[str] = None


def _make_handler(state: _BootState):
    return type("_BootHandlerBound", (_BootHandler,), {"boot_state": state})


def run_android() -> int:
    logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(levelname)s] %(name)s: %(message)s")

    state = _BootState()
    boot_server = HTTPServer((HOST, PORT), _make_handler(state))
    threading.Thread(target=boot_server.serve_forever, daemon=True).start()
    logger.info("Заглушка запущена на http://%s:%s — WebView получит ответ немедленно.", HOST, PORT)

    # Всё, что может упасть (импорт cryptography/flask, инициализация
    # приложения), — строго внутри этого потока, ПОСЛЕ того как порт уже
    # занят заглушкой. Раньше это делалось прямо в основном потоке внутри
    # try/except: это ловит ИСКЛЮЧЕНИЯ, но не ЗАВИСАНИЯ (если импорт/вызов
    # блокируется навсегда и никогда не бросает исключение — например,
    # нативный .so cryptography стопорится на статической инициализации на
    # конкретном устройстве/ABI — экран висел на "Запуск узла…" бесконечно
    # и без всякой диагностики). Поэтому инициализация теперь выполняется в
    # отдельном daemon-потоке, а основной поток ждёт её не дольше
    # INIT_TIMEOUT_SEC и, если не дождался, сам снимает стек застрявшего
    # потока и показывает его как диагностику вместо вечного спиннера.
    result: dict[str, Any] = {}

    def _init() -> None:
        _debug_log("_init: старт")
        try:
            # Разбито на явные шаги (а не один "from .webapp import create_app")
            # ИСКЛЮЧИТЕЛЬНО ради диагностики: если зависнет — в boot_debug.log
            # (см. /__boot_log) останется точная отметка последнего успешного
            # шага. Сам набор импортов не изменился — .webapp всё равно тянет
            # именно эти модули, здесь они просто явно перечислены по одному.
            _debug_log("шаг 1/6: import flask")
            import flask  # noqa: F401

            _debug_log("шаг 2/6: import cryptography.hazmat.backends")
            from cryptography.hazmat.backends import default_backend  # noqa: F401

            _debug_log("шаг 3/6: cryptography default_backend()")
            default_backend()

            _debug_log("шаг 4/6: import cryptography.hazmat.primitives.asymmetric.rsa")
            from cryptography.hazmat.primitives.asymmetric import rsa  # noqa: F401

            _debug_log("шаг 5/6: import p2p_messenger.webapp (auth/peer/crypto_utils/discovery)")
            from .webapp import create_app

            _debug_log("шаг 6/6: create_app()")
            result["app"] = create_app()
            _debug_log("_init: успешно завершён")
        except Exception:  # noqa: BLE001 - любая ошибка должна быть видна в WebView
            result["error"] = traceback.format_exc()
            _debug_log("_init: ИСКЛЮЧЕНИЕ — %s" % result["error"].splitlines()[-1])
            logger.exception("Не удалось инициализировать приложение на Android")

    init_thread = threading.Thread(target=_init, name="p2p-init", daemon=True)
    init_thread.start()
    init_thread.join(INIT_TIMEOUT_SEC)

    app: Optional[Any] = None
    if init_thread.is_alive():
        # Поток жив спустя тайм-аут -> где-то внутри импорта/create_app()
        # застряли (не исключение). Снимаем стек прямо этого потока по его
        # ident, чтобы увидеть точную строку зависания, а не гадать.
        frame = sys._current_frames().get(init_thread.ident)
        stuck_where = (
            "".join(traceback.format_stack(frame))
            if frame is not None
            else "(не удалось получить стек потока)"
        )
        state.error = (
            "Инициализация не завершилась за {timeout:.0f} секунд — поток застрял "
            "здесь (это не исключение, а зависание):\n\n{stack}\n"
            "Чаще всего причина — нативный модуль cryptography (.so), не "
            "загружающийся на этом устройстве/ABI. Поток продолжает работать "
            "в фоне; если он всё же закончит инициализацию, перезагрузите эту "
            "страницу.".format(timeout=INIT_TIMEOUT_SEC, stack=stuck_where)
        )
        logger.error("Инициализация зависла (поток жив спустя %.0fс):\n%s", INIT_TIMEOUT_SEC, stuck_where)
    elif "error" in result:
        state.error = result["error"]
    else:
        app = result.get("app")

    if app is None:
        if init_thread.is_alive():
            # Не исключение, а именно тайм-аут: поток мог быть просто
            # медленным (не обязательно мёртвым - взаимоблокировкой).
            # Отдельный сторож ждёт его молча в фоне и, если он всё же
            # закончит, доводит загрузку до конца (или показывает
            # финальную ошибку) — тогда "перезагрузить страницу" из
            # сообщения диагностики реально сработает.
            def _watch_late_finish() -> None:
                init_thread.join()  # без тайм-аута — ждём столько, сколько потребуется
                if "error" in result:
                    state.error = result["error"]
                    logger.error("Инициализация всё же завершилась ошибкой (после тайм-аута)")
                    return
                late_app = result.get("app")
                if late_app is not None:
                    logger.info("Инициализация завершилась после тайм-аута — запускаем сервер")
                    _finish_boot(late_app, state, boot_server)

            threading.Thread(target=_watch_late_finish, name="p2p-init-watch", daemon=True).start()
        # Заглушка уже показывает traceback вместо вечного "Loading..." —
        # держим процесс живым, чтобы WebView могла её показать/перечитать.
        while True:
            time.sleep(3600)

    return _finish_boot(app, state, boot_server)


def _finish_boot(app: Any, state: "_BootState", boot_server: HTTPServer) -> int:
    """Переключает порт 5000 с заглушки на настоящее Flask-приложение."""
    state.ready.set()
    boot_server.shutdown()
    boot_server.server_close()

    # Между освобождением порта заглушкой и стартом настоящего Flask-сервера
    # возможен короткий зазор (ОС не всегда мгновенно освобождает сокет) —
    # пробуем несколько раз вместо падения с первого "Address already in use".
    last_exc: Optional[BaseException] = None
    for _ in range(20):
        try:
            app.run(host=HOST, port=PORT, debug=False, use_reloader=False, threaded=True)
            return 0
        except OSError as exc:
            last_exc = exc
            time.sleep(0.2)

    logger.error("Не удалось запустить локальный веб-сервер на %s:%s", HOST, PORT, exc_info=last_exc)
    state.error = (
        "".join(traceback.format_exception(type(last_exc), last_exc, last_exc.__traceback__))
        if last_exc
        else "Не удалось запустить веб-сервер: неизвестная ошибка."
    )
    fallback = HTTPServer((HOST, PORT), _make_handler(state))
    fallback.serve_forever()
    return 1
