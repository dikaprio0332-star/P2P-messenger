"""
Отдельная точка входа для Android-сборки (buildozer, p4a.bootstrap = webview).

v4 — ИЗМЕНЕНИЕ АРХИТЕКТУРЫ ПОСЛЕ РЕАЛЬНОГО ЗАВИСАНИЯ НА УСТРОЙСТВЕ
====================================================================
В v3 риск-импорт (from .webapp import create_app, тянущий cryptography)
выполнялся в отдельном ПОТОКЕ (threading.Thread) внутри того же процесса,
что и HTTP-заглушка "Запуск узла…". Расчёт был на то, что даже если поток
инициализации зависнет навсегда, главный поток дождётся своих 12 секунд
(Thread.join(timeout)) и покажет диагностику вместо вечного спиннера.

Это сработало бы для ЗАВИСАНИЯ НА PYTHON-УРОВНЕ (например, бесконечный
цикл в чистом Python). На практике же реальные зависания cryptography на
Android — это НАТИВНЫЙ код (.so, OpenSSL) внутри C-расширения, который
иногда крутится в busy-loop или блокируется НЕ ОТПУСКАЯ GIL (например,
неудачная попытка получить энтропию через нестандартный на некоторых
устройствах путь). Пока GIL удерживается native-кодом, ЛЮБОЙ другой поток
процесса — включая поток HTTP-заглушки и главный поток с его join(12) —
тоже стоит колом. Отсюда и наблюдавшийся баг: экран "Запуск узла…"
зависал заметно дольше 12 секунд и НЕ переключался на страницу с ошибкой,
хотя код диагностики был на месте и формально должен был сработать —
просто ему самому не давали выполниться.

Поток нельзя принудительно убить в Python. ПРОЦЕСС — можно. Поэтому в v4
риск-импорт и сам Flask-сервер вынесены в ОТДЕЛЬНЫЙ ПРОЦЕСС
(multiprocessing), а не поток:

  - Родительский процесс (этот файл) НИКОГДА не импортирует webapp/
    cryptography сам и висит на порту 127.0.0.1:5000, показывая
    "Запуск узла…" и опрашивая готовность дочернего процесса ЧИСТО
    СНАРУЖИ — обычным TCP-подключением к его порту (127.0.0.1:5001).
    Такая проверка — это системный вызов ОС, а не что-то внутри
    дочернего процесса, поэтому она в принципе не может зависнуть из-за
    проблем в дочернем процессе, даже если там GIL намертво заблокирован
    нативным кодом.
  - Как только дочерний порт начинает принимать соединения, заглушка
    отдаёт JS-опросу redirect на реальный адрес — и WebView переключается
    туда.
  - Если дочерний процесс за INIT_TIMEOUT_SEC не поднялся — а) это могло
    быть зависание (родитель продолжает наблюдение в фоне на случай,
    если оно всё же рассосётся) или б) дочерний процесс мог упасть
    (тогда его exitcode доступен родителю немедленно — в т.ч.
    отрицательный код сигнала, например -11 = SIGSEGV, что прямо
    указывает на нативный сбой, а не на зависание).
  - Пользователю в любом случае показывается страница ошибки с кнопкой
    "Перезапустить узел", которая шлёт дочернему процессу SIGKILL и
    поднимает новый — то, что было в принципе невозможно для потока.
"""

from __future__ import annotations

import logging
import multiprocessing
import socket
import sys
import threading
import time
import traceback
from html import escape
from http.server import BaseHTTPRequestHandler, HTTPServer
from typing import Any, Optional

logger = logging.getLogger("p2p_messenger.android_boot")

HOST = "127.0.0.1"
PORT = 5000          # заглушка / диагностика — здесь и остаётся всегда
CHILD_PORT = 5001     # реальный Flask-сервер поднимается дочерним процессом здесь

# Сколько ждать поднятия дочернего процесса, прежде чем показать
# диагностику вместо бесконечного "Запуск узла…". На реальных устройствах
# инициализация обычно занимает <1с; 12с — большой запас.
INIT_TIMEOUT_SEC = 12.0

BOOT_CODE_MARKER = "boot-diag-2026-08-27-v4"

_BOOT_PAGE = """<!doctype html>
<html lang="ru"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>WIRE P2P Messenger</title>
<style>
  body{background:#0f0f12;color:#eaeaea;font-family:sans-serif;
       display:flex;align-items:center;justify-content:center;
       height:100vh;margin:0;text-align:center;position:relative}
  .spinner{width:36px;height:36px;border-radius:50%;
           border:3px solid #333;border-top-color:#7c7cff;
           animation:spin 0.8s linear infinite;margin:0 auto 16px}
  @keyframes spin{to{transform:rotate(360deg)}}
  #elapsed{margin-top:8px;color:#888;font-size:12px}
  #marker{position:fixed;right:8px;bottom:8px;color:#444;font-size:10px;
          font-family:monospace}
</style></head>
<body><div>
  <div class="spinner"></div>
  <div>Запуск узла…</div>
  <div id="elapsed">0 сек</div>
</div>
<div id="marker">__MARKER__</div>
<script>
var t0 = Date.now();
var elapsedEl = document.getElementById('elapsed');
(function poll(){
  elapsedEl.textContent = Math.round((Date.now() - t0) / 1000) + ' сек';
  fetch('/__boot_status', {cache:'no-store'}).then(function(r){return r.json();}).then(function(d){
    if (d.status === 'ready') { location.replace(d.redirect || '/'); }
    else if (d.status === 'error') { location.reload(); }
    else { setTimeout(poll, 400); }
  }).catch(function(){ setTimeout(poll, 600); });
})();
</script></body></html>""".replace("__MARKER__", BOOT_CODE_MARKER)


def _error_page(tb: str) -> str:
    return (
        "<!doctype html><html lang=\"ru\"><head><meta charset=\"utf-8\">"
        "<meta name=\"viewport\" content=\"width=device-width, initial-scale=1\">"
        "<title>Ошибка запуска</title>"
        "<style>body{background:#1a0f0f;color:#f4d6d6;font-family:monospace;"
        "font-size:13px;padding:16px;white-space:pre-wrap;word-break:break-word}"
        "h1{color:#ff8080;font-size:16px;font-family:sans-serif}"
        "button{margin-top:12px;margin-right:8px;padding:8px 14px;font-size:14px}"
        "#marker{position:fixed;right:8px;bottom:8px;color:#663;font-size:10px;"
        "font-family:monospace}</style></head>"
        "<body><h1>Не удалось запустить узел</h1><pre id=\"tb\">" + escape(tb) + "</pre>"
        "<button onclick=\"navigator.clipboard&&navigator.clipboard.writeText("
        "document.getElementById('tb').innerText)\">Скопировать текст ошибки</button>"
        "<button onclick=\"fetch('/__boot_restart',{method:'POST'}).then(function(){location.reload();})\">"
        "Перезапустить узел</button>"
        "<div id=\"marker\">" + escape(BOOT_CODE_MARKER) + "</div>"
        "</body></html>"
    )


class _BootHandler(BaseHTTPRequestHandler):
    """Обслуживает страницу, /__boot_status (JSON) и /__boot_restart (POST)."""

    protocol_version = "HTTP/1.0"  # без keep-alive — сокет освобождается сразу после ответа
    boot_state: "_BootState"

    def _reply(self, body: str, ctype: str = "text/html; charset=utf-8", code: int = 200) -> None:
        data = body.encode("utf-8")
        try:
            self.send_response(code)
            self.send_header("Content-Type", ctype)
            self.send_header("Content-Length", str(len(data)))
            self.send_header("Connection", "close")
            self.end_headers()
            self.wfile.write(data)
        except OSError:
            pass

    def do_GET(self) -> None:  # noqa: N802
        state = self.boot_state
        if self.path.startswith("/__boot_status"):
            if state.error:
                payload = '{"status": "error"}'
            elif state.ready.is_set():
                payload = '{"status": "ready", "redirect": "http://%s:%s/"}' % (HOST, CHILD_PORT)
            else:
                payload = '{"status": "loading"}'
            self._reply(payload, ctype="application/json")
            return
        self._reply(_error_page(state.error) if state.error else _BOOT_PAGE)

    def do_POST(self) -> None:  # noqa: N802
        if self.path.startswith("/__boot_restart") and self.boot_state.restart is not None:
            self.boot_state.restart()
            self._reply('{"ok": true}', ctype="application/json")
            return
        self._reply('{"ok": false}', ctype="application/json", code=404)

    def log_message(self, fmt: str, *args: Any) -> None:
        logger.debug("boot-заглушка: " + fmt, *args)


class _BootState:
    def __init__(self) -> None:
        self.ready = threading.Event()
        self.error: Optional[str] = None
        self.restart: Optional[Any] = None  # выставляется run_android()


def _make_handler(state: _BootState):
    return type("_BootHandlerBound", (_BootHandler,), {"boot_state": state})


def _run_webapp_process(port: int, error_queue: "multiprocessing.Queue[str]") -> None:
    """Выполняется В ОТДЕЛЬНОМ ПРОЦЕССЕ. Здесь и только здесь происходит
    рискованный импорт (webapp -> auth/peer/crypto_utils -> cryptography).
    Если что-то падает исключением — сообщаем через очередь. Если процесс
    зависнет или упадёт нативно (SIGSEGV и т.п.), об этом расскажет уже
    сам факт его смерти/молчания родителю — эта функция тогда просто
    никогда не вернёт управление или процесс умрёт без сообщения."""
    try:
        from .webapp import create_app

        app = create_app()
    except Exception:  # noqa: BLE001
        error_queue.put(traceback.format_exc())
        return
    try:
        app.run(host=HOST, port=port, debug=False, use_reloader=False, threaded=True)
    except Exception:  # noqa: BLE001
        error_queue.put(traceback.format_exc())


def _spawn_child() -> tuple[multiprocessing.Process, "multiprocessing.Queue[str]"]:
    # fork — самый лёгкий и надёжный способ на Linux/Android (не требует
    # повторного импорта __main__, как spawn); если платформа его не
    # поддерживает, откатываемся на то, что даёт multiprocessing по умолчанию.
    try:
        ctx = multiprocessing.get_context("fork")
    except ValueError:
        ctx = multiprocessing.get_context()
    error_queue: "multiprocessing.Queue[str]" = ctx.Queue()
    child = ctx.Process(target=_run_webapp_process, args=(CHILD_PORT, error_queue), daemon=True)
    child.start()
    return child, error_queue


def _port_open(host: str, port: int, timeout: float = 0.3) -> bool:
    try:
        with socket.create_connection((host, port), timeout=timeout):
            return True
    except OSError:
        return False


def run_android() -> int:
    logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(levelname)s] %(name)s: %(message)s")

    state = _BootState()
    boot_server = HTTPServer((HOST, PORT), _make_handler(state))
    threading.Thread(target=boot_server.serve_forever, daemon=True).start()
    logger.info("Заглушка запущена на http://%s:%s", HOST, PORT)

    child_holder: dict[str, Any] = {}

    def _launch() -> None:
        state.ready.clear()
        state.error = None
        old_child = child_holder.get("child")
        if old_child is not None and old_child.is_alive():
            old_child.kill()
            old_child.join(timeout=2.0)
        child, error_queue = _spawn_child()
        child_holder["child"] = child
        child_holder["error_queue"] = error_queue
        threading.Thread(target=_supervise, args=(child, error_queue), daemon=True).start()

    def _supervise(child: multiprocessing.Process, error_queue: "multiprocessing.Queue[str]") -> None:
        deadline = time.monotonic() + INIT_TIMEOUT_SEC
        result = _wait_for(child, error_queue, deadline)
        if result == "ready":
            state.ready.set()
            return
        if result is not None:  # "error" или "crashed" — сообщение уже в state.error
            return
        # Тайм-аут: продолжаем следить без ограничения по времени — вдруг
        # инициализация всё же медленная, а не мёртвая; страница ошибки уже
        # показана, "Перезапустить узел" пользователь может нажать в любой момент.
        state.error = (
            "Узел не поднялся за {timeout:.0f} секунд.\n\n"
            "Дочерний процесс инициализации (PID {pid}) ещё жив, но не открыл "
            "порт {port} — похоже на зависание внутри нативного модуля "
            "cryptography (частая история для несовпадения ABI/сборки на "
            "конкретном устройстве). Наблюдение продолжается в фоне: если "
            "процесс всё же закончит запуск, обновите эту страницу вручную. "
            "Либо нажмите «Перезапустить узел» ниже.".format(
                timeout=INIT_TIMEOUT_SEC, pid=child.pid, port=CHILD_PORT
            )
        )
        while state.error is not None:
            if _port_open(HOST, CHILD_PORT):
                state.ready.set()
                state.error = None
                return
            if not error_queue.empty():
                state.error = error_queue.get()
                return
            if not child.is_alive():
                state.error = _crash_message(child)
                return
            time.sleep(1.0)

    def _wait_for(child: multiprocessing.Process, error_queue, deadline: float) -> Optional[str]:
        while time.monotonic() < deadline:
            if _port_open(HOST, CHILD_PORT):
                return "ready"
            if not error_queue.empty():
                state.error = error_queue.get()
                return "error"
            if not child.is_alive():
                state.error = _crash_message(child)
                return "crashed"
            time.sleep(0.2)
        return None

    def _crash_message(child: multiprocessing.Process) -> str:
        code = child.exitcode
        note = ""
        if isinstance(code, int) and code < 0:
            note = f" (сигнал {-code} — вероятен нативный сбой в скомпилированном модуле, например cryptography)"
        return f"Процесс инициализации неожиданно завершился (код выхода: {code}{note})."

    state.restart = _launch
    _launch()

    # Главный поток дальше не нужен для логики — вся работа идёт в daemon-
    # потоках/дочернем процессе; держим процесс живым.
    while True:
        time.sleep(3600)
