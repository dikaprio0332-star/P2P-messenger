"""
Установление соединения между пирами за NAT без какого-либо внешнего
сервера (ни сигнального, ни STUN/TURN, ни rendezvous-сервиса).

Из чего это складывается:

1. UPnP IGD (Internet Gateway Device) — узнаём внешний IP и (по
   возможности) открываем проброс порта, опрашивая ТОЛЬКО собственный
   роутер по локальной сети (SSDP-мультикаст 239.255.255.250:1900 +
   SOAP-запрос на найденный control URL). Это не внешний сервис — это
   обычный бытовой роутер, к которому мы и так подключены.

2. Инвайт-код — самодостаточная строка (base64(JSON)), в которую
   зашиты локальный и внешний адрес узла и его публичный ключ.
   Передаётся собеседнику любым способом вне приложения (мессенджер,
   голосом, QR-код и т.п.) — это ответственность пользователя, а не
   сетевого слоя.

3. Simultaneous open — оба узла одновременно (по договорённости
   пользователей "жми сейчас") пытаются установить исходящее TCP-
   соединение друг с другом, при этом каждый слушает и соединяется с
   ОДНОГО И ТОГО ЖЕ локального порта (SO_REUSEADDR/SO_REUSEPORT), чтобы
   NAT сохранил ту же трансляцию, что и для входящих подключений.

Ограничение, которое нельзя обойти кодом: если один из узлов находится
за симметричным NAT (Symmetric NAT / CGNAT, типично для мобильных
операторов), внешний порт меняется от соединения к соединению, и без
третьей стороны, наблюдающей оба адреса одновременно, пробить NAT
невозможно в принципе. В этом случае сработает только сценарий, когда
оба пира в одной локальной сети (используется local_ip/local_port из
инвайт-кода), либо когда роутер поддерживает UPnP.
"""

from __future__ import annotations

import base64
import json
import logging
import re
import socket
import struct
import threading
import time
import urllib.request
from dataclasses import dataclass, field
from typing import Optional
from xml.etree import ElementTree

from .config import CONFIG

logger = logging.getLogger("p2p_messenger.nat_punch")

SSDP_ADDR = "239.255.255.250"
SSDP_PORT = 1900
SSDP_SEARCH_TARGETS = (
    "urn:schemas-upnp-org:device:InternetGatewayDevice:1",
    "urn:schemas-upnp-org:device:InternetGatewayDevice:2",
)
UPNP_DISCOVER_TIMEOUT = 2.5
INVITE_CODE_VERSION = 1
INVITE_CODE_TTL_SEC = 15 * 60  # инвайт-код "протухает", чтобы не публиковать старые адреса


class NatPunchError(Exception):
    """Ошибка на любом из этапов: обнаружение роутера, проброс порта, пробив."""


# --------------------------------------------------------------------- #
# UPnP IGD: обнаружение роутера и запрос внешнего IP/проброса порта.
# Всё общение идёт по локальной сети с собственным шлюзом — никаких
# сторонних хостов в интернете здесь нет.
# --------------------------------------------------------------------- #


@dataclass
class UPnPGateway:
    control_url: str
    service_type: str


def discover_gateway(timeout: float = UPNP_DISCOVER_TIMEOUT) -> Optional[UPnPGateway]:
    """Находит домашний роутер через SSDP M-SEARCH. Возвращает None, если
    роутер не откликнулся или не поддерживает UPnP IGD (тогда доступен
    только пробив по локальной сети / вручную открытому порту)."""
    sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    sock.settimeout(timeout)

    location: Optional[str] = None
    try:
        for target in SSDP_SEARCH_TARGETS:
            msg = (
                "M-SEARCH * HTTP/1.1\r\n"
                f"HOST: {SSDP_ADDR}:{SSDP_PORT}\r\n"
                'MAN: "ssdp:discover"\r\n'
                "MX: 2\r\n"
                f"ST: {target}\r\n\r\n"
            ).encode("utf-8")
            try:
                sock.sendto(msg, (SSDP_ADDR, SSDP_PORT))
            except OSError as exc:
                logger.debug("SSDP-запрос не отправлен: %s", exc)
                continue

            deadline = time.monotonic() + timeout
            while time.monotonic() < deadline:
                try:
                    data, _addr = sock.recvfrom(4096)
                except socket.timeout:
                    break
                except OSError:
                    break
                text = data.decode("utf-8", errors="ignore")
                match = re.search(r"(?im)^location:\s*(\S+)", text)
                if match:
                    location = match.group(1).strip()
                    break
            if location:
                break
    finally:
        sock.close()

    if not location:
        logger.info("UPnP-роутер не найден по SSDP (это нормально, если UPnP выключен)")
        return None

    return _fetch_gateway_description(location)


def _fetch_gateway_description(location: str) -> Optional[UPnPGateway]:
    try:
        with urllib.request.urlopen(location, timeout=UPNP_DISCOVER_TIMEOUT) as resp:
            body = resp.read()
    except Exception as exc:  # noqa: BLE001 - роутеры отвечают очень по-разному
        logger.debug("Не удалось получить описание устройства UPnP: %s", exc)
        return None

    try:
        root = ElementTree.fromstring(body)
    except ElementTree.ParseError:
        return None

    ns = {"d": "urn:schemas-upnp-org:device-1-0"}
    base_match = re.match(r"(https?://[^/]+)", location)
    base_url = base_match.group(1) if base_match else location

    for service in root.iterfind(".//d:service", ns):
        service_type = (service.findtext("d:serviceType", default="", namespaces=ns) or "")
        if "WANIPConnection" in service_type or "WANPPPConnection" in service_type:
            control = service.findtext("d:controlURL", default="", namespaces=ns) or ""
            if not control:
                continue
            control_url = control if control.startswith("http") else base_url + control
            return UPnPGateway(control_url=control_url, service_type=service_type)
    return None


def _soap_call(gateway: UPnPGateway, action: str, params: dict[str, str]) -> str:
    args = "".join(f"<{k}>{v}</{k}>" for k, v in params.items())
    body = (
        '<?xml version="1.0"?>'
        '<s:Envelope xmlns:s="http://schemas.xmlsoap.org/soap/envelope/" '
        's:encodingStyle="http://schemas.xmlsoap.org/soap/encoding/">'
        "<s:Body>"
        f'<u:{action} xmlns:u="{gateway.service_type}">{args}</u:{action}>'
        "</s:Body></s:Envelope>"
    ).encode("utf-8")

    req = urllib.request.Request(
        gateway.control_url,
        data=body,
        headers={
            "Content-Type": 'text/xml; charset="utf-8"',
            "SOAPAction": f'"{gateway.service_type}#{action}"',
        },
        method="POST",
    )
    with urllib.request.urlopen(req, timeout=UPNP_DISCOVER_TIMEOUT) as resp:
        return resp.read().decode("utf-8", errors="ignore")


def get_external_ip(gateway: UPnPGateway) -> Optional[str]:
    try:
        xml_resp = _soap_call(gateway, "GetExternalIPAddress", {})
    except Exception as exc:  # noqa: BLE001
        logger.debug("GetExternalIPAddress не удался: %s", exc)
        return None
    match = re.search(r"<NewExternalIPAddress>([^<]*)</NewExternalIPAddress>", xml_resp)
    return match.group(1).strip() if match and match.group(1).strip() else None


def add_port_mapping(gateway: UPnPGateway, external_port: int, internal_port: int,
                      internal_ip: str, description: str = "p2p_messenger",
                      protocol: str = "TCP", lease_seconds: int = 3600) -> bool:
    """Best-effort: просит роутер пробросить порт. Возвращает False, если
    роутер отказал (например, UPnP отключён администратором) — это не
    фатально, просто пробив ограничится локальной сетью."""
    try:
        _soap_call(gateway, "AddPortMapping", {
            "NewRemoteHost": "",
            "NewExternalPort": str(external_port),
            "NewProtocol": protocol,
            "NewInternalPort": str(internal_port),
            "NewInternalClient": internal_ip,
            "NewEnabled": "1",
            "NewPortMappingDescription": description,
            "NewLeaseDuration": str(lease_seconds),
        })
        return True
    except Exception as exc:  # noqa: BLE001
        logger.info("Проброс порта через UPnP не удался: %s", exc)
        return False


def get_local_ip() -> str:
    """Локальный IP этого узла в LAN (без обращения к интернету — просто
    смотрим, через какой интерфейс ОС маршрутизировала бы пакет)."""
    sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    try:
        sock.connect(("10.255.255.255", 1))
        return sock.getsockname()[0]
    except OSError:
        return "127.0.0.1"
    finally:
        sock.close()


# --------------------------------------------------------------------- #
# Инвайт-код
# --------------------------------------------------------------------- #


@dataclass
class InviteCode:
    name: str
    public_key_pem: str
    local_ip: str
    local_port: int
    external_ip: Optional[str] = None
    external_port: Optional[int] = None
    created_at: float = field(default_factory=time.time)

    def encode(self) -> str:
        payload = {
            "v": INVITE_CODE_VERSION,
            "name": self.name,
            "pub": self.public_key_pem,
            "lip": self.local_ip,
            "lport": self.local_port,
            "eip": self.external_ip,
            "eport": self.external_port,
            "ts": self.created_at,
        }
        raw = json.dumps(payload, separators=(",", ":")).encode("utf-8")
        return base64.urlsafe_b64encode(raw).decode("ascii")

    @staticmethod
    def decode(code: str) -> "InviteCode":
        try:
            raw = base64.urlsafe_b64decode(code.strip().encode("ascii"))
            payload = json.loads(raw)
        except Exception as exc:  # noqa: BLE001
            raise NatPunchError("Некорректный инвайт-код") from exc

        if payload.get("v") != INVITE_CODE_VERSION:
            raise NatPunchError("Инвайт-код от несовместимой версии приложения")

        age = time.time() - float(payload.get("ts", 0))
        if age > INVITE_CODE_TTL_SEC:
            raise NatPunchError(
                "Инвайт-код устарел (действует %d мин) — попросите собеседника сгенерировать новый"
                % (INVITE_CODE_TTL_SEC // 60)
            )

        return InviteCode(
            name=payload["name"],
            public_key_pem=payload["pub"],
            local_ip=payload["lip"],
            local_port=int(payload["lport"]),
            external_ip=payload.get("eip"),
            external_port=payload.get("eport"),
            created_at=float(payload.get("ts", time.time())),
        )


def build_invite_code(name: str, public_key_pem: str, local_port: int,
                       upnp_timeout: float = UPNP_DISCOVER_TIMEOUT) -> InviteCode:
    """Собирает инвайт-код: локальный адрес известен всегда, внешний —
    best-effort через UPnP (может остаться None, тогда сработает только
    подключение в одной локальной сети)."""
    local_ip = get_local_ip()
    external_ip: Optional[str] = None
    external_port: Optional[int] = None

    gateway = discover_gateway(timeout=upnp_timeout)
    if gateway is not None:
        external_ip = get_external_ip(gateway)
        if external_ip and add_port_mapping(gateway, local_port, local_port, local_ip):
            external_port = local_port
        elif external_ip:
            # Роутер не даёт пробросить порт — внешний IP всё равно
            # публикуем: если у собеседника full-cone NAT и мы первыми
            # инициируем исходящее соединение с того же порта, что
            # слушаем, simultaneous open иногда срабатывает и без
            # явного маппинга.
            external_port = local_port

    return InviteCode(
        name=name,
        public_key_pem=public_key_pem,
        local_ip=local_ip,
        local_port=local_port,
        external_ip=external_ip,
        external_port=external_port,
    )


# --------------------------------------------------------------------- #
# Simultaneous open: попытка пробива на основе уже собранного инвайт-кода
# --------------------------------------------------------------------- #


def _bound_socket(local_port: int) -> socket.socket:
    sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    if hasattr(socket, "SO_REUSEPORT"):
        try:
            sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEPORT, 1)
        except OSError:
            pass
    sock.bind(("0.0.0.0", local_port))
    return sock


def _try_connect(local_port: int, target: tuple[str, int], deadline: float,
                  result: dict, result_key: str) -> None:
    while time.monotonic() < deadline and result.get("sock") is None:
        sock: Optional[socket.socket] = None
        try:
            sock = _bound_socket(local_port)
            sock.settimeout(1.0)
            sock.connect(target)
            sock.settimeout(None)
            if result.get("sock") is None:
                result["sock"] = sock
                result["via"] = result_key
            else:
                sock.close()
            return
        except OSError:
            if sock is not None:
                sock.close()
            time.sleep(0.3)


def punch_connect_to(invite: InviteCode, local_port: int,
                      timeout: float = 20.0) -> socket.socket:
    """
    Пытается установить TCP-соединение с пиром, описанным в инвайт-коде,
    без какого-либо сервера-посредника. Одновременно пробует:
      - локальный адрес (та же LAN — самый надёжный и быстрый случай),
      - внешний адрес (если он есть в инвайт-коде) — сработает при
        full-cone/умеренном NAT и/или проброшенном через UPnP порте.

    Оба собеседника должны вызвать это (или начать процесс подключения)
    примерно одновременно — именно это и есть simultaneous open.
    Бросает NatPunchError, если ни один вариант не сработал за timeout.
    """
    result: dict = {"sock": None, "via": None}
    deadline = time.monotonic() + timeout
    threads = []

    targets: list[tuple[str, tuple[str, int]]] = [("lan", (invite.local_ip, invite.local_port))]
    if invite.external_ip and invite.external_port:
        targets.append(("wan", (invite.external_ip, invite.external_port)))

    for key, target in targets:
        t = threading.Thread(
            target=_try_connect, args=(local_port, target, deadline, result, key),
            daemon=True, name=f"punch-{key}",
        )
        threads.append(t)
        t.start()

    for t in threads:
        t.join(timeout=max(0.0, deadline - time.monotonic()) + 0.1)

    sock = result.get("sock")
    if sock is None:
        raise NatPunchError(
            "Не удалось установить соединение напрямую (пробив NAT не сработал). "
            "Убедитесь, что оба устройства запустили подключение примерно одновременно, "
            "либо что вы в одной локальной сети."
        )
    logger.info("Пробив NAT удался через %s: %s", result["via"], sock.getpeername())
    return sock
