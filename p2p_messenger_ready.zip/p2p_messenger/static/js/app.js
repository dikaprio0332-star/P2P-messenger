/* =========================================================================
   p2p_messenger — фронтенд SPA.
   Обычный vanilla JS (без сборки/фреймворков) — работает прямо из /static.
   Общение с бэкендом идёт через простой JSON REST API + короткий polling
   для получения новых событий (см. p2p_messenger/webapp.py).
   ========================================================================= */

const state = {
  nickname: null,
  username: "",
  port: null,
  activePeer: null,
  lastEventId: 0,
  sessions: [],
  discovered: [],
  historyCache: {},   // peer name -> array of {direction, text, timestamp}
  unread: {},         // peer name -> count
  avatar: "",         // data URL моей аватарки, если задана
  bio: "",
  discoverable: true, // видимость в LAN-обнаружении (хранится на сервере, в аккаунте)
  settings: {          // локальные настройки уведомлений (только этот браузер)
    toasts: true,
    sound: false,
    desktop: false,
  },
};

const SETTINGS_STORAGE_KEY = "p2p_messenger_local_settings";

function loadLocalSettings() {
  try {
    const raw = localStorage.getItem(SETTINGS_STORAGE_KEY);
    if (raw) Object.assign(state.settings, JSON.parse(raw));
  } catch (_err) { /* некорректные данные в хранилище - используем значения по умолчанию */ }
}

function saveLocalSettings() {
  try {
    localStorage.setItem(SETTINGS_STORAGE_KEY, JSON.stringify(state.settings));
  } catch (_err) { /* хранилище недоступно (приватный режим и т.п.) - не критично */ }
}

const AVATAR_COLORS = ["#45E6D2", "#8D7CFF", "#F3B94D", "#FF6B72", "#5FB0FF", "#3ED598", "#E88CE0"];

/* ------------------------------------------------------------------ */
/* Утилиты                                                            */
/* ------------------------------------------------------------------ */

function colorForName(name) {
  let hash = 0;
  for (let i = 0; i < name.length; i++) hash = (hash * 31 + name.charCodeAt(i)) >>> 0;
  return AVATAR_COLORS[hash % AVATAR_COLORS.length];
}

function initialsFor(name) {
  return (name || "?").trim().slice(0, 2).toUpperCase();
}

function makeAvatar(name, size, imageUrl) {
  const el = document.createElement("div");
  el.className = "avatar";
  el.style.width = el.style.height = (size || 38) + "px";
  if (imageUrl) {
    el.style.backgroundImage = `url(${imageUrl})`;
    el.style.backgroundSize = "cover";
    el.style.backgroundPosition = "center";
  } else {
    el.style.background = colorForName(name);
    el.textContent = initialsFor(name);
  }
  return el;
}

function applyMyAvatar() {
  const target = document.getElementById("my-avatar");
  if (target) target.replaceWith(makeAvatarWithId(state.nickname, "my-avatar", state.avatar));
  const profileTarget = document.getElementById("profile-avatar");
  if (profileTarget) profileTarget.replaceWith(makeAvatarWithId(state.nickname, "profile-avatar", state.avatar, "avatar-xl"));
}

function formatTime(ts) {
  const d = new Date(ts * 1000);
  return d.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" });
}

async function api(method, url, body, isForm) {
  const opts = { method, headers: {}, credentials: "same-origin" };
  if (isForm) {
    opts.body = body;
  } else if (body !== undefined) {
    opts.headers["Content-Type"] = "application/json";
    opts.body = JSON.stringify(body);
  }
  const resp = await fetch(url, opts);
  let data = {};
  try { data = await resp.json(); } catch (_e) { /* пустой ответ допустим */ }
  if (!resp.ok) throw new Error(data.error || `Ошибка запроса (${resp.status})`);
  return data;
}

function toast(message, isError) {
  const container = document.getElementById("toast-container");
  const el = document.createElement("div");
  el.className = "toast" + (isError ? " error" : "");
  el.textContent = message;
  container.appendChild(el);
  setTimeout(() => el.remove(), 4500);
}

/* ------------------------------------------------------------------ */
/* Экран входа / регистрации                                          */
/* ------------------------------------------------------------------ */

function initAuthView() {
  const tabs = document.querySelectorAll(".tab-btn");
  tabs.forEach((btn) => {
    btn.addEventListener("click", () => {
      tabs.forEach((b) => b.classList.remove("active"));
      btn.classList.add("active");
      const target = btn.dataset.tab;
      document.getElementById("form-login").classList.toggle("hidden", target !== "login");
      document.getElementById("form-register").classList.toggle("hidden", target !== "register");
    });
  });

  document.getElementById("form-login").addEventListener("submit", async (e) => {
    e.preventDefault();
    const errorEl = document.getElementById("login-error");
    errorEl.textContent = "";
    const nickname = document.getElementById("login-nickname").value.trim();
    const password = document.getElementById("login-password").value;
    try {
      const data = await api("POST", "/api/login", { nickname, password });
      enterApp(data.nickname, data.port, data.username);
    } catch (err) {
      errorEl.textContent = err.message;
    }
  });

  document.getElementById("form-register").addEventListener("submit", async (e) => {
    e.preventDefault();
    const errorEl = document.getElementById("reg-error");
    errorEl.textContent = "";
    const nickname = document.getElementById("reg-nickname").value.trim();
    const password = document.getElementById("reg-password").value;
    const port = parseInt(document.getElementById("reg-port").value, 10) || 5100;
    try {
      const data = await api("POST", "/api/register", { nickname, password, port });
      enterApp(data.nickname, data.port, data.username);
    } catch (err) {
      errorEl.textContent = err.message;
    }
  });
}

/* ------------------------------------------------------------------ */
/* Переход в основной интерфейс                                       */
/* ------------------------------------------------------------------ */

function enterApp(nickname, port, username) {
  state.nickname = nickname;
  state.port = port;
  document.getElementById("view-auth").classList.add("hidden");
  document.getElementById("view-app").classList.remove("hidden");

  document.getElementById("my-name").textContent = nickname;
  document.getElementById("my-port").textContent = `порт ${port}`;
  document.getElementById("profile-nickname").textContent = nickname;
  document.getElementById("settings-nickname").textContent = nickname;
  document.getElementById("settings-port").textContent = port;
  applyMyUsername(username || "");
  applyMyAvatar();
  loadLocalSettings();
  applyLocalSettingsToUI();
  loadProfile();

  refreshPeers();
  refreshSessions();
  setInterval(refreshPeers, 4000);
  setInterval(refreshSessions, 3000);
  setInterval(pollEvents, 1000);
}

function applyMyUsername(username) {
  state.username = username || "";
  const label = state.username ? `@${state.username}` : "";
  document.getElementById("my-username").textContent = label;
  document.getElementById("settings-username").textContent = label || "\u2014";
  const input = document.getElementById("profile-username");
  if (input && document.activeElement !== input) input.value = state.username;
}

function makeAvatarWithId(name, id, imageUrl, extraClass) {
  const el = makeAvatar(name, undefined, imageUrl);
  el.id = id;
  if (extraClass) el.classList.add(extraClass);
  return el;
}

/* ------------------------------------------------------------------ */
/* Боковая панель: обнаруженные пиры и активные сессии                */
/* ------------------------------------------------------------------ */

async function refreshPeers() {
  try {
    const data = await api("GET", "/api/peers");
    state.discovered = data.peers;
    renderDiscovered();
  } catch (_err) { /* сеть могла временно моргнуть - не спамим тостами */ }
}

async function refreshSessions() {
  try {
    const data = await api("GET", "/api/sessions");
    state.sessions = data.sessions;
    renderSessions();
    if (state.activePeer) updateWireIndicator();
  } catch (_err) { /* см. выше */ }
}

function renderDiscovered() {
  const list = document.getElementById("discovered-list");
  list.innerHTML = "";
  const notConnected = state.discovered.filter((p) => !state.sessions.includes(p.name));
  if (notConnected.length === 0) {
    list.innerHTML = '<div class="peer-empty">Никого нового поблизости не видно</div>';
    return;
  }
  notConnected.forEach((p) => {
    const row = document.createElement("div");
    row.className = "peer-row clickable";
    row.appendChild(makeAvatar(p.name, 30));
    const meta = document.createElement("div");
    meta.className = "peer-row-meta";
    meta.innerHTML = `<div class="peer-row-name"></div><div class="peer-row-sub"></div>`;
    meta.querySelector(".peer-row-name").textContent = p.name;
    meta.querySelector(".peer-row-sub").textContent = `${p.address}:${p.tcp_port}`;
    row.appendChild(meta);
    row.addEventListener("click", () => connectTo(p.address, p.tcp_port));
    list.appendChild(row);
  });
}

function renderSessions() {
  const list = document.getElementById("sessions-list");
  list.innerHTML = "";
  if (state.sessions.length === 0) {
    list.innerHTML = '<div class="peer-empty">Пока нет активных подключений</div>';
    return;
  }
  state.sessions.forEach((name) => {
    const row = document.createElement("div");
    row.className = "peer-row clickable" + (name === state.activePeer ? " active" : "");
    row.appendChild(makeAvatar(name, 30));
    const meta = document.createElement("div");
    meta.className = "peer-row-meta";
    meta.innerHTML = `<div class="peer-row-name"></div><div class="peer-row-sub">защищено · AES-256</div>`;
    meta.querySelector(".peer-row-name").textContent = name;
    row.appendChild(meta);
    const dot = document.createElement("div");
    dot.className = "status-dot secure";
    row.appendChild(dot);
    row.addEventListener("click", () => selectPeer(name));
    list.appendChild(row);
  });
}

async function connectTo(address, port) {
  try {
    const data = await api("POST", "/api/connect", { address, port });
    toast(`Защищённое соединение установлено: ${data.peer}`);
    await refreshSessions();
    selectPeer(data.peer);
  } catch (err) {
    toast(err.message, true);
  }
}

/* ------------------------------------------------------------------ */
/* Область чата                                                       */
/* ------------------------------------------------------------------ */

function updateWireIndicator() {
  const wire = document.getElementById("wire-mini");
  const status = document.getElementById("chat-status");
  const connected = state.sessions.includes(state.activePeer);
  wire.className = "wire-mini " + (connected ? "secure" : "pending");
  status.textContent = connected ? "канал зашифрован · AES-256-GCM" : "соединение потеряно";
  status.className = "chat-status " + (connected ? "secure" : "");
  document.getElementById("msg-input").disabled = !connected;
  document.getElementById("btn-send").disabled = !connected;
}

async function selectPeer(name) {
  state.activePeer = name;
  state.unread[name] = 0;
  document.getElementById("chat-title").textContent = name;
  updateWireIndicator();
  renderSessions();
  await loadHistory(name);
}

async function loadHistory(name) {
  try {
    const data = await api("GET", `/api/history/${encodeURIComponent(name)}`);
    state.historyCache[name] = data.history;
    renderMessages(name);
  } catch (err) {
    toast(err.message, true);
  }
}

function renderMessages(name) {
  const box = document.getElementById("messages");
  box.innerHTML = "";
  const records = state.historyCache[name] || [];
  if (records.length === 0) {
    box.innerHTML = '<p class="msg-empty">Сообщений пока нет. Напишите первым &mdash; собеседник получит их мгновенно.</p>';
    return;
  }
  records.forEach((rec) => appendBubble(rec.direction, rec.text, rec.timestamp));
  box.scrollTop = box.scrollHeight;
}

function appendBubble(direction, text, ts) {
  const box = document.getElementById("messages");
  if (box.querySelector(".msg-empty")) box.innerHTML = "";
  const row = document.createElement("div");
  row.className = "bubble-row " + (direction === "out" ? "out" : "in");
  const bubble = document.createElement("div");
  bubble.className = "bubble";
  const textEl = document.createElement("div");
  textEl.textContent = text;
  bubble.appendChild(textEl);
  const time = document.createElement("span");
  time.className = "bubble-time";
  time.textContent = formatTime(ts || Date.now() / 1000);
  bubble.appendChild(time);
  row.appendChild(bubble);
  box.appendChild(row);
  box.scrollTop = box.scrollHeight;
}

async function sendCurrentMessage() {
  const input = document.getElementById("msg-input");
  const text = input.value.trim();
  if (!text || !state.activePeer) return;
  input.value = "";
  try {
    await api("POST", "/api/send", { peer: state.activePeer, text });
    appendBubble("out", text, Date.now() / 1000);
    state.historyCache[state.activePeer] = state.historyCache[state.activePeer] || [];
    state.historyCache[state.activePeer].push({ direction: "out", text, timestamp: Date.now() / 1000 });
  } catch (err) {
    toast(err.message, true);
    input.value = text;
  }
}

async function sendFile(file) {
  if (!state.activePeer) return;
  const form = new FormData();
  form.append("peer", state.activePeer);
  form.append("file", file);
  toast(`Отправка файла "${file.name}"…`);
  try {
    await api("POST", "/api/file", form, true);
    appendBubble("out", `\ud83d\udcce ${file.name}`, Date.now() / 1000);
  } catch (err) {
    toast(err.message, true);
  }
}

/* ------------------------------------------------------------------ */
/* Polling событий (входящие сообщения, статусы, обнаружение)         */
/* ------------------------------------------------------------------ */

async function pollEvents() {
  try {
    const data = await api("GET", `/api/events?since=${state.lastEventId}`);
    data.events.forEach(handleEvent);
  } catch (_err) { /* сеть могла временно моргнуть */ }
}

function handleEvent(ev) {
  state.lastEventId = Math.max(state.lastEventId, ev.id);

  if (ev.kind === "chat") {
    state.historyCache[ev.peer] = state.historyCache[ev.peer] || [];
    state.historyCache[ev.peer].push({ direction: "in", text: ev.text, timestamp: ev.ts });
    if (ev.peer === state.activePeer) {
      appendBubble("in", ev.text, ev.ts);
    } else {
      state.unread[ev.peer] = (state.unread[ev.peer] || 0) + 1;
      notifyIncomingMessage(ev.peer, ev.text);
      renderSessions();
    }
  } else if (ev.kind === "status") {
    toast(ev.message, ev.status === "error");
    if (ev.status === "connect" || ev.status === "disconnect") {
      refreshSessions();
      if (ev.status === "disconnect" && ev.message.indexOf(state.activePeer) !== -1) {
        updateWireIndicator();
      }
    }
  } else if (ev.kind === "discovery") {
    refreshPeers();
  }
}

/* ------------------------------------------------------------------ */
/* Модалка ручного подключения                                        */
/* ------------------------------------------------------------------ */

function initConnectModal() {
  const modal = document.getElementById("modal-connect");
  document.getElementById("btn-connect").addEventListener("click", () => {
    document.getElementById("connect-error").textContent = "";
    modal.classList.remove("hidden");
  });
  document.getElementById("btn-connect-cancel").addEventListener("click", () => modal.classList.add("hidden"));
  document.getElementById("btn-connect-submit").addEventListener("click", async () => {
    const address = document.getElementById("connect-address").value.trim();
    const port = parseInt(document.getElementById("connect-port").value, 10);
    const errorEl = document.getElementById("connect-error");
    if (!address || !port) { errorEl.textContent = "Укажите адрес и порт."; return; }
    try {
      const data = await api("POST", "/api/connect", { address, port });
      modal.classList.add("hidden");
      toast(`Защищённое соединение установлено: ${data.peer}`);
      await refreshSessions();
      selectPeer(data.peer);
    } catch (err) {
      errorEl.textContent = err.message;
    }
  });
}

/* ------------------------------------------------------------------ */
/* Композер (ввод сообщений и файлов)                                 */
/* ------------------------------------------------------------------ */

function initComposer() {
  document.getElementById("btn-send").addEventListener("click", sendCurrentMessage);
  document.getElementById("msg-input").addEventListener("keydown", (e) => {
    if (e.key === "Enter") sendCurrentMessage();
  });
  document.getElementById("btn-attach").addEventListener("click", () => {
    document.getElementById("file-input").click();
  });
  document.getElementById("file-input").addEventListener("change", (e) => {
    const file = e.target.files[0];
    if (file) sendFile(file);
    e.target.value = "";
  });
}

/* ------------------------------------------------------------------ */
/* Нижняя навигация (Чат / Настройки / Профиль)                       */
/* ------------------------------------------------------------------ */

function initBottomNav() {
  document.querySelectorAll(".nav-btn").forEach((btn) => {
    btn.addEventListener("click", () => {
      document.querySelectorAll(".nav-btn").forEach((b) => b.classList.remove("active"));
      document.querySelectorAll(".app-screen").forEach((s) => s.classList.remove("active"));
      btn.classList.add("active");
      document.getElementById(`screen-${btn.dataset.screen}`).classList.add("active");
    });
  });

  document.getElementById("btn-open-sidebar").addEventListener("click", () => {
    document.getElementById("sidebar").classList.toggle("open");
    document.getElementById("sidebar-backdrop").classList.toggle("visible");
  });

  document.getElementById("sidebar-backdrop").addEventListener("click", () => {
    document.getElementById("sidebar").classList.remove("open");
    document.getElementById("sidebar-backdrop").classList.remove("visible");
  });
}

/* ------------------------------------------------------------------ */
/* Экран профиля: аватарка и описание                                 */
/* ------------------------------------------------------------------ */

async function loadProfile() {
  try {
    const data = await api("GET", "/api/profile");
    state.avatar = data.avatar || "";
    state.bio = data.bio || "";
    state.discoverable = data.discoverable !== false;
    document.getElementById("profile-bio").value = state.bio;
    document.getElementById("settings-discoverable").checked = state.discoverable;
    updateBioCount();
    applyMyAvatar();
    applyMyUsername(data.username || state.username);
  } catch (_err) { /* профиль подтянется при следующем открытии вкладки */ }
}

function updateBioCount() {
  const len = document.getElementById("profile-bio").value.length;
  document.getElementById("profile-bio-count").textContent = `${len} / 280`;
}

function resizeImageToDataUrl(file, maxSize) {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onerror = () => reject(new Error("Не удалось прочитать файл."));
    reader.onload = () => {
      const img = new Image();
      img.onerror = () => reject(new Error("Файл не похож на изображение."));
      img.onload = () => {
        const scale = Math.min(1, maxSize / Math.max(img.width, img.height));
        const w = Math.round(img.width * scale);
        const h = Math.round(img.height * scale);
        const canvas = document.createElement("canvas");
        canvas.width = w;
        canvas.height = h;
        canvas.getContext("2d").drawImage(img, 0, 0, w, h);
        resolve(canvas.toDataURL("image/jpeg", 0.85));
      };
      img.src = reader.result;
    };
    reader.readAsDataURL(file);
  });
}

function initProfileScreen() {
  document.getElementById("btn-change-avatar").addEventListener("click", () => {
    document.getElementById("avatar-input").click();
  });

  document.getElementById("avatar-input").addEventListener("change", async (e) => {
    const file = e.target.files[0];
    e.target.value = "";
    if (!file) return;
    try {
      state.avatar = await resizeImageToDataUrl(file, 256);
      applyMyAvatar();
    } catch (err) {
      toast(err.message, true);
    }
  });

  document.getElementById("profile-bio").addEventListener("input", updateBioCount);

  document.getElementById("btn-save-profile").addEventListener("click", async () => {
    const errorEl = document.getElementById("profile-error");
    errorEl.textContent = "";
    const bio = document.getElementById("profile-bio").value.trim();
    const username = document.getElementById("profile-username").value.trim().replace(/^@+/, "");
    if (!username) { errorEl.textContent = "Юзернейм не может быть пустым."; return; }
    try {
      const data = await api("POST", "/api/profile", { bio, avatar: state.avatar, username });
      state.bio = bio;
      applyMyUsername(data.username);
      toast("Профиль сохранён");
    } catch (err) {
      errorEl.textContent = err.message;
    }
  });
}

/* ------------------------------------------------------------------ */
/* Экран настроек: видимость в сети и уведомления                     */
/* ------------------------------------------------------------------ */

function applyLocalSettingsToUI() {
  document.getElementById("settings-toasts").checked = !!state.settings.toasts;
  document.getElementById("settings-sound").checked = !!state.settings.sound;
  document.getElementById("settings-desktop").checked = !!state.settings.desktop;
}

function playNotificationSound() {
  try {
    const ctx = new (window.AudioContext || window.webkitAudioContext)();
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    osc.type = "sine";
    osc.frequency.value = 720;
    gain.gain.setValueAtTime(0.0001, ctx.currentTime);
    gain.gain.exponentialRampToValueAtTime(0.15, ctx.currentTime + 0.01);
    gain.gain.exponentialRampToValueAtTime(0.0001, ctx.currentTime + 0.22);
    osc.connect(gain).connect(ctx.destination);
    osc.start();
    osc.stop(ctx.currentTime + 0.24);
    osc.onended = () => ctx.close();
  } catch (_err) { /* WebAudio недоступен - тихо пропускаем */ }
}

function showDesktopNotification(peerName, text) {
  if (!("Notification" in window) || Notification.permission !== "granted") return;
  if (document.visibilityState === "visible") return; // не дублируем, пока вкладка активна
  try {
    const n = new Notification(`${peerName}`, { body: text, tag: `p2p-${peerName}` });
    n.onclick = () => { window.focus(); n.close(); };
  } catch (_err) { /* некоторые браузеры на мобильных не поддерживают конструктор Notification */ }
}

function notifyIncomingMessage(peerName, text) {
  if (state.settings.toasts) toast(`${peerName}: ${text}`);
  if (state.settings.sound) playNotificationSound();
  if (state.settings.desktop) showDesktopNotification(peerName, text);
}

function initSettingsScreen() {
  document.getElementById("settings-discoverable").addEventListener("change", async (e) => {
    const discoverable = e.target.checked;
    try {
      await api("POST", "/api/profile", { discoverable });
      state.discoverable = discoverable;
      toast(discoverable ? "Вы снова видны в LAN-обнаружении" : "Вы скрыты из LAN-обнаружения");
    } catch (err) {
      e.target.checked = !discoverable; // откатываем переключатель при ошибке
      toast(err.message, true);
    }
  });

  document.getElementById("settings-toasts").addEventListener("change", (e) => {
    state.settings.toasts = e.target.checked;
    saveLocalSettings();
  });

  document.getElementById("settings-sound").addEventListener("change", (e) => {
    state.settings.sound = e.target.checked;
    saveLocalSettings();
    if (e.target.checked) playNotificationSound(); // короткий пример звука сразу при включении
  });

  document.getElementById("settings-desktop").addEventListener("change", async (e) => {
    if (!e.target.checked) {
      state.settings.desktop = false;
      saveLocalSettings();
      return;
    }
    if (!("Notification" in window)) {
      e.target.checked = false;
      toast("Браузер не поддерживает уведомления", true);
      return;
    }
    const permission = await Notification.requestPermission();
    if (permission !== "granted") {
      e.target.checked = false;
      toast("Разрешение на уведомления не выдано", true);
      return;
    }
    state.settings.desktop = true;
    saveLocalSettings();
  });
}

/* ------------------------------------------------------------------ */
/* Выход                                                              */
/* ------------------------------------------------------------------ */

function initLogout() {
  document.getElementById("btn-logout").addEventListener("click", async () => {
    try { await api("POST", "/api/logout"); } catch (_err) { /* всё равно уходим с экрана */ }
    window.location.reload();
  });
}

/* ------------------------------------------------------------------ */
/* Точка входа                                                        */
/* ------------------------------------------------------------------ */

async function bootstrap() {
  initAuthView();
  initConnectModal();
  initComposer();
  initLogout();
  initBottomNav();
  initProfileScreen();
  initSettingsScreen();

  try {
    const data = await api("GET", "/api/session");
    if (data.logged_in) {
      enterApp(data.nickname, data.port, data.username);
      return;
    }
  } catch (_err) { /* остаёмся на экране входа */ }
}

document.addEventListener("DOMContentLoaded", bootstrap);
