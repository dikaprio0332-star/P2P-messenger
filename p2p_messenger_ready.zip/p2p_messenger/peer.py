"""
Peer — центральный класс приложения, объединяющий:

    network.py     (TCP-соединения)
    crypto_utils.py (RSA-рукопожатие + AES-GCM сессии)
    discovery.py   (обнаружение узлов в LAN)
    storage.py     (история переписки, контакты)
    protocol.py    (формат сообщений)

Это "фасад" (Facade pattern) — весь остальной код (CLI, GUI) работает
только через методы Peer и не лезет в детали сокетов или крипто.

Жизненный цикл соединения с собеседником:

  1. connect_to() ИЛИ входящее соединение через TCPServer
  2. HELLO <-> HELLO_ACK: обмен именами и RSA публичными ключами
  3. Инициатор генерирует AES-сессионный ключ, шифрует его RSA-ключом
     собеседника и отправляет KEY_EXCHANGE
  4. С этого момента все CHAT/FILE_* сообщения шифруются AES-GCM
"""

from __future__ import annotations

import base64
import logging
import threading
from dataclasses import dataclass, field
from pathlib import Path
from typing import Callable, Optional

from . import crypto_utils
from . import nat_punch
from .config import CONFIG
from .crypto_utils import CascadeCipher
from .discovery import DiscoveredPeer, PeerDiscovery
from .nat_punch import InviteCode, NatPunchError
from .network import Connection, TCPServer, connect_to_peer
from .protocol import Envelope, MessageType, ProtocolError
from .storage import ContactsStore, HistoryStore

logger = logging.getLogger("p2p_messenger.peer")


@dataclass
class PeerSession:
    """Состояние одной установленной сессии с конкретным собеседником."""

    name: str
    connection: Connection
    cipher: Optional[CascadeCipher] = None
    is_initiator: bool = False
    ready_event: threading.Event = field(default_factory=threading.Event)


# Тип колбэка для входящих текстовых сообщений: (peer_name, text) -> None
ChatCallback = Callable[[str, str], None]
# Тип колбэка для системных событий (подключение/отключение/ошибка)
EventCallback = Callable[[str, str], None]


class Peer:
    """Главный узел мессенджера, представляющий локального пользователя."""

    def __init__(
        self,
        name: str,
        tcp_port: int = CONFIG.tcp_port,
        key_password: str = "",
        username: str = "",
        bio: str = "",
        avatar: str = "",
    ):
        self.name = name
        self.tcp_port = tcp_port
        # Профиль, который отдаётся другим узлам по запросу (см. PROFILE_REQUEST
        # ниже) - хранится здесь как простые атрибуты, а не читается из
        # AccountStore напрямую, чтобы Peer не зависел от web-слоя аутентификации
        # (это по-прежнему тот же "фасад", просто с парой дополнительных полей).
        self.username = username
        self.bio = bio
        self.avatar = avatar

        CONFIG.ensure_dirs()
        self.private_key, self.public_key = crypto_utils.load_or_create_rsa_keypair(name, key_password)
        self.public_key_pem = crypto_utils.public_key_to_pem(self.public_key)

        self.contacts = ContactsStore()
        self.history = HistoryStore()

        self._sessions: dict[str, PeerSession] = {}
        self._sessions_lock = threading.Lock()

        self._server = TCPServer(tcp_port, self._on_incoming_connection)
        self._discovery = PeerDiscovery(
            name, tcp_port, username=username, bio=bio, on_peer_updated=self._on_peer_discovered
        )

        self.on_chat_message: Optional[ChatCallback] = None
        self.on_event: Optional[EventCallback] = None
        self.on_discovery_update: Optional[Callable[[DiscoveredPeer], None]] = None
        # Колбэк для полностью полученного файла: (peer_name, filename, size, saved_path) -> None
        self.on_file_received: Optional[Callable[[str, str, int, str], None]] = None

        self._file_transfers: dict[str, "IncomingFileTransfer"] = {}

        # --- Запрос профиля собеседника (аватар/био/юзернейм по TCP) -------
        self._peer_profiles: dict[str, dict] = {}
        self._profile_events: dict[str, threading.Event] = {}
        self._profile_lock = threading.Lock()

    # ------------------------------------------------------------------ #
    # Жизненный цикл
    # ------------------------------------------------------------------ #

    def start(self) -> None:
        self._server.start()
        self._discovery.start()
        self._emit_event("info", f"Узел '{self.name}' запущен на порту {self.tcp_port}")

    def stop(self) -> None:
        self._discovery.stop()
        self._server.stop()
        with self._sessions_lock:
            for session in self._sessions.values():
                self._send_bye(session)
                session.connection.close()
            self._sessions.clear()

    def get_discovered_peers(self) -> list[DiscoveredPeer]:
        return self._discovery.get_peers()

    def get_active_sessions(self) -> list[str]:
        with self._sessions_lock:
            return list(self._sessions.keys())

    def set_discoverable(self, visible: bool) -> None:
        """Настройка: показывать ли этот узел другим в LAN-обнаружении."""
        self._discovery.set_visible(visible)

    @property
    def discoverable(self) -> bool:
        return self._discovery.is_visible

    def set_username(self, username: str) -> None:
        """Обновляет @username, который транслируется другим узлам при обнаружении."""
        self.username = username
        self._discovery.set_username(username)

    def set_profile(self, bio: Optional[str] = None, avatar: Optional[str] = None) -> None:
        """
        Обновляет локальный профиль (био/аватар), отдаваемый другим узлам по
        PROFILE_REQUEST. Био также коротко транслируется в UDP-анонсах (см.
        discovery.py), аватар - только по прямому TCP-запросу (слишком большой
        для широковещательных пакетов).
        """
        if bio is not None:
            self.bio = bio
            self._discovery.set_bio(bio)
        if avatar is not None:
            self.avatar = avatar

    def request_profile(self, peer_name: str, timeout: float = 5.0) -> Optional[dict]:
        """
        Запросить полный профиль (username/bio/avatar) у уже подключённого
        собеседника и дождаться ответа. Возвращает None, если сессии нет или
        собеседник не ответил вовремя.
        """
        session = self._get_ready_session_or_none(peer_name)
        if session is None:
            return None
        with self._profile_lock:
            event = self._profile_events.setdefault(peer_name, threading.Event())
            event.clear()
        try:
            session.connection.send_envelope(
                Envelope(type=MessageType.PROFILE_REQUEST.value, sender=self.name)
            )
        except (OSError, ProtocolError):
            return None
        if not event.wait(timeout=timeout):
            return None
        with self._profile_lock:
            return self._peer_profiles.get(peer_name)

    # ------------------------------------------------------------------ #
    # Подключение к пирам
    # ------------------------------------------------------------------ #

    def connect_to(self, address: str, port: int) -> str:
        """
        Установить исходящее соединение с пиром по адресу:порту, выполнить
        рукопожатие и обмен ключами. Возвращает имя подключённого пира.
        Блокирует вызывающий поток до завершения рукопожатия либо ошибки.
        """
        conn = connect_to_peer(address, port)
        return self._bootstrap_outgoing_session(conn, label=f"{address}:{port}")

    def _bootstrap_outgoing_session(self, conn: Connection, label: str) -> str:
        """Общая часть connect_to/connect_via_invite: запускает читающий
        поток, отправляет HELLO и ждёт завершения рукопожатия."""
        session = PeerSession(name="", connection=conn, is_initiator=True)

        reader_thread = threading.Thread(
            target=self._session_reader_loop, args=(session,), daemon=True,
            name=f"reader-{label}",
        )
        reader_thread.start()

        self._send_hello(conn)

        if not session.ready_event.wait(timeout=CONFIG.connect_timeout_sec * 3):
            conn.close()
            raise TimeoutError(f"Рукопожатие с {label} не завершилось по таймауту")

        return session.name

    # ------------------------------------------------------------------ #
    # Инвайт-код: подключение без сигнального/rendezvous-сервера
    # ------------------------------------------------------------------ #

    def generate_invite_code(self) -> str:
        """
        Собирает инвайт-код для передачи собеседнику вне приложения
        (мессенджер, QR-код и т.п.). Best-effort пытается узнать внешний
        IP и пробросить порт через UPnP на домашнем роутере — без
        какого-либо стороннего сервера. Если UPnP недоступен, код всё
        равно рабочий для подключения в пределах одной локальной сети.
        """
        invite = nat_punch.build_invite_code(
            name=self.name,
            public_key_pem=self.public_key_pem,
            local_port=self.tcp_port,
        )
        return invite.encode()

    def connect_via_invite(self, code: str, timeout: float = 20.0) -> str:
        """
        Подключается к пиру по инвайт-коду без сигнального сервера:
        пытается одновременно достучаться по локальному и внешнему
        адресу из кода (см. nat_punch.punch_connect_to). Собеседник
        должен в это же время генерировать/принимать код со своей
        стороны (simultaneous open) — просто открыть приложение и
        слушать порт для этого достаточно, отдельного действия
        "начать пробив" со стороны того, кто поделился кодом, не
        требуется.
        """
        invite = InviteCode.decode(code)
        try:
            raw_sock = nat_punch.punch_connect_to(invite, local_port=self.tcp_port, timeout=timeout)
        except NatPunchError:
            raise
        conn = Connection(raw_sock, raw_sock.getpeername())
        return self._bootstrap_outgoing_session(conn, label=f"invite:{invite.name}")

    def send_chat(self, peer_name: str, text: str) -> None:
        session = self._get_ready_session(peer_name)
        envelope = Envelope(
            type=MessageType.CHAT.value,
            payload={"ciphertext": session.cipher.encrypt(text.encode("utf-8"))},
            sender=self.name,
        )
        session.connection.send_envelope(envelope)
        self.history.append(peer_name, "out", text)

    def send_file(self, peer_name: str, filepath: str, chunk_size: int = 32 * 1024) -> None:
        """Передать файл собеседнику по частям, каждая часть зашифрована AES-GCM."""
        session = self._get_ready_session(peer_name)
        path = Path(filepath)
        if not path.is_file():
            raise FileNotFoundError(filepath)

        file_id = base64.urlsafe_b64encode(path.name.encode("utf-8")).decode("ascii")[:16]
        size = path.stat().st_size

        session.connection.send_envelope(
            Envelope(
                type=MessageType.FILE_OFFER.value,
                payload={"file_id": file_id, "filename": path.name, "size": size},
                sender=self.name,
            )
        )

        with path.open("rb") as f:
            while True:
                chunk = f.read(chunk_size)
                if not chunk:
                    break
                blob = session.cipher.encrypt(chunk)
                session.connection.send_envelope(
                    Envelope(
                        type=MessageType.FILE_CHUNK.value,
                        payload={"file_id": file_id, "data": blob},
                        sender=self.name,
                    )
                )

        session.connection.send_envelope(
            Envelope(type=MessageType.FILE_DONE.value, payload={"file_id": file_id}, sender=self.name)
        )
        self._emit_event("info", f"Файл '{path.name}' отправлен пиру {peer_name}")

    # ------------------------------------------------------------------ #
    # Входящие соединения
    # ------------------------------------------------------------------ #

    def _on_incoming_connection(self, conn: Connection) -> None:
        session = PeerSession(name="", connection=conn, is_initiator=False)
        self._session_reader_loop(session)

    def _on_peer_discovered(self, peer: DiscoveredPeer) -> None:
        self.contacts.upsert(peer.name, peer.address, peer.tcp_port)
        if self.on_discovery_update:
            self.on_discovery_update(peer)

    # ------------------------------------------------------------------ #
    # Основной цикл чтения сессии (один на каждое соединение)
    # ------------------------------------------------------------------ #

    def _session_reader_loop(self, session: PeerSession) -> None:
        conn = session.connection
        try:
            while not conn.is_closed:
                try:
                    envelope = conn.recv_envelope()
                except ProtocolError as exc:
                    self._emit_event("error", f"Ошибка протокола от {conn.address}: {exc}")
                    break
                except OSError:
                    break

                self._dispatch(session, envelope)
                if envelope.type == MessageType.BYE.value:
                    break
        finally:
            conn.close()
            if session.name:
                with self._sessions_lock:
                    self._sessions.pop(session.name, None)
                self._emit_event("disconnect", session.name)

    def _dispatch(self, session: PeerSession, envelope: Envelope) -> None:
        handler_name = f"_handle_{envelope.type}"
        handler = getattr(self, handler_name, None)
        if handler is None:
            self._emit_event("error", f"Неизвестный тип сообщения: {envelope.type}")
            return
        handler(session, envelope)

    # ------------------------------------------------------------------ #
    # Обработчики конкретных типов сообщений (rукопожатие)
    # ------------------------------------------------------------------ #

    def _send_hello(self, conn: Connection) -> None:
        conn.send_envelope(
            Envelope(
                type=MessageType.HELLO.value,
                payload={"name": self.name, "public_key_pem": self.public_key_pem, "tcp_port": self.tcp_port},
                sender=self.name,
            )
        )

    def _handle_hello(self, session: PeerSession, envelope: Envelope) -> None:
        peer_name = envelope.payload["name"]
        peer_pub_pem = envelope.payload["public_key_pem"]
        peer_port = envelope.payload.get("tcp_port")
        session.name = peer_name
        session.connection.peer_name = peer_name

        self.contacts.upsert(peer_name, session.connection.address[0], peer_port or 0, peer_pub_pem)

        # Отвечаем своим HELLO_ACK, если мы не инициатор (симметричный обмен).
        if not session.is_initiator:
            session.connection.send_envelope(
                Envelope(
                    type=MessageType.HELLO_ACK.value,
                    payload={
                        "name": self.name,
                        "public_key_pem": self.public_key_pem,
                        "tcp_port": self.tcp_port,
                    },
                    sender=self.name,
                )
            )

        # Инициатор соединения генерирует и рассылает сессионный AES-ключ.
        if session.is_initiator:
            peer_pub_key = crypto_utils.public_key_from_pem(peer_pub_pem)
            session_key = crypto_utils.generate_session_key()
            session.cipher = CascadeCipher(session_key)
            encrypted_key = crypto_utils.rsa_encrypt(peer_pub_key, session_key)
            session.connection.send_envelope(
                Envelope(
                    type=MessageType.KEY_EXCHANGE.value,
                    payload={"encrypted_key_hex": encrypted_key.hex()},
                    sender=self.name,
                )
            )
            self._activate_session(session)

    def _handle_hello_ack(self, session: PeerSession, envelope: Envelope) -> None:
        # HELLO_ACK несёт ту же информацию, что и HELLO - переиспользуем обработчик.
        self._handle_hello(session, envelope)

    def _handle_key_exchange(self, session: PeerSession, envelope: Envelope) -> None:
        encrypted_key = bytes.fromhex(envelope.payload["encrypted_key_hex"])
        session_key = crypto_utils.rsa_decrypt(self.private_key, encrypted_key)
        session.cipher = CascadeCipher(session_key)
        self._activate_session(session)

    def _activate_session(self, session: PeerSession) -> None:
        with self._sessions_lock:
            self._sessions[session.name] = session
        session.ready_event.set()
        self._emit_event("connect", session.name)

    # ------------------------------------------------------------------ #
    # Обработчики прикладных сообщений
    # ------------------------------------------------------------------ #

    def _handle_chat(self, session: PeerSession, envelope: Envelope) -> None:
        if session.cipher is None:
            self._emit_event("error", f"Получено CHAT до завершения рукопожатия от {session.name}")
            return
        plaintext = session.cipher.decrypt(envelope.payload["ciphertext"]).decode("utf-8")
        self.history.append(session.name, "in", plaintext)
        if self.on_chat_message:
            self.on_chat_message(session.name, plaintext)
        # Подтверждаем доставку. Собеседник мог уже закрыть соединение
        # (например, выходит из программы) - это не повод падать с ошибкой.
        try:
            session.connection.send_envelope(
                Envelope(type=MessageType.ACK.value, payload={"msg_id": envelope.msg_id}, sender=self.name)
            )
        except (ProtocolError, OSError):
            logger.debug("Не удалось отправить ACK: соединение с %s уже закрыто", session.name)

    def _handle_ack(self, session: PeerSession, envelope: Envelope) -> None:
        logger.debug("ACK получен от %s для msg_id=%s", session.name, envelope.payload.get("msg_id"))

    def _handle_ping(self, session: PeerSession, envelope: Envelope) -> None:
        session.connection.send_envelope(Envelope(type=MessageType.PONG.value, sender=self.name))

    def _handle_pong(self, session: PeerSession, envelope: Envelope) -> None:
        logger.debug("PONG от %s", session.name)

    def _handle_bye(self, session: PeerSession, envelope: Envelope) -> None:
        self._emit_event("info", f"{session.name} закрыл(а) соединение")

    def _handle_error(self, session: PeerSession, envelope: Envelope) -> None:
        self._emit_event("error", f"Ошибка от {session.name}: {envelope.payload.get('message')}")

    # --- Профиль собеседника --------------------------------------------- #

    def _handle_profile_request(self, session: PeerSession, envelope: Envelope) -> None:
        try:
            session.connection.send_envelope(
                Envelope(
                    type=MessageType.PROFILE_RESPONSE.value,
                    payload={"username": self.username, "bio": self.bio, "avatar": self.avatar},
                    sender=self.name,
                )
            )
        except (OSError, ProtocolError):
            pass

    def _handle_profile_response(self, session: PeerSession, envelope: Envelope) -> None:
        with self._profile_lock:
            self._peer_profiles[session.name] = {
                "username": envelope.payload.get("username", ""),
                "bio": envelope.payload.get("bio", ""),
                "avatar": envelope.payload.get("avatar", ""),
            }
            event = self._profile_events.setdefault(session.name, threading.Event())
            event.set()

    # --- Передача файлов ------------------------------------------------ #

    def _handle_file_offer(self, session: PeerSession, envelope: Envelope) -> None:
        transfer = IncomingFileTransfer(
            file_id=envelope.payload["file_id"],
            filename=envelope.payload["filename"],
            size=envelope.payload["size"],
        )
        self._file_transfers[transfer.file_id] = transfer
        self._emit_event(
            "info", f"{session.name} отправляет файл '{transfer.filename}' ({transfer.size} байт)"
        )

    def _handle_file_chunk(self, session: PeerSession, envelope: Envelope) -> None:
        file_id = envelope.payload["file_id"]
        transfer = self._file_transfers.get(file_id)
        if transfer is None or session.cipher is None:
            return
        chunk = session.cipher.decrypt(envelope.payload["data"])
        transfer.chunks.append(chunk)

    def _handle_file_done(self, session: PeerSession, envelope: Envelope) -> None:
        file_id = envelope.payload["file_id"]
        transfer = self._file_transfers.pop(file_id, None)
        if transfer is None:
            return
        out_dir = CONFIG.data_dir / "received_files"
        out_dir.mkdir(parents=True, exist_ok=True)
        out_path = out_dir / transfer.filename
        out_path.write_bytes(b"".join(transfer.chunks))
        self._emit_event("info", f"Файл получен и сохранён: {out_path}")
        if self.on_file_received:
            self.on_file_received(session.name, transfer.filename, transfer.size, str(out_path))

    # ------------------------------------------------------------------ #
    # Вспомогательное
    # ------------------------------------------------------------------ #

    def _get_ready_session(self, peer_name: str) -> PeerSession:
        with self._sessions_lock:
            session = self._sessions.get(peer_name)
        if session is None or session.cipher is None:
            raise ConnectionError(f"Нет активной защищённой сессии с '{peer_name}'")
        return session

    def _get_ready_session_or_none(self, peer_name: str) -> Optional[PeerSession]:
        with self._sessions_lock:
            session = self._sessions.get(peer_name)
        if session is None or session.cipher is None:
            return None
        return session

    def _send_bye(self, session: PeerSession) -> None:
        try:
            session.connection.send_envelope(Envelope(type=MessageType.BYE.value, sender=self.name))
        except (OSError, ProtocolError):
            pass

    def _emit_event(self, kind: str, message: str) -> None:
        logger.info("[%s] %s", kind, message)
        if self.on_event:
            self.on_event(kind, message)


@dataclass
class IncomingFileTransfer:
    file_id: str
    filename: str
    size: int
    chunks: list[bytes] = field(default_factory=list)
