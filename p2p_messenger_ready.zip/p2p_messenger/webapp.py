"""
Веб-интерфейс мессенджера: Flask-бэкенд поверх того же ядра (Peer/auth/
crypto), что и CLI/GUI — никакой сетевой или криптологики здесь не
дублируется, только HTTP-обвязка и раздача статического SPA-фронтенда.

Обновления в реальном времени сделаны через короткий polling
(GET /api/events?since=N) — это надёжно работает в любом браузере без
дополнительных зависимостей (websocket-серверов, eventlet и т.п.) и вполне
достаточно для локального P2P-чата.
"""

from __future__ import annotations

import logging
import mimetypes
import os
import secrets
import threading
import time
import webbrowser
from pathlib import Path
from typing import Any, Optional

from flask import Flask, jsonify, request, send_file, session

from .auth import AccountStore, AuthError
from .config import CONFIG
from .crypto_utils import CryptoError
from .discovery import DiscoveredPeer
from .nat_punch import NatPunchError
from .peer import Peer
from .storage import FavoritesStore, GroupsStore

logger = logging.getLogger("p2p_messenger.webapp")

WEB_HOST = os.environ.get("P2P_WEB_HOST", "127.0.0.1")
WEB_PORT = int(os.environ.get("P2P_WEB_PORT", 8765))
MAX_EVENTS_KEPT = 500

# Групповые/канальные сообщения едут поверх обычного зашифрованного CHAT
# (см. Peer.send_chat) - никаких изменений в протоколе/крипто не требуется.
# Чтобы отличить их от личных сообщений, текст оборачивается служебным
# префиксом, который клиент (веб-слой) распознаёт и разворачивает обратно;
# как обычный текст этот префикс никогда не появится в интерфейсе.
GROUP_MARKER = "\u0002P2PGRP\u0002"

# Каталог с превью-пригодными вложениями (фото/видео/файлы), отдаётся через
# /api/media/<filename> для показа прямо в чате (не как "скачивание").
MEDIA_DIR_NAME = "media_files"

IMAGE_EXTS = {".png", ".jpg", ".jpeg", ".gif", ".webp", ".bmp", ".svg"}
VIDEO_EXTS = {".mp4", ".webm", ".ogg", ".mov", ".m4v"}


def _guess_kind(filename: str) -> str:
    ext = Path(filename).suffix.lower()
    if ext in IMAGE_EXTS:
        return "image"
    if ext in VIDEO_EXTS:
        return "video"
    return "file"


class WebPeerState:
    """Обёртка над Peer, копящая события в очередь для HTTP polling'а."""

    def __init__(self, peer: Peer, groups: "GroupsStore"):
        self.peer = peer
        self.groups = groups
        self._events: list[dict[str, Any]] = []
        self._next_id = 1
        self._lock = threading.Lock()

        peer.on_chat_message = self._on_chat
        peer.on_event = self._on_event
        peer.on_discovery_update = self._on_discovery
        peer.on_file_received = self._on_file

    def _push(self, kind: str, data: dict[str, Any]) -> None:
        with self._lock:
            event = {"id": self._next_id, "kind": kind, "ts": time.time(), **data}
            self._next_id += 1
            self._events.append(event)
            if len(self._events) > MAX_EVENTS_KEPT:
                self._events = self._events[-MAX_EVENTS_KEPT:]

    def _on_chat(self, sender: str, text: str) -> None:
        if text.startswith(GROUP_MARKER):
            self._handle_incoming_group_message(sender, text[len(GROUP_MARKER):])
            return
        self._push("chat", {"peer": sender, "text": text, "direction": "in"})

    def _handle_incoming_group_message(self, sender: str, raw: str) -> None:
        import json as _json

        try:
            payload = _json.loads(raw)
            gid = payload["gid"]
            text = payload["text"]
        except (ValueError, KeyError, TypeError):
            return
        group = self.groups.get(gid)
        # Отбрасываем сообщения от тех, кто не(уже не) состоит в группе -
        # защита от "мусора" от вышедших участников.
        if group is None or sender not in group.get("members", []):
            return
        self.peer.history.append(f"grp_{gid}", "in", text, meta={"sender": sender})
        self._push("group", {"gid": gid, "peer": sender, "text": text})

    def _on_event(self, ev_kind: str, message: str) -> None:
        self._push("status", {"status": ev_kind, "message": message})

    def _on_discovery(self, discovered: DiscoveredPeer) -> None:
        self._push(
            "discovery",
            {
                "peer": {
                    "name": discovered.name,
                    "address": discovered.address,
                    "tcp_port": discovered.tcp_port,
                    "username": discovered.username,
                    "bio": discovered.bio,
                }
            },
        )

    def _on_file(self, peer_name: str, filename: str, size: int, saved_path: str) -> None:
        mime = mimetypes.guess_type(filename)[0] or "application/octet-stream"
        # NB: ключ называется "media_kind", а не "kind" - поле верхнего уровня
        # события уже называется "kind" (тип события для диспетчеризации в
        # JS: chat/status/file/...), и одинаковое имя приводило бы к тому,
        # что при слиянии словарей в _push() "kind" из meta (image/video/file)
        # молча перезаписывал бы "kind" события ("file"), ломая обработку
        # на клиенте.
        meta = {"filename": filename, "size": size, "mime": mime, "media_kind": _guess_kind(filename)}
        self.peer.history.append(peer_name, "in", f"\U0001F4CE {filename}", kind="file", meta=meta)
        self._push("file", {"peer": peer_name, "direction": "in", **meta})

    def events_since(self, since_id: int) -> list[dict[str, Any]]:
        with self._lock:
            return [e for e in self._events if e["id"] > since_id]


class PeerRegistry:
    """Реестр запущенных узлов (по одному на вошедший в систему ник)."""

    def __init__(self, groups: "GroupsStore"):
        self._states: dict[str, WebPeerState] = {}
        self._lock = threading.Lock()
        self._groups = groups

    def get(self, nickname: str) -> Optional[WebPeerState]:
        with self._lock:
            return self._states.get(nickname.lower())

    def start(
        self,
        nickname: str,
        password: str,
        preferred_port: int,
        username: str = "",
        bio: str = "",
        avatar: str = "",
    ) -> WebPeerState:
        with self._lock:
            existing = self._states.get(nickname.lower())
            if existing is not None:
                return existing

            port = _find_free_port(preferred_port)
            peer = Peer(
                name=nickname, tcp_port=port, key_password=password,
                username=username, bio=bio, avatar=avatar,
            )
            peer.start()
            state = WebPeerState(peer, self._groups)
            self._states[nickname.lower()] = state
            return state

    def stop(self, nickname: str) -> None:
        with self._lock:
            state = self._states.pop(nickname.lower(), None)
        if state is not None:
            state.peer.stop()

    def stop_all(self) -> None:
        with self._lock:
            states, self._states = list(self._states.values()), {}
        for state in states:
            state.peer.stop()


def _find_free_port(preferred: int, attempts: int = 25) -> int:
    import socket

    for candidate in range(preferred, preferred + attempts):
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
            try:
                s.bind(("0.0.0.0", candidate))
                return candidate
            except OSError:
                continue
    raise OSError("Не удалось найти свободный порт для входящих соединений")


def _secret_key() -> bytes:
    CONFIG.ensure_dirs()
    path = CONFIG.data_dir / "flask_secret.key"
    if path.exists():
        return path.read_bytes()
    key = secrets.token_bytes(32)
    path.write_bytes(key)
    try:
        os.chmod(path, 0o600)
    except OSError:
        pass
    return key


def create_app() -> Flask:
    base_dir = Path(__file__).resolve().parent
    app = Flask(
        __name__,
        static_folder=str(base_dir / "static"),
        template_folder=str(base_dir / "templates"),
    )
    app.secret_key = _secret_key()

    accounts = AccountStore()
    favorites = FavoritesStore()
    groups = GroupsStore()
    registry = PeerRegistry(groups)
    app.peer_registry = registry  # доступно тестам для чистой остановки узлов между тестами

    # ------------------------------------------------------------------ #
    # Вспомогательное
    # ------------------------------------------------------------------ #

    def current_state() -> Optional[WebPeerState]:
        nickname = session.get("nickname")
        if not nickname:
            return None
        return registry.get(nickname)

    def require_state():
        state = current_state()
        if state is None:
            return None, (jsonify(error="Требуется вход в систему."), 401)
        return state, None

    # ------------------------------------------------------------------ #
    # Страницы
    # ------------------------------------------------------------------ #

    @app.get("/")
    def index():
        return (base_dir / "templates" / "index.html").read_text(encoding="utf-8")

    # ------------------------------------------------------------------ #
    # Аутентификация
    # ------------------------------------------------------------------ #

    @app.get("/api/session")
    def api_session():
        state = current_state()
        if state is None:
            return jsonify(logged_in=False)
        account = accounts.get(state.peer.name)
        return jsonify(
            logged_in=True,
            nickname=state.peer.name,
            port=state.peer.tcp_port,
            username=account.username if account else "",
        )

    @app.post("/api/register")
    def api_register():
        body = request.get_json(force=True, silent=True) or {}
        nickname = (body.get("nickname") or "").strip()
        password = body.get("password") or ""
        # Порт для входящих P2P-соединений выбирается автоматически (первый
        # свободный начиная с CONFIG.tcp_port) - пользователь его не вводит
        # и не может случайно выбрать порт, занятый другим приложением.
        try:
            port = _find_free_port(CONFIG.tcp_port)
        except OSError as exc:
            return jsonify(error=str(exc)), 500
        try:
            account = accounts.register(nickname, password, port)
            state = registry.start(
                nickname, password, port,
                username=account.username, bio=account.bio, avatar=account.avatar,
            )
        except AuthError as exc:
            return jsonify(error=str(exc)), 400
        except (OSError, CryptoError) as exc:
            return jsonify(error=str(exc)), 500

        session["nickname"] = state.peer.name
        return jsonify(ok=True, nickname=state.peer.name, port=state.peer.tcp_port, username=account.username)

    @app.post("/api/login")
    def api_login():
        body = request.get_json(force=True, silent=True) or {}
        nickname = (body.get("nickname") or "").strip()
        password = body.get("password") or ""
        try:
            account = accounts.verify(nickname, password)
            state = registry.start(
                account.nickname, password, account.tcp_port,
                username=account.username, bio=account.bio, avatar=account.avatar,
            )
        except AuthError as exc:
            return jsonify(error=str(exc)), 400
        except CryptoError as exc:
            return jsonify(error=str(exc)), 400
        except OSError as exc:
            return jsonify(error=str(exc)), 500

        # Восстанавливаем сохранённую настройку видимости в LAN-обнаружении
        # (узел мог быть запущен впервые в этом процессе только что выше).
        state.peer.set_discoverable(account.discoverable)

        session["nickname"] = state.peer.name
        return jsonify(ok=True, nickname=state.peer.name, port=state.peer.tcp_port, username=account.username)

    @app.get("/api/profile")
    def api_profile_get():
        nickname = session.get("nickname")
        if not nickname:
            return jsonify(error="Требуется вход в систему."), 401
        account = accounts.get(nickname)
        if account is None:
            return jsonify(error="Аккаунт не найден."), 404
        return jsonify(
            nickname=account.nickname,
            username=account.username,
            bio=account.bio,
            avatar=account.avatar,
            port=account.tcp_port,
            discoverable=account.discoverable,
        )

    @app.post("/api/profile")
    def api_profile_update():
        nickname = session.get("nickname")
        if not nickname:
            return jsonify(error="Требуется вход в систему."), 401
        body = request.get_json(force=True, silent=True) or {}
        bio = body.get("bio")
        avatar = body.get("avatar")
        username = body.get("username")
        discoverable = body.get("discoverable")
        if username is not None:
            username = str(username).strip().lstrip("@")
        try:
            account = accounts.update_profile(
                nickname,
                bio=bio.strip() if isinstance(bio, str) else None,
                avatar=avatar if isinstance(avatar, str) else None,
                username=username if isinstance(username, str) and username else None,
                discoverable=bool(discoverable) if isinstance(discoverable, bool) else None,
            )
        except AuthError as exc:
            return jsonify(error=str(exc)), 400

        state = current_state()
        if state is not None and isinstance(discoverable, bool):
            state.peer.set_discoverable(discoverable)
        if state is not None and username:
            # Рассылаем новый @username сразу, не дожидаясь перезапуска узла.
            state.peer.set_username(account.username)
        if state is not None and (bio is not None or avatar is not None):
            # Аналогично - обновляем профиль, отдаваемый другим узлам по
            # PROFILE_REQUEST, сразу, не дожидаясь перезапуска узла.
            state.peer.set_profile(bio=account.bio, avatar=account.avatar)

        return jsonify(
            ok=True,
            bio=account.bio,
            avatar=account.avatar,
            username=account.username,
            discoverable=account.discoverable,
        )

    @app.post("/api/logout")
    def api_logout():
        nickname = session.pop("nickname", None)
        if nickname:
            registry.stop(nickname)
        return jsonify(ok=True)

    # ------------------------------------------------------------------ #
    # Данные приложения
    # ------------------------------------------------------------------ #

    def _find_address(state: WebPeerState, peer_name: str) -> Optional[tuple[str, int]]:
        """
        Найти реальный address:port узла по нику - из свежего LAN-обнаружения,
        а если сейчас не виден в эфире, то из ранее сохранённых контактов
        (у каждого узла в сети всегда свой собственный IP, полученный
        автоматически - вручную его никто не вводит).
        """
        for p in state.peer.get_discovered_peers():
            if p.name == peer_name:
                return p.address, p.tcp_port
        contact = state.peer.contacts.get(peer_name)
        if contact:
            return contact["address"], contact["tcp_port"]
        return None

    def _ensure_connected(state: WebPeerState, peer_name: str) -> bool:
        """Если сессии с peer_name ещё нет - подключиться автоматически по его известному IP."""
        if peer_name in state.peer.get_active_sessions():
            return True
        addr = _find_address(state, peer_name)
        if addr is None:
            return False
        try:
            state.peer.connect_to(addr[0], addr[1])
            return True
        except (OSError, TimeoutError):
            return False

    @app.get("/api/peers")
    def api_peers():
        state, err = require_state()
        if err:
            return err
        peers = state.peer.get_discovered_peers()
        return jsonify(
            peers=[
                {
                    "name": p.name,
                    "address": p.address,
                    "tcp_port": p.tcp_port,
                    "username": p.username,
                    "bio": p.bio,
                }
                for p in peers
            ]
        )

    # ------------------------------------------------------------------ #
    # Избранное
    # ------------------------------------------------------------------ #

    @app.get("/api/favorites")
    def api_favorites_list():
        state, err = require_state()
        if err:
            return err
        return jsonify(favorites=favorites.list_for(state.peer.name))

    @app.post("/api/favorites/<peer_name>")
    def api_favorites_add(peer_name: str):
        state, err = require_state()
        if err:
            return err
        return jsonify(favorites=favorites.add(state.peer.name, peer_name))

    @app.delete("/api/favorites/<peer_name>")
    def api_favorites_remove(peer_name: str):
        state, err = require_state()
        if err:
            return err
        return jsonify(favorites=favorites.remove(state.peer.name, peer_name))

    # ------------------------------------------------------------------ #
    # Просмотр профиля другого пользователя
    # ------------------------------------------------------------------ #

    @app.get("/api/profile/<peer_name>")
    def api_profile_view(peer_name: str):
        state, err = require_state()
        if err:
            return err
        if peer_name == state.peer.name:
            return jsonify(
                nickname=state.peer.name, username=state.peer.username,
                bio=state.peer.bio, avatar=state.peer.avatar, online=True, connected=True,
            )

        discovered = next((p for p in state.peer.get_discovered_peers() if p.name == peer_name), None)
        online = discovered is not None

        connected = _ensure_connected(state, peer_name)
        if connected:
            full = state.peer.request_profile(peer_name, timeout=3.0)
            if full is not None:
                return jsonify(
                    nickname=peer_name, username=full.get("username", ""),
                    bio=full.get("bio", ""), avatar=full.get("avatar", ""),
                    online=online, connected=True,
                )

        # Не удалось получить полный профиль (собеседник офлайн/не отвечает) -
        # отдаём то, что уже знаем: юзернейм/био из последнего анонса обнаружения.
        return jsonify(
            nickname=peer_name,
            username=(discovered.username if discovered else ""),
            bio=(discovered.bio if discovered else ""),
            avatar="",
            online=online,
            connected=False,
        )

    @app.get("/api/sessions")
    def api_sessions():
        state, err = require_state()
        if err:
            return err
        return jsonify(sessions=state.peer.get_active_sessions())

    @app.post("/api/connect")
    def api_connect():
        state, err = require_state()
        if err:
            return err
        body = request.get_json(force=True, silent=True) or {}
        address = (body.get("address") or "").strip()
        try:
            port = int(body.get("port"))
        except (TypeError, ValueError):
            return jsonify(error="Некорректный порт."), 400
        try:
            name = state.peer.connect_to(address, port)
        except (OSError, TimeoutError) as exc:
            return jsonify(error=f"Не удалось подключиться: {exc}"), 400
        return jsonify(ok=True, peer=name)

    @app.get("/api/invite-code")
    def api_invite_code():
        """
        Генерирует инвайт-код для подключения без сигнального сервера.
        Код нужно передать собеседнику вне приложения (скопировать,
        отправить в другом мессенджере, показать как QR и т.п.).
        """
        state, err = require_state()
        if err:
            return err
        try:
            code = state.peer.generate_invite_code()
        except Exception as exc:  # noqa: BLE001 - UPnP/сеть могут отказать по многу причин
            return jsonify(error=f"Не удалось сформировать инвайт-код: {exc}"), 500
        return jsonify(ok=True, invite_code=code)

    @app.post("/api/invite-code")
    def api_invite_code_connect():
        """
        Принимает инвайт-код собеседника и пытается пробить NAT напрямую
        (без сервера). Собеседник должен быть онлайн и его приложение -
        слушать порт из кода примерно в это же время (simultaneous open).
        """
        state, err = require_state()
        if err:
            return err
        body = request.get_json(force=True, silent=True) or {}
        code = (body.get("invite_code") or "").strip()
        if not code:
            return jsonify(error="Инвайт-код не передан."), 400
        try:
            name = state.peer.connect_via_invite(code)
        except NatPunchError as exc:
            return jsonify(error=str(exc)), 400
        except (OSError, TimeoutError) as exc:
            return jsonify(error=f"Не удалось подключиться по инвайт-коду: {exc}"), 400
        return jsonify(ok=True, peer=name)

    @app.post("/api/send")
    def api_send():
        state, err = require_state()
        if err:
            return err
        body = request.get_json(force=True, silent=True) or {}
        peer_name = (body.get("peer") or "").strip()
        text = body.get("text") or ""
        if not text.strip():
            return jsonify(error="Пустое сообщение."), 400
        # Ручного подключения в интерфейсе больше нет - если сессии с этим
        # узлом ещё нет, подключаемся автоматически по его собственному IP,
        # известному из LAN-обнаружения или контактов.
        _ensure_connected(state, peer_name)
        try:
            state.peer.send_chat(peer_name, text)
        except ConnectionError as exc:
            return jsonify(error=str(exc)), 400
        return jsonify(ok=True)

    def _store_upload_to_media(uploaded) -> tuple[Path, str, dict[str, Any]]:
        """Сохранить загруженный файл в постоянный media_files (не во временную папку),
        чтобы вложение можно было превью/скачать снова после перезагрузки страницы."""
        media_dir = CONFIG.data_dir / MEDIA_DIR_NAME
        media_dir.mkdir(parents=True, exist_ok=True)
        safe_name = "".join(c for c in uploaded.filename if c.isalnum() or c in "._-") or "file"
        token_name = f"{secrets.token_hex(8)}_{safe_name}"
        path = media_dir / token_name
        uploaded.save(path)
        size = path.stat().st_size
        mime = mimetypes.guess_type(safe_name)[0] or "application/octet-stream"
        meta = {
            "filename": token_name, "original_name": safe_name, "size": size,
            "mime": mime, "media_kind": _guess_kind(safe_name),
        }
        return path, token_name, meta

    @app.post("/api/file")
    def api_file():
        state, err = require_state()
        if err:
            return err
        peer_name = (request.form.get("peer") or "").strip()
        uploaded = request.files.get("file")
        if not peer_name or uploaded is None or not uploaded.filename:
            return jsonify(error="Не указан файл или собеседник."), 400

        path, token_name, meta = _store_upload_to_media(uploaded)
        _ensure_connected(state, peer_name)
        try:
            state.peer.send_file(peer_name, str(path))
        except (ConnectionError, FileNotFoundError) as exc:
            return jsonify(error=str(exc)), 400

        state.peer.history.append(
            peer_name, "out", f"\U0001F4CE {meta['original_name']}", kind="file", meta=meta
        )
        return jsonify(ok=True, **meta)

    @app.get("/api/history/<peer_name>")
    def api_history(peer_name: str):
        state, err = require_state()
        if err:
            return err
        history = [
            rec for rec in state.peer.history.read_all(peer_name)
            if not rec.get("text", "").startswith(GROUP_MARKER)
        ]
        return jsonify(history=history)

    # ------------------------------------------------------------------ #
    # Группы и каналы
    # ------------------------------------------------------------------ #

    @app.get("/api/groups")
    def api_groups_list():
        state, err = require_state()
        if err:
            return err
        online = set(state.peer.get_active_sessions()) | {
            p.name for p in state.peer.get_discovered_peers()
        }
        result = []
        for g in groups.for_member(state.peer.name):
            entry = dict(g)
            entry["members_online"] = [m for m in g["members"] if m in online or m == state.peer.name]
            result.append(entry)
        return jsonify(groups=result)

    @app.post("/api/groups")
    def api_groups_create():
        state, err = require_state()
        if err:
            return err
        body = request.get_json(force=True, silent=True) or {}
        name = (body.get("name") or "").strip()
        kind = body.get("kind") if body.get("kind") in ("group", "channel") else "group"
        members = [m.strip() for m in (body.get("members") or []) if isinstance(m, str) and m.strip()]
        if not name:
            return jsonify(error="Укажите название группы/канала."), 400
        entry = groups.create(name, kind, state.peer.name, members)
        return jsonify(group=entry)

    def _require_group(gid: str, state: WebPeerState):
        group = groups.get(gid)
        if group is None or state.peer.name not in group.get("members", []):
            return None
        return group

    @app.get("/api/groups/<gid>")
    def api_groups_get(gid: str):
        state, err = require_state()
        if err:
            return err
        group = _require_group(gid, state)
        if group is None:
            return jsonify(error="Группа не найдена."), 404
        online = set(state.peer.get_active_sessions()) | {p.name for p in state.peer.get_discovered_peers()}
        entry = dict(group)
        entry["members_online"] = [m for m in group["members"] if m in online or m == state.peer.name]
        return jsonify(group=entry)

    @app.post("/api/groups/<gid>/members")
    def api_groups_add_member(gid: str):
        state, err = require_state()
        if err:
            return err
        group = _require_group(gid, state)
        if group is None:
            return jsonify(error="Группа не найдена."), 404
        if group["owner"] != state.peer.name:
            return jsonify(error="Добавлять участников может только владелец."), 403
        body = request.get_json(force=True, silent=True) or {}
        member = (body.get("nickname") or "").strip()
        if not member:
            return jsonify(error="Укажите ник участника."), 400
        entry = groups.add_member(gid, member)
        return jsonify(group=entry)

    @app.delete("/api/groups/<gid>/members/<member_name>")
    def api_groups_remove_member(gid: str, member_name: str):
        state, err = require_state()
        if err:
            return err
        group = _require_group(gid, state)
        if group is None:
            return jsonify(error="Группа не найдена."), 404
        # Владелец может удалить любого; остальные - только сами себя (выйти).
        if group["owner"] != state.peer.name and member_name != state.peer.name:
            return jsonify(error="Недостаточно прав."), 403
        entry = groups.remove_member(gid, member_name)
        return jsonify(group=entry)

    @app.delete("/api/groups/<gid>")
    def api_groups_delete(gid: str):
        state, err = require_state()
        if err:
            return err
        group = _require_group(gid, state)
        if group is None:
            return jsonify(error="Группа не найдена."), 404
        if group["owner"] == state.peer.name:
            groups.delete(gid)
        else:
            groups.remove_member(gid, state.peer.name)  # выйти из чужой группы
        return jsonify(ok=True)

    def _fanout_group(state: WebPeerState, group: dict, sender_func) -> list[str]:
        """Разослать сообщение/файл всем участникам группы (кроме себя), автоматически
        подключаясь к каждому по его собственному IP, если ещё не подключены."""
        failed = []
        for member in group["members"]:
            if member == state.peer.name:
                continue
            if not _ensure_connected(state, member):
                failed.append(member)
                continue
            try:
                sender_func(member)
            except (ConnectionError, FileNotFoundError):
                failed.append(member)
        return failed

    @app.post("/api/groups/<gid>/send")
    def api_groups_send(gid: str):
        state, err = require_state()
        if err:
            return err
        group = _require_group(gid, state)
        if group is None:
            return jsonify(error="Группа не найдена."), 404
        if group["kind"] == "channel" and group["owner"] != state.peer.name:
            return jsonify(error="В этом канале писать может только владелец."), 403
        body = request.get_json(force=True, silent=True) or {}
        text = (body.get("text") or "").strip()
        if not text:
            return jsonify(error="Пустое сообщение."), 400

        import json as _json

        wire_text = GROUP_MARKER + _json.dumps({"gid": gid, "gname": group["name"], "text": text})
        failed = _fanout_group(state, group, lambda member: state.peer.send_chat(member, wire_text))
        state.peer.history.append(f"grp_{gid}", "out", text, meta={"sender": state.peer.name})
        return jsonify(ok=True, failed=failed)

    @app.post("/api/groups/<gid>/file")
    def api_groups_file(gid: str):
        state, err = require_state()
        if err:
            return err
        group = _require_group(gid, state)
        if group is None:
            return jsonify(error="Группа не найдена."), 404
        if group["kind"] == "channel" and group["owner"] != state.peer.name:
            return jsonify(error="В этом канале писать может только владелец."), 403
        uploaded = request.files.get("file")
        if uploaded is None or not uploaded.filename:
            return jsonify(error="Не указан файл."), 400

        path, token_name, meta = _store_upload_to_media(uploaded)
        failed = _fanout_group(state, group, lambda member: state.peer.send_file(member, str(path)))
        state.peer.history.append(
            f"grp_{gid}", "out", f"\U0001F4CE {meta['original_name']}",
            kind="file", meta={**meta, "sender": state.peer.name},
        )
        return jsonify(ok=True, failed=failed, **meta)

    @app.get("/api/groups/<gid>/history")
    def api_groups_history(gid: str):
        state, err = require_state()
        if err:
            return err
        group = _require_group(gid, state)
        if group is None:
            return jsonify(error="Группа не найдена."), 404
        return jsonify(history=state.peer.history.read_all(f"grp_{gid}"))

    @app.get("/api/events")
    def api_events():
        state, err = require_state()
        if err:
            return err
        since = request.args.get("since", "0")
        try:
            since_id = int(since)
        except ValueError:
            since_id = 0
        return jsonify(events=state.events_since(since_id))

    def _resolve_media_path(filename: str) -> Optional[Path]:
        safe_name = Path(filename).name  # защита от path traversal
        for sub in (MEDIA_DIR_NAME, "received_files"):
            candidate = CONFIG.data_dir / sub / safe_name
            if candidate.is_file():
                return candidate
        return None

    @app.get("/api/download/<peer_name>/<path:filename>")
    def api_download(peer_name: str, filename: str):
        state, err = require_state()
        if err:
            return err
        path = _resolve_media_path(filename)
        if path is None:
            return jsonify(error="Файл не найден."), 404
        return send_file(path, as_attachment=True, download_name=path.name.split("_", 1)[-1])

    @app.get("/api/media/<path:filename>")
    def api_media(filename: str):
        """Отдаёт вложение "инлайново" (для <img>/<video> в чате), а не как скачивание."""
        state, err = require_state()
        if err:
            return err
        path = _resolve_media_path(filename)
        if path is None:
            return jsonify(error="Файл не найден."), 404
        mime = mimetypes.guess_type(path.name)[0] or "application/octet-stream"
        return send_file(path, as_attachment=False, mimetype=mime, conditional=True)

    return app


def run_web_app() -> int:
    logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(levelname)s] %(name)s: %(message)s")
    app = create_app()

    # На Android/Pydroid 3 порт веб-интерфейса иногда остаётся "занятым"
    # ненадолго после предыдущего запуска (система не всегда мгновенно
    # освобождает сокет, когда приложение было закрыто через недавние
    # задачи, а не штатно). Чтобы это не превращалось в необъяснимый крэш
    # при повторном запуске, подбираем свободный порт рядом с желаемым.
    port = _find_free_port(WEB_PORT)
    url = f"http://{WEB_HOST}:{port}"
    print(f"=== p2p_messenger веб-интерфейс запущен: {url} ===")
    print("Откройте этот адрес в браузере на этом устройстве, если он не откроется сам.")

    def _open_browser() -> None:
        time.sleep(0.7)
        try:
            webbrowser.open(url)
        except Exception:  # noqa: BLE001 - открытие браузера не критично для работы
            # На некоторых сборках Pydroid 3 автооткрытие системного браузера
            # может не сработать — это не ошибка приложения, адрес выше
            # всё равно можно открыть вручную.
            pass

    threading.Thread(target=_open_browser, daemon=True).start()
    try:
        app.run(host=WEB_HOST, port=port, debug=False, use_reloader=False, threaded=True)
    except OSError as exc:
        print(f"Не удалось запустить веб-сервер на {WEB_HOST}:{port}: {exc}")
        return 1
    return 0


def run_android_webapp() -> int:
    """
    "Голая" часть Android-запуска: считается, что порт уже занят заглушкой
    из p2p_messenger/android_boot.py (см. её докстринг — там же объяснено,
    почему сама подмена порта и обработка сбоя импорта вынесены в отдельный
    модуль на чистой стандартной библиотеке). Эта функция вызывается
    android_boot.run_android() уже ПОСЛЕ успешного импорта и создания
    Flask-приложения, поэтому здесь остаётся только сам app.run().

    Оставлена как отдельная функция (а не инлайн в android_boot.py), чтобы
    десктопные тесты и ручной запуск могли по-прежнему дергать её напрямую
    при необходимости.
    """
    logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(levelname)s] %(name)s: %(message)s")
    app = create_app()
    try:
        app.run(host="127.0.0.1", port=5000, debug=False, use_reloader=False, threaded=True)
    except OSError as exc:
        logger.exception("Не удалось запустить локальный веб-сервер на 127.0.0.1:5000: %s", exc)
        return 1
    return 0
