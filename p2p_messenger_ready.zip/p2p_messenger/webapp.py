"""
Веб-интерфейс мессенджера: Flask-бэкенд поверх того же ядра (Peer/auth/
crypto), что и CLI/GUI — никакой сетевой или криптологики здесь не
дублируется, только HTTP-обвязка и раздача статического SPA-фронтенда.

Обновления в реальном времени сделаны через короткий polling
(GET /api/events?since=N) — это надёжно работает в любом браузере без
дополнительных зависимостей (websocket-серверов, eventlet и т.п.) и вполне
достаточно для локального P2P-чата.
"""

from __future__ import annotations

import logging
import os
import secrets
import threading
import time
import traceback
import webbrowser
from html import escape
from http.server import BaseHTTPRequestHandler, HTTPServer
from pathlib import Path
from typing import Any, Optional

from flask import Flask, jsonify, request, send_file, session

from .auth import AccountStore, AuthError
from .config import CONFIG
from .crypto_utils import CryptoError
from .discovery import DiscoveredPeer
from .peer import Peer

logger = logging.getLogger("p2p_messenger.webapp")

WEB_HOST = os.environ.get("P2P_WEB_HOST", "127.0.0.1")
WEB_PORT = int(os.environ.get("P2P_WEB_PORT", 8765))
MAX_EVENTS_KEPT = 500


class WebPeerState:
    """Обёртка над Peer, копящая события в очередь для HTTP polling'а."""

    def __init__(self, peer: Peer):
        self.peer = peer
        self._events: list[dict[str, Any]] = []
        self._next_id = 1
        self._lock = threading.Lock()

        peer.on_chat_message = self._on_chat
        peer.on_event = self._on_event
        peer.on_discovery_update = self._on_discovery

    def _push(self, kind: str, data: dict[str, Any]) -> None:
        with self._lock:
            event = {"id": self._next_id, "kind": kind, "ts": time.time(), **data}
            self._next_id += 1
            self._events.append(event)
            if len(self._events) > MAX_EVENTS_KEPT:
                self._events = self._events[-MAX_EVENTS_KEPT:]

    def _on_chat(self, sender: str, text: str) -> None:
        self._push("chat", {"peer": sender, "text": text, "direction": "in"})

    def _on_event(self, ev_kind: str, message: str) -> None:
        self._push("status", {"status": ev_kind, "message": message})

    def _on_discovery(self, discovered: DiscoveredPeer) -> None:
        self._push(
            "discovery",
            {
                "peer": {
                    "name": discovered.name,
                    "address": discovered.address,
                    "tcp_port": discovered.tcp_port,
                    "username": discovered.username,
                }
            },
        )

    def events_since(self, since_id: int) -> list[dict[str, Any]]:
        with self._lock:
            return [e for e in self._events if e["id"] > since_id]


class PeerRegistry:
    """Реестр запущенных узлов (по одному на вошедший в систему ник)."""

    def __init__(self):
        self._states: dict[str, WebPeerState] = {}
        self._lock = threading.Lock()

    def get(self, nickname: str) -> Optional[WebPeerState]:
        with self._lock:
            return self._states.get(nickname.lower())

    def start(self, nickname: str, password: str, preferred_port: int, username: str = "") -> WebPeerState:
        with self._lock:
            existing = self._states.get(nickname.lower())
            if existing is not None:
                return existing

            port = _find_free_port(preferred_port)
            peer = Peer(name=nickname, tcp_port=port, key_password=password, username=username)
            peer.start()
            state = WebPeerState(peer)
            self._states[nickname.lower()] = state
            return state

    def stop(self, nickname: str) -> None:
        with self._lock:
            state = self._states.pop(nickname.lower(), None)
        if state is not None:
            state.peer.stop()

    def stop_all(self) -> None:
        with self._lock:
            states, self._states = list(self._states.values()), {}
        for state in states:
            state.peer.stop()


def _find_free_port(preferred: int, attempts: int = 25) -> int:
    import socket

    for candidate in range(preferred, preferred + attempts):
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
            try:
                s.bind(("0.0.0.0", candidate))
                return candidate
            except OSError:
                continue
    raise OSError("Не удалось найти свободный порт для входящих соединений")


def _secret_key() -> bytes:
    CONFIG.ensure_dirs()
    path = CONFIG.data_dir / "flask_secret.key"
    if path.exists():
        return path.read_bytes()
    key = secrets.token_bytes(32)
    path.write_bytes(key)
    try:
        os.chmod(path, 0o600)
    except OSError:
        pass
    return key


def create_app() -> Flask:
    base_dir = Path(__file__).resolve().parent
    app = Flask(
        __name__,
        static_folder=str(base_dir / "static"),
        template_folder=str(base_dir / "templates"),
    )
    app.secret_key = _secret_key()

    accounts = AccountStore()
    registry = PeerRegistry()
    app.peer_registry = registry  # доступно тестам для чистой остановки узлов между тестами

    # ------------------------------------------------------------------ #
    # Вспомогательное
    # ------------------------------------------------------------------ #

    def current_state() -> Optional[WebPeerState]:
        nickname = session.get("nickname")
        if not nickname:
            return None
        return registry.get(nickname)

    def require_state():
        state = current_state()
        if state is None:
            return None, (jsonify(error="Требуется вход в систему."), 401)
        return state, None

    # ------------------------------------------------------------------ #
    # Страницы
    # ------------------------------------------------------------------ #

    @app.get("/")
    def index():
        return (base_dir / "templates" / "index.html").read_text(encoding="utf-8")

    # ------------------------------------------------------------------ #
    # Аутентификация
    # ------------------------------------------------------------------ #

    @app.get("/api/session")
    def api_session():
        state = current_state()
        if state is None:
            return jsonify(logged_in=False)
        account = accounts.get(state.peer.name)
        return jsonify(
            logged_in=True,
            nickname=state.peer.name,
            port=state.peer.tcp_port,
            username=account.username if account else "",
        )

    @app.post("/api/register")
    def api_register():
        body = request.get_json(force=True, silent=True) or {}
        nickname = (body.get("nickname") or "").strip()
        password = body.get("password") or ""
        port = int(body.get("port") or CONFIG.tcp_port)
        try:
            account = accounts.register(nickname, password, port)
            state = registry.start(nickname, password, port, username=account.username)
        except AuthError as exc:
            return jsonify(error=str(exc)), 400
        except (OSError, CryptoError) as exc:
            return jsonify(error=str(exc)), 500

        session["nickname"] = state.peer.name
        return jsonify(ok=True, nickname=state.peer.name, port=state.peer.tcp_port, username=account.username)

    @app.post("/api/login")
    def api_login():
        body = request.get_json(force=True, silent=True) or {}
        nickname = (body.get("nickname") or "").strip()
        password = body.get("password") or ""
        try:
            account = accounts.verify(nickname, password)
            state = registry.start(account.nickname, password, account.tcp_port, username=account.username)
        except AuthError as exc:
            return jsonify(error=str(exc)), 400
        except CryptoError as exc:
            return jsonify(error=str(exc)), 400
        except OSError as exc:
            return jsonify(error=str(exc)), 500

        # Восстанавливаем сохранённую настройку видимости в LAN-обнаружении
        # (узел мог быть запущен впервые в этом процессе только что выше).
        state.peer.set_discoverable(account.discoverable)

        session["nickname"] = state.peer.name
        return jsonify(ok=True, nickname=state.peer.name, port=state.peer.tcp_port, username=account.username)

    @app.get("/api/profile")
    def api_profile_get():
        nickname = session.get("nickname")
        if not nickname:
            return jsonify(error="Требуется вход в систему."), 401
        account = accounts.get(nickname)
        if account is None:
            return jsonify(error="Аккаунт не найден."), 404
        return jsonify(
            nickname=account.nickname,
            username=account.username,
            bio=account.bio,
            avatar=account.avatar,
            port=account.tcp_port,
            discoverable=account.discoverable,
        )

    @app.post("/api/profile")
    def api_profile_update():
        nickname = session.get("nickname")
        if not nickname:
            return jsonify(error="Требуется вход в систему."), 401
        body = request.get_json(force=True, silent=True) or {}
        bio = body.get("bio")
        avatar = body.get("avatar")
        username = body.get("username")
        discoverable = body.get("discoverable")
        if username is not None:
            username = str(username).strip().lstrip("@")
        try:
            account = accounts.update_profile(
                nickname,
                bio=bio.strip() if isinstance(bio, str) else None,
                avatar=avatar if isinstance(avatar, str) else None,
                username=username if isinstance(username, str) and username else None,
                discoverable=bool(discoverable) if isinstance(discoverable, bool) else None,
            )
        except AuthError as exc:
            return jsonify(error=str(exc)), 400

        state = current_state()
        if state is not None and isinstance(discoverable, bool):
            state.peer.set_discoverable(discoverable)
        if state is not None and username:
            # Рассылаем новый @username сразу, не дожидаясь перезапуска узла.
            state.peer.set_username(account.username)

        return jsonify(
            ok=True,
            bio=account.bio,
            avatar=account.avatar,
            username=account.username,
            discoverable=account.discoverable,
        )

    @app.post("/api/logout")
    def api_logout():
        nickname = session.pop("nickname", None)
        if nickname:
            registry.stop(nickname)
        return jsonify(ok=True)

    # ------------------------------------------------------------------ #
    # Данные приложения
    # ------------------------------------------------------------------ #

    @app.get("/api/peers")
    def api_peers():
        state, err = require_state()
        if err:
            return err
        peers = state.peer.get_discovered_peers()
        return jsonify(
            peers=[
                {"name": p.name, "address": p.address, "tcp_port": p.tcp_port, "username": p.username}
                for p in peers
            ]
        )

    @app.get("/api/sessions")
    def api_sessions():
        state, err = require_state()
        if err:
            return err
        return jsonify(sessions=state.peer.get_active_sessions())

    @app.post("/api/connect")
    def api_connect():
        state, err = require_state()
        if err:
            return err
        body = request.get_json(force=True, silent=True) or {}
        address = (body.get("address") or "").strip()
        try:
            port = int(body.get("port"))
        except (TypeError, ValueError):
            return jsonify(error="Некорректный порт."), 400
        try:
            name = state.peer.connect_to(address, port)
        except (OSError, TimeoutError) as exc:
            return jsonify(error=f"Не удалось подключиться: {exc}"), 400
        return jsonify(ok=True, peer=name)

    @app.post("/api/send")
    def api_send():
        state, err = require_state()
        if err:
            return err
        body = request.get_json(force=True, silent=True) or {}
        peer_name = (body.get("peer") or "").strip()
        text = body.get("text") or ""
        if not text.strip():
            return jsonify(error="Пустое сообщение."), 400
        try:
            state.peer.send_chat(peer_name, text)
        except ConnectionError as exc:
            return jsonify(error=str(exc)), 400
        return jsonify(ok=True)

    @app.post("/api/file")
    def api_file():
        state, err = require_state()
        if err:
            return err
        peer_name = (request.form.get("peer") or "").strip()
        uploaded = request.files.get("file")
        if not peer_name or uploaded is None or not uploaded.filename:
            return jsonify(error="Не указан файл или собеседник."), 400

        tmp_dir = CONFIG.data_dir / "outgoing_tmp"
        tmp_dir.mkdir(parents=True, exist_ok=True)
        safe_name = "".join(c for c in uploaded.filename if c.isalnum() or c in "._-") or "file"
        tmp_path = tmp_dir / f"{secrets.token_hex(8)}_{safe_name}"
        uploaded.save(tmp_path)

        try:
            state.peer.send_file(peer_name, str(tmp_path))
        except (ConnectionError, FileNotFoundError) as exc:
            return jsonify(error=str(exc)), 400
        finally:
            try:
                tmp_path.unlink(missing_ok=True)
            except OSError:
                pass
        return jsonify(ok=True)

    @app.get("/api/history/<peer_name>")
    def api_history(peer_name: str):
        state, err = require_state()
        if err:
            return err
        return jsonify(history=state.peer.history.read_all(peer_name))

    @app.get("/api/events")
    def api_events():
        state, err = require_state()
        if err:
            return err
        since = request.args.get("since", "0")
        try:
            since_id = int(since)
        except ValueError:
            since_id = 0
        return jsonify(events=state.events_since(since_id))

    @app.get("/api/download/<peer_name>/<path:filename>")
    def api_download(peer_name: str, filename: str):
        state, err = require_state()
        if err:
            return err
        safe_name = Path(filename).name  # защита от path traversal
        path = CONFIG.data_dir / "received_files" / safe_name
        if not path.is_file():
            return jsonify(error="Файл не найден."), 404
        return send_file(path, as_attachment=True, download_name=safe_name)

    return app


def run_web_app() -> int:
    logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(levelname)s] %(name)s: %(message)s")
    app = create_app()

    # На Android/Pydroid 3 порт веб-интерфейса иногда остаётся "занятым"
    # ненадолго после предыдущего запуска (система не всегда мгновенно
    # освобождает сокет, когда приложение было закрыто через недавние
    # задачи, а не штатно). Чтобы это не превращалось в необъяснимый крэш
    # при повторном запуске, подбираем свободный порт рядом с желаемым.
    port = _find_free_port(WEB_PORT)
    url = f"http://{WEB_HOST}:{port}"
    print(f"=== p2p_messenger веб-интерфейс запущен: {url} ===")
    print("Откройте этот адрес в браузере на этом устройстве, если он не откроется сам.")

    def _open_browser() -> None:
        time.sleep(0.7)
        try:
            webbrowser.open(url)
        except Exception:  # noqa: BLE001 - открытие браузера не критично для работы
            # На некоторых сборках Pydroid 3 автооткрытие системного браузера
            # может не сработать — это не ошибка приложения, адрес выше
            # всё равно можно открыть вручную.
            pass

    threading.Thread(target=_open_browser, daemon=True).start()
    try:
        app.run(host=WEB_HOST, port=port, debug=False, use_reloader=False, threaded=True)
    except OSError as exc:
        print(f"Не удалось запустить веб-сервер на {WEB_HOST}:{port}: {exc}")
        return 1
    return 0


_BOOT_PAGE = """<!doctype html>
<html lang="ru"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>WIRE P2P Messenger</title>
<style>
  body{background:#0f0f12;color:#eaeaea;font-family:sans-serif;
       display:flex;align-items:center;justify-content:center;
       height:100vh;margin:0;text-align:center}
  .spinner{width:36px;height:36px;border-radius:50%;
           border:3px solid #333;border-top-color:#7c7cff;
           animation:spin 0.8s linear infinite;margin:0 auto 16px}
  @keyframes spin{to{transform:rotate(360deg)}}
</style></head>
<body><div>
  <div class="spinner"></div>
  <div>Запуск узла…</div>
</div>
<script>
(function poll(){
  fetch('/__boot_status', {cache:'no-store'}).then(function(r){return r.json();}).then(function(d){
    if (d.status === 'ready') { location.replace('/'); }
    else if (d.status === 'error') { location.reload(); }
    else { setTimeout(poll, 400); }
  }).catch(function(){ setTimeout(poll, 600); });
})();
</script></body></html>"""


def _boot_error_page(tb: str) -> str:
    return (
        "<!doctype html><html lang=\"ru\"><head><meta charset=\"utf-8\">"
        "<meta name=\"viewport\" content=\"width=device-width, initial-scale=1\">"
        "<title>Ошибка запуска</title>"
        "<style>body{background:#1a0f0f;color:#f4d6d6;font-family:monospace;"
        "font-size:13px;padding:16px;white-space:pre-wrap;word-break:break-word}"
        "h1{color:#ff8080;font-size:16px;font-family:sans-serif}</style></head>"
        "<body><h1>Не удалось запустить узел</h1>" + escape(tb) + "</body></html>"
    )


def run_android_webapp() -> int:
    """
    Точка входа для Android-сборки (buildozer, p4a.bootstrap = webview).

    В отличие от run_web_app() (десктоп/Pydroid 3):
      - хост:порт ЖЁСТКО фиксированы на 127.0.0.1:5000 — это порт,
        который по умолчанию открывает нативная WebView-активность
        бутстрапа "webview" в python-for-android. Если сервер слушает
        другой порт, WebView просто не сможет к нему достучаться.
      - никакого webbrowser.open() — сама WebView-активность уже
        открыта поверх процесса и сама загрузит указанный адрес,
        системный браузер тут не нужен и не должен запускаться.
      - никакого _find_free_port() с перебором — на телефоне это
        единственный процесс приложения, порт 5000 гарантированно
        свободен при первом запуске.

    ВАЖНО (борьба с "вечная загрузка" / пустой экран на реальных телефонах):
    системная WebView открывает http://127.0.0.1:5000 сразу при старте
    активности — ещё до того, как в этом же процессе успевает отработать
    код между запуском main.py и вызовом app.run() (импорт cryptography,
    инициализация хранилища и т.п., на первом запуске — секунды). Если
    порт в этот момент ещё не слушается, WebView получает отказ в
    соединении один раз и НЕ переспрашивает сам — в отличие от обычного
    браузера. Хуже того: если инициализация падает необработанным
    исключением (самый частый случай на реальном устройстве — сбой при
    загрузке нативно собранного p4a-рецепта cryptography), процесс просто
    погибает, а WebView остаётся на "Loading..." или на пустом экране
    навсегда, без единого сообщения об ошибке, которое можно увидеть без
    USB-кабеля и adb logcat.

    Чтобы это исправить, НЕ трогая Java-код бутстрапа, ниже сразу — до
    каких-либо тяжёлых импортов/инициализации — поднимается временный
    HTTP-сервер-заглушка на том же порту 127.0.0.1:5000: он немедленно
    отвечает WebView страницей "Запуск узла…" с JS-опросом
    /__boot_status раз в 0.4–0.6 c. Как только настоящее Flask-приложение
    готово, заглушка останавливается и тот же порт занимает app.run() —
    страница сама перезагружается на "/". Если же инициализация упала —
    заглушка вместо вечной загрузки показывает сам traceback прямо в
    WebView, чтобы баг было видно и понятно, что чинить дальше.
    """
    logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(levelname)s] %(name)s: %(message)s")

    host, port = "127.0.0.1", 5000
    ready = threading.Event()
    error_holder: list[str] = []

    class _BootHandler(BaseHTTPRequestHandler):
        protocol_version = "HTTP/1.0"  # без keep-alive — сокет освобождается сразу после ответа

        def _reply(self, body: str, ctype: str = "text/html; charset=utf-8") -> None:
            data = body.encode("utf-8")
            self.send_response(200)
            self.send_header("Content-Type", ctype)
            self.send_header("Content-Length", str(len(data)))
            self.send_header("Connection", "close")
            self.end_headers()
            try:
                self.wfile.write(data)
            except OSError:
                pass

        def do_GET(self) -> None:  # noqa: N802 - имя метода задано BaseHTTPRequestHandler
            if self.path.startswith("/__boot_status"):
                if error_holder:
                    status = "error"
                elif ready.is_set():
                    status = "ready"
                else:
                    status = "loading"
                self._reply('{"status": "%s"}' % status, ctype="application/json")
                return
            self._reply(_boot_error_page(error_holder[0]) if error_holder else _BOOT_PAGE)

        def log_message(self, fmt: str, *args: Any) -> None:  # приглушаем стандартный вывод в stderr
            logger.debug("boot-заглушка: " + fmt, *args)

    boot_server = HTTPServer((host, port), _BootHandler)
    threading.Thread(target=boot_server.serve_forever, daemon=True).start()

    app: Optional[Flask] = None
    try:
        app = create_app()
    except Exception:  # noqa: BLE001 - любая ошибка инициализации должна быть видна в WebView
        error_holder.append(traceback.format_exc())
        logger.exception("Ошибка инициализации приложения на Android")

    if app is None:
        # Заглушка уже показывает traceback вместо вечного "Loading..." —
        # держим процесс живым, чтобы WebView могло достучаться до неё.
        while True:
            time.sleep(3600)

    ready.set()
    boot_server.shutdown()
    boot_server.server_close()

    # Между освобождением порта заглушкой и стартом настоящего Flask-сервера
    # возможен короткий зазор (ОС не всегда мгновенно освобождает сокет) —
    # пробуем несколько раз вместо падения с первого "Address already in use".
    last_exc: Optional[BaseException] = None
    for _ in range(20):
        try:
            app.run(host=host, port=port, debug=False, use_reloader=False, threaded=True)
            return 0
        except OSError as exc:
            last_exc = exc
            time.sleep(0.2)

    logger.error("Не удалось запустить локальный веб-сервер на %s:%s", host, port, exc_info=last_exc)
    # Даже тут не оставляем WebView без ответа — поднимаем ту же заглушку
    # ещё раз, сразу с текстом ошибки.
    error_holder.append(
        "".join(traceback.format_exception(type(last_exc), last_exc, last_exc.__traceback__))
        if last_exc
        else "Не удалось запустить веб-сервер: неизвестная ошибка."
    )
    HTTPServer((host, port), _BootHandler).serve_forever()
    return 1
