#!/usr/bin/env python3
"""
Точка входа в приложение.

Примеры запуска:

    python main.py --web                     # красивый веб-интерфейс (рекомендуется)
    python main.py --name Alice               # консольный интерфейс
    python main.py --name Bob --port 5200 --gui  # tkinter GUI

При первом запуске введите ник и пароль — это и есть регистрация:
пароль защищает ваш приватный ключ на диске, второй раз вводить его
не нужно только на этом же устройстве и с этим же паролем.

Два узла в одной локальной сети автоматически найдут друг друга через
UDP-обнаружение (см. p2p_messenger/discovery.py). Также можно подключиться
вручную по IP:порту — командой /connect в CLI, кнопкой в GUI/веб-интерфейсе.
"""

import os
import sys

# На Android (сборка через buildozer/python-for-android, bootstrap=webview)
# у процесса всегда есть переменные окружения ANDROID_ARGUMENT/ANDROID_PRIVATE,
# которые ставит сам p4a. В этом случае сразу поднимаем веб-интерфейс на
# 127.0.0.1 — встроенный в APK WebView откроет его автоматически, никакого
# меню/аргументов командной строки на телефоне нет.
if "ANDROID_ARGUMENT" in os.environ:
    os.environ.setdefault("P2P_WEB_HOST", "127.0.0.1")
    os.environ.setdefault("P2P_WEB_PORT", "8765")  # должен совпадать с p4a.port в buildozer.spec
    from p2p_messenger.webapp import run_web_app

    sys.exit(run_web_app())

_MISSING_DEP_HELP = """
Не найден пакет '{module}'.

В Pydroid 3 поставьте зависимости через встроенный менеджер пакетов
(значок "Pip" в боковом меню, не через обычный терминал Android):

    cryptography
    flask

Либо выполните в консоли Pydroid 3 (вкладка "Terminal" внутри самого
приложения Pydroid 3, значок консоли, а НЕ системный терминал Android):

    pip install cryptography flask

После установки запустите main.py ещё раз (кнопка ▶ Run).
""".strip()

try:
    from p2p_messenger.cli import main
except ImportError as exc:
    missing = (exc.name or str(exc)).split(".")[0]
    print(_MISSING_DEP_HELP.format(module=missing))
    sys.exit(1)

if __name__ == "__main__":
    sys.exit(main())
