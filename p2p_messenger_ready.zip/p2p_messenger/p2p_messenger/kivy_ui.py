"""
Нативный интерфейс приложения на Kivy — визуально повторяет веб-версию
(см. templates/index.html + static/css/style.css), но рисуется настоящими
Android-виджетами, без HTML/WebView.

Использует то же ядро, что и CLI/GUI/веб-версия: Peer, AccountStore,
DiscoveredPeer — никакая сетевая или криптологика здесь не дублируется,
только UI-обвязка.

Экраны (как в веб-версии):
  - auth    — вход / регистрация (табы)
  - chat    — список узлов (по кнопке ☰) + переписка + отправка файла
  - profile — ник, био
  - settings— ник, порт, выход

Коллбэки Peer (on_chat_message/on_event/on_discovery_update) вызываются
из фоновых сетевых потоков — в Kivy трогать виджеты можно только из
главного потока, поэтому каждый коллбэк только планирует обновление UI
через Clock.schedule_once (это единственный thread-safe способ достучаться
до главного цикла Kivy из другого потока).
"""

from __future__ import annotations

import os
import time
from typing import Optional

from kivy.app import App
from kivy.clock import Clock, mainthread
from kivy.core.window import Window
from kivy.lang import Builder
from kivy.properties import BooleanProperty, ListProperty, StringProperty
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.button import Button
from kivy.uix.label import Label
from kivy.uix.popup import Popup
from kivy.uix.screenmanager import Screen, ScreenManager, NoTransition
from kivy.uix.scrollview import ScrollView
from kivy.utils import get_color_from_hex as hex_

from .auth import AccountStore, AuthError
from .config import CONFIG
from .crypto_utils import CryptoError
from .discovery import DiscoveredPeer
from .peer import Peer

# --------------------------------------------------------------------------- #
# Палитра — 1-в-1 из static/css/style.css (:root)
# --------------------------------------------------------------------------- #

BG_DEEP = hex_("#0A0F17")
BG_PANEL = hex_("#10182A")
BG_PANEL_2 = hex_("#161F35")
BG_ELEVATED = hex_("#1C2740")
BORDER = hex_("#22304A")
TEXT_PRIMARY = hex_("#EAF0F8")
TEXT_MUTED = hex_("#8595B4")
TEXT_DIM = hex_("#56637C")
ACCENT_LINK = hex_("#45E6D2")
ACCENT_PENDING = hex_("#F3B94D")
ACCENT_DANGER = hex_("#FF6B72")
ACCENT_VIOLET = hex_("#8D7CFF")

KV = """
#:import hex kivy.utils.get_color_from_hex

<RowSep@Widget>:
    size_hint_y: None
    height: dp(1)
    canvas:
        Color:
            rgba: hex("#22304A")
        Rectangle:
            pos: self.pos
            size: self.size

<WireLabel@Label>:
    color: hex("#EAF0F8")
    markup: True

<HintLabel@Label>:
    color: hex("#56637C")
    font_size: '12sp'
    markup: True

<FieldInput@TextInput>:
    background_color: hex("#0A0F17")
    foreground_color: hex("#EAF0F8")
    cursor_color: hex("#45E6D2")
    hint_text_color: hex("#56637C")
    padding: [12, 12, 12, 12]
    multiline: False
    size_hint_y: None
    height: dp(44)

<PrimaryButton@Button>:
    background_normal: ''
    background_color: hex("#45E6D2")
    color: hex("#06231F")
    bold: True
    size_hint_y: None
    height: dp(46)

<GhostButton@Button>:
    background_normal: ''
    background_color: hex("#1C2740")
    color: hex("#8595B4")
    size_hint_y: None
    height: dp(42)

<ErrorLabel@Label>:
    color: hex("#FF6B72")
    font_size: '12sp'
    size_hint_y: None
    height: self.texture_size[1] + dp(4)
    text_size: self.width, None

<PeerRow>:
    orientation: 'horizontal'
    size_hint_y: None
    height: dp(52)
    padding: [10, 6]
    spacing: 10
    canvas.before:
        Color:
            rgba: (hex("#1C2740") if root.active else (0, 0, 0, 0))
        Rectangle:
            pos: self.pos
            size: self.size
    Widget:
        size_hint_x: None
        width: dp(10)
        canvas:
            Color:
                rgba: hex("#45E6D2") if root.secure else hex("#56637C")
            Ellipse:
                pos: self.center_x - dp(4), self.center_y - dp(4)
                size: dp(8), dp(8)
    BoxLayout:
        orientation: 'vertical'
        Label:
            text: root.title
            color: hex("#EAF0F8")
            bold: True
            font_size: '14sp'
            halign: 'left'
            text_size: self.width, None
            size_hint_y: None
            height: dp(20)
        Label:
            text: root.subtitle
            color: hex("#56637C")
            font_size: '11sp'
            halign: 'left'
            text_size: self.width, None
            size_hint_y: None
            height: dp(16)

<Bubble>:
    orientation: 'vertical'
    size_hint: (0.72, None)
    pos_hint: {'right': 1} if root.outgoing else {'x': 0}
    padding: [12, 8]
    height: self.minimum_height
    canvas.before:
        Color:
            rgba: hex("#10241F") if root.outgoing else hex("#161F35")
        RoundedRectangle:
            pos: self.pos
            size: self.size
            radius: [dp(12)]
    Label:
        text: root.text
        color: hex("#EAF0F8")
        font_size: '14sp'
        halign: 'left'
        valign: 'top'
        text_size: self.width - dp(4), None
        size_hint_y: None
        height: self.texture_size[1]
    Label:
        text: root.time_str
        color: hex("#56637C")
        font_size: '10sp'
        halign: 'right'
        text_size: self.width, None
        size_hint_y: None
        height: dp(14)

<AuthScreen>:
    canvas.before:
        Color:
            rgba: hex("#0A0F17")
        Rectangle:
            pos: self.pos
            size: self.size
    BoxLayout:
        orientation: 'vertical'
        size_hint: (None, None)
        width: min(dp(380), root.width - dp(32))
        height: self.minimum_height
        pos_hint: {'center_x': 0.5, 'center_y': 0.5}
        padding: [28, 30]
        spacing: 4
        canvas.before:
            Color:
                rgba: hex("#10182A")
            RoundedRectangle:
                pos: self.pos
                size: self.size
                radius: [dp(20)]

        Label:
            text: '[b]\\u25c7 WIRE[/b]'
            markup: True
            color: hex("#45E6D2")
            font_size: '22sp'
            size_hint_y: None
            height: dp(32)
        HintLabel:
            text: 'Прямая зашифрованная линия между двумя узлами.\\nБез сервера. Без посредников.'
            halign: 'center'
            text_size: self.width, None
            size_hint_y: None
            height: dp(40)

        Widget:
            size_hint_y: None
            height: dp(16)

        BoxLayout:
            size_hint_y: None
            height: dp(38)
            spacing: 2
            canvas.before:
                Color:
                    rgba: hex("#0A0F17")
                RoundedRectangle:
                    pos: self.pos
                    size: self.size
                    radius: [dp(8)]
            ToggleButton:
                text: 'Вход'
                group: 'authtab'
                state: 'down' if root.mode == 'login' else 'normal'
                background_normal: ''
                background_color: hex("#1C2740") if self.state == 'down' else (0,0,0,0)
                color: hex("#EAF0F8") if self.state == 'down' else hex("#56637C")
                on_press: root.mode = 'login'
            ToggleButton:
                text: 'Регистрация'
                group: 'authtab'
                state: 'down' if root.mode == 'register' else 'normal'
                background_normal: ''
                background_color: hex("#1C2740") if self.state == 'down' else (0,0,0,0)
                color: hex("#EAF0F8") if self.state == 'down' else hex("#56637C")
                on_press: root.mode = 'register'

        Widget:
            size_hint_y: None
            height: dp(14)

        BoxLayout:
            orientation: 'vertical'
            spacing: 6
            size_hint_y: None
            height: self.minimum_height
            opacity: 1 if root.mode == 'login' else 0
            disabled: root.mode != 'login'
            HintLabel:
                text: 'НИК'
                size_hint_y: None
                height: dp(16)
            FieldInput:
                id: login_nick
                hint_text: 'ваш_ник'
            HintLabel:
                text: 'ПАРОЛЬ'
                size_hint_y: None
                height: dp(16)
            FieldInput:
                id: login_pass
                hint_text: '••••••••'
                password: True
            PrimaryButton:
                text: 'Войти в узел'
                on_release: root.do_login()
            ErrorLabel:
                id: login_error

        BoxLayout:
            orientation: 'vertical'
            spacing: 6
            size_hint_y: None
            height: self.minimum_height if root.mode == 'register' else 0
            opacity: 1 if root.mode == 'register' else 0
            disabled: root.mode != 'register'
            HintLabel:
                text: 'НИК'
                size_hint_y: None
                height: dp(16)
            FieldInput:
                id: reg_nick
                hint_text: '3–24 символа'
            HintLabel:
                text: 'ПАРОЛЬ'
                size_hint_y: None
                height: dp(16)
            FieldInput:
                id: reg_pass
                hint_text: 'минимум 6 символов'
                password: True
            HintLabel:
                text: 'ПОРТ ДЛЯ ВХОДЯЩИХ СОЕДИНЕНИЙ'
                size_hint_y: None
                height: dp(16)
            FieldInput:
                id: reg_port
                hint_text: '5100'
                input_filter: 'int'
            PrimaryButton:
                text: 'Создать узел'
                on_release: root.do_register()
            ErrorLabel:
                id: reg_error

<ChatScreen>:
    canvas.before:
        Color:
            rgba: hex("#0A0F17")
        Rectangle:
            pos: self.pos
            size: self.size
    BoxLayout:
        orientation: 'vertical'
        BoxLayout:
            size_hint_y: None
            height: dp(52)
            padding: [12, 8]
            spacing: 10
            canvas.before:
                Color:
                    rgba: hex("#10182A")
                Rectangle:
                    pos: self.pos
                    size: self.size
            Button:
                text: '\\u2630'
                size_hint_x: None
                width: dp(40)
                background_normal: ''
                background_color: (0, 0, 0, 0)
                color: hex("#EAF0F8")
                on_release: root.open_peer_list()
            Label:
                id: chat_title
                text: root.peer_title
                bold: True
                color: hex("#EAF0F8")
                halign: 'left'
                text_size: self.width, None
            Label:
                text: root.peer_status
                color: hex("#45E6D2") if root.secure else hex("#56637C")
                font_size: '11sp'
                size_hint_x: None
                width: dp(90)
        RowSep:
        ScrollView:
            id: scroll
            BoxLayout:
                id: messages_box
                orientation: 'vertical'
                size_hint_y: None
                height: self.minimum_height
                padding: [14, 14]
                spacing: 6
        RowSep:
        BoxLayout:
            size_hint_y: None
            height: dp(58)
            padding: [10, 8]
            spacing: 8
            canvas.before:
                Color:
                    rgba: hex("#10182A")
                Rectangle:
                    pos: self.pos
                    size: self.size
            GhostButton:
                text: '\\U0001F4CE'
                size_hint_x: None
                width: dp(42)
                on_release: root.pick_file()
            FieldInput:
                id: msg_input
                hint_text: 'Введите сообщение…'
                disabled: not root.current_peer
                on_text_validate: root.send_message()
            PrimaryButton:
                text: 'Отправить'
                size_hint_x: None
                width: dp(100)
                disabled: not root.current_peer
                on_release: root.send_message()

<ProfileScreen>:
    canvas.before:
        Color:
            rgba: hex("#0A0F17")
        Rectangle:
            pos: self.pos
            size: self.size
    BoxLayout:
        orientation: 'vertical'
        padding: [20, 20]
        spacing: 12
        Label:
            text: '[b]Профиль[/b]'
            markup: True
            color: hex("#EAF0F8")
            font_size: '18sp'
            size_hint_y: None
            height: dp(30)
        Widget:
            size_hint_y: None
            height: dp(70)
            canvas:
                Color:
                    rgba: hex("#8D7CFF")
                Ellipse:
                    pos: self.center_x - dp(35), self.center_y - dp(35)
                    size: dp(70), dp(70)
            Label:
                text: root.initials
                bold: True
                color: hex("#06111C")
                center: self.parent.center
        HintLabel:
            text: 'НИК'
            size_hint_y: None
            height: dp(16)
        WireLabel:
            text: root.nickname
            size_hint_y: None
            height: dp(24)
        HintLabel:
            text: 'О СЕБЕ'
            size_hint_y: None
            height: dp(16)
        FieldInput:
            id: bio_input
            multiline: True
            size_hint_y: None
            height: dp(90)
        PrimaryButton:
            text: 'Сохранить'
            on_release: root.save_profile()
        ErrorLabel:
            id: profile_error

<SettingsScreen>:
    canvas.before:
        Color:
            rgba: hex("#0A0F17")
        Rectangle:
            pos: self.pos
            size: self.size
    BoxLayout:
        orientation: 'vertical'
        padding: [20, 20]
        spacing: 14
        Label:
            text: '[b]Настройки[/b]'
            markup: True
            color: hex("#EAF0F8")
            font_size: '18sp'
            size_hint_y: None
            height: dp(30)
        BoxLayout:
            size_hint_y: None
            height: dp(30)
            Label:
                text: 'Ник'
                color: hex("#8595B4")
            Label:
                text: root.nickname
                color: hex("#EAF0F8")
        BoxLayout:
            size_hint_y: None
            height: dp(30)
            Label:
                text: 'Порт входящих соединений'
                color: hex("#8595B4")
            Label:
                text: root.port_text
                color: hex("#EAF0F8")
        BoxLayout:
            size_hint_y: None
            height: dp(30)
            Label:
                text: 'Обнаружение в сети'
                color: hex("#8595B4")
            Label:
                text: 'включено'
                color: hex("#EAF0F8")
        Widget:
        GhostButton:
            text: 'Выйти из аккаунта'
            color: hex("#FF6B72")
            on_release: root.do_logout()

<RootShell>:
    orientation: 'vertical'
    ScreenManager:
        id: inner_sm
        transition: NoTransition()
        ChatScreen:
            id: chat_screen
            name: 'chat'
        SettingsScreen:
            id: settings_screen
            name: 'settings'
        ProfileScreen:
            id: profile_screen
            name: 'profile'
    BoxLayout:
        size_hint_y: None
        height: dp(56)
        canvas.before:
            Color:
                rgba: hex("#10182A")
            Rectangle:
                pos: self.pos
                size: self.size
        ToggleButton:
            text: 'Чат'
            group: 'nav'
            state: 'down' if inner_sm.current == 'chat' else 'normal'
            background_normal: ''
            background_color: (0, 0, 0, 0)
            color: hex("#45E6D2") if self.state == 'down' else hex("#56637C")
            on_press: inner_sm.current = 'chat'
        ToggleButton:
            text: 'Настройки'
            group: 'nav'
            state: 'down' if inner_sm.current == 'settings' else 'normal'
            background_normal: ''
            background_color: (0, 0, 0, 0)
            color: hex("#45E6D2") if self.state == 'down' else hex("#56637C")
            on_press: inner_sm.current = 'settings'
        ToggleButton:
            text: 'Профиль'
            group: 'nav'
            state: 'down' if inner_sm.current == 'profile' else 'normal'
            background_normal: ''
            background_color: (0, 0, 0, 0)
            color: hex("#45E6D2") if self.state == 'down' else hex("#56637C")
            on_press: inner_sm.current = 'profile'

<MainScreen>:
    RootShell:
        id: shell
"""


class PeerRow(BoxLayout):
    title = StringProperty("")
    subtitle = StringProperty("")
    active = BooleanProperty(False)
    secure = BooleanProperty(False)


class Bubble(BoxLayout):
    text = StringProperty("")
    time_str = StringProperty("")
    outgoing = BooleanProperty(False)


class AuthScreen(Screen):
    mode = StringProperty("login")

    def do_login(self) -> None:
        app = App.get_running_app()
        nickname = self.ids.login_nick.text.strip()
        password = self.ids.login_pass.text
        self.ids.login_error.text = ""
        try:
            app.login(nickname, password)
        except (AuthError, CryptoError, OSError) as exc:
            self.ids.login_error.text = str(exc)

    def do_register(self) -> None:
        app = App.get_running_app()
        nickname = self.ids.reg_nick.text.strip()
        password = self.ids.reg_pass.text
        port_text = self.ids.reg_port.text.strip() or str(CONFIG.tcp_port)
        self.ids.reg_error.text = ""
        try:
            app.register(nickname, password, int(port_text))
        except (AuthError, CryptoError, OSError, ValueError) as exc:
            self.ids.reg_error.text = str(exc)


class ChatScreen(Screen):
    peer_title = StringProperty("Выберите собеседника")
    peer_status = StringProperty("")
    secure = BooleanProperty(False)
    current_peer = StringProperty("")
    _popup: Optional[Popup] = None

    def _gather_entries(self) -> dict:
        """Объединяет обнаруженных в сети, активные подключения и известных
        по истории (ContactsStore) в один словарь {ник: {...}} для поиска."""
        app = App.get_running_app()
        entries: dict = {}
        if not app.peer:
            return entries

        sessions = app.peer.get_active_sessions()
        for name in sessions:
            entries[name] = {"subtitle": "активна", "secure": True, "address": None, "port": None}

        for p in app.peer.get_discovered_peers():
            if p.name not in entries:
                entries[p.name] = {
                    "subtitle": f"{p.address}:{p.tcp_port} · в сети",
                    "secure": False, "address": p.address, "port": p.tcp_port,
                }

        for name, info in app.peer.contacts.all().items():
            if name not in entries:
                addr = info.get("address", "?")
                port = info.get("tcp_port", "?")
                entries[name] = {
                    "subtitle": f"{addr}:{port} · известен",
                    "secure": False, "address": info.get("address"), "port": info.get("tcp_port"),
                }
        return entries

    def open_peer_list(self) -> None:
        app = App.get_running_app()
        content = BoxLayout(orientation="vertical", spacing=8, padding=10)

        content.add_widget(Label(text="Поиск по нику", color=TEXT_DIM, font_size="11sp",
                                  size_hint_y=None, height=16, halign="left"))
        search_input = Builder.load_string(
            "FieldInput:\n    hint_text: 'начните вводить ник…'\n"
        )
        content.add_widget(search_input)

        list_container = BoxLayout(orientation="vertical", spacing=6, size_hint_y=None)
        list_container.bind(minimum_height=list_container.setter("height"))
        scroll = ScrollView()
        scroll.add_widget(list_container)
        content.add_widget(scroll)

        connect_btn = Button(text="+ подключиться вручную по IP", size_hint_y=None, height=42,
                              background_normal="", background_color=BG_ELEVATED, color=ACCENT_LINK)
        connect_btn.bind(on_release=lambda *_: (self._popup.dismiss(), app.open_connect_popup()))
        content.add_widget(connect_btn)

        def refresh(*_args) -> None:
            list_container.clear_widgets()
            query = search_input.text.strip().lower()
            entries = self._gather_entries()
            names = sorted(entries.keys(), key=str.lower)
            if query:
                names = [n for n in names if query in n.lower()]
            if not names:
                msg = "Ничего не найдено" if query else "Пока никого нет рядом"
                list_container.add_widget(Label(text=msg, color=TEXT_DIM,
                                                 size_hint_y=None, height=30))
            for name in names:
                info = entries[name]
                row = PeerRow(title=name, subtitle=info["subtitle"], secure=info["secure"],
                              active=(name == self.current_peer))
                row.bind(on_touch_down=self._make_row_handler(name, info["address"], info["port"]))
                list_container.add_widget(row)

        search_input.bind(text=refresh)
        refresh()

        self._popup = Popup(title="Узлы", content=content, size_hint=(0.9, 0.85))
        self._popup.open()

    def _make_row_handler(self, name, address, port):
        def _on_touch(instance, touch):
            if instance.collide_point(*touch.pos):
                app = App.get_running_app()
                if address is not None and name not in (app.peer.get_active_sessions() if app.peer else []):
                    app.connect_to_peer(address, port, name)
                else:
                    self.open_chat_with(name)
                if self._popup:
                    self._popup.dismiss()
            return False
        return _on_touch

    def open_chat_with(self, name: str) -> None:
        app = App.get_running_app()
        self.current_peer = name
        self.peer_title = name
        sessions = app.peer.get_active_sessions() if app.peer else []
        self.secure = name in sessions
        self.peer_status = "зашифровано" if self.secure else "…"
        self.render_history(name)

    def render_history(self, name: str) -> None:
        app = App.get_running_app()
        box = self.ids.messages_box
        box.clear_widgets()
        if not app.peer:
            return
        for rec in app.peer.history.read_all(name):
            self._add_bubble(rec["text"], rec["direction"] == "out", rec.get("timestamp"))
        Clock.schedule_once(lambda *_: setattr(self.ids.scroll, "scroll_y", 0), 0)

    def _add_bubble(self, text: str, outgoing: bool, ts: Optional[float]) -> None:
        t = time.strftime("%H:%M", time.localtime(ts)) if ts else ""
        self.ids.messages_box.add_widget(Bubble(text=text, time_str=t, outgoing=outgoing))

    def on_incoming_message(self, sender: str, text: str) -> None:
        if sender == self.current_peer:
            self._add_bubble(text, False, time.time())
            Clock.schedule_once(lambda *_: setattr(self.ids.scroll, "scroll_y", 0), 0)

    def send_message(self) -> None:
        app = App.get_running_app()
        text = self.ids.msg_input.text.strip()
        if not text or not self.current_peer or not app.peer:
            return
        try:
            app.peer.send_chat(self.current_peer, text)
        except ConnectionError as exc:
            app.toast(str(exc))
            return
        self._add_bubble(text, True, time.time())
        self.ids.msg_input.text = ""
        Clock.schedule_once(lambda *_: setattr(self.ids.scroll, "scroll_y", 0), 0)

    def pick_file(self) -> None:
        app = App.get_running_app()
        if not self.current_peer:
            app.toast("Сначала выберите собеседника")
            return
        try:
            from plyer import filechooser
            filechooser.open_file(on_selection=self._on_file_chosen)
        except Exception:  # noqa: BLE001 - на некоторых сборках filechooser недоступен
            app.toast("Выбор файла недоступен на этом устройстве")

    def _on_file_chosen(self, selection) -> None:
        if not selection:
            return
        path = selection[0]
        app = App.get_running_app()

        def _send():
            try:
                app.peer.send_file(self.current_peer, path)
            except (ConnectionError, FileNotFoundError) as exc:
                app.toast(str(exc))
                return
            Clock.schedule_once(lambda *_: self._add_bubble(f"📎 {os.path.basename(path)}", True, time.time()), 0)

        import threading
        threading.Thread(target=_send, daemon=True).start()


class ProfileScreen(Screen):
    nickname = StringProperty("")
    initials = StringProperty("")

    def on_pre_enter(self, *args):
        app = App.get_running_app()
        if app.account:
            self.nickname = app.account.nickname
            self.initials = app.account.nickname[:2].upper()
            self.ids.bio_input.text = app.account.bio or ""

    def save_profile(self) -> None:
        app = App.get_running_app()
        self.ids.profile_error.text = ""
        try:
            app.save_bio(self.ids.bio_input.text.strip())
        except AuthError as exc:
            self.ids.profile_error.text = str(exc)


class SettingsScreen(Screen):
    nickname = StringProperty("")
    port_text = StringProperty("")

    def on_pre_enter(self, *args):
        app = App.get_running_app()
        if app.peer:
            self.nickname = app.peer.name
            self.port_text = str(app.peer.tcp_port)

    def do_logout(self) -> None:
        App.get_running_app().logout()


class RootShell(BoxLayout):
    pass


class MainScreen(Screen):
    pass


class WireApp(App):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.accounts = AccountStore()
        self.peer: Optional[Peer] = None
        self.account = None

    def build(self):
        Window.clearcolor = BG_DEEP
        Builder.load_string(KV)
        self.sm = ScreenManager(transition=NoTransition())
        self.auth_screen = AuthScreen(name="auth")
        self.main_screen = MainScreen(name="main")
        self.sm.add_widget(self.auth_screen)
        self.sm.add_widget(self.main_screen)
        return self.sm

    # ------------------------------------------------------------------ #
    # Аутентификация
    # ------------------------------------------------------------------ #

    def register(self, nickname: str, password: str, port: int) -> None:
        account = self.accounts.register(nickname, password, port)
        self._start_peer(account, password)

    def login(self, nickname: str, password: str) -> None:
        account = self.accounts.verify(nickname, password)
        self._start_peer(account, password)

    def _start_peer(self, account, password: str) -> None:
        peer = Peer(name=account.nickname, tcp_port=account.tcp_port, key_password=password)
        peer.on_chat_message = self._on_chat_message
        peer.on_event = self._on_event
        peer.on_discovery_update = self._on_discovery_update
        peer.start()
        self.peer = peer
        self.account = account
        self.sm.current = "main"
        Clock.schedule_interval(self._refresh_sidebar_tick, 4.0)

    def logout(self) -> None:
        if self.peer:
            self.peer.stop()
        self.peer = None
        self.account = None
        self.sm.current = "auth"

    def save_bio(self, bio: str) -> None:
        if not self.account:
            return
        self.account = self.accounts.update_profile(self.account.nickname, bio=bio)

    # ------------------------------------------------------------------ #
    # Коллбэки Peer (вызываются из фоновых потоков!)
    # ------------------------------------------------------------------ #

    def _on_chat_message(self, sender: str, text: str) -> None:
        Clock.schedule_once(lambda *_: self._chat_screen().on_incoming_message(sender, text), 0)

    def _on_event(self, kind: str, message: str) -> None:
        Clock.schedule_once(lambda *_: self.toast(message), 0)

    def _on_discovery_update(self, discovered: DiscoveredPeer) -> None:
        pass  # список обновляется по требованию при открытии попапа с узлами

    def _refresh_sidebar_tick(self, *_args) -> bool:
        return self.peer is not None

    def _chat_screen(self) -> ChatScreen:
        return self.main_screen.ids.shell.ids.chat_screen

    # ------------------------------------------------------------------ #
    # Подключение к узлу
    # ------------------------------------------------------------------ #

    def connect_to_peer(self, address: str, port: int, expected_name: Optional[str] = None) -> None:
        def _do():
            try:
                name = self.peer.connect_to(address, port)
            except (OSError, TimeoutError) as exc:
                Clock.schedule_once(lambda *_: self.toast(f"Не удалось подключиться: {exc}"), 0)
                return
            Clock.schedule_once(lambda *_: self._chat_screen().open_chat_with(name), 0)

        import threading
        threading.Thread(target=_do, daemon=True).start()

    def open_connect_popup(self) -> None:
        box = BoxLayout(orientation="vertical", spacing=8, padding=14)
        addr_in = Builder.load_string(
            "FieldInput:\n    hint_text: 'IP-адрес, например 192.168.1.10'\n"
        )
        port_in = Builder.load_string(
            "FieldInput:\n    hint_text: 'Порт, например 5100'\n    input_filter: 'int'\n"
        )
        box.add_widget(Label(text="IP-адрес", color=TEXT_DIM, size_hint_y=None, height=20))
        box.add_widget(addr_in)
        box.add_widget(Label(text="Порт", color=TEXT_DIM, size_hint_y=None, height=20))
        box.add_widget(port_in)
        err = Label(text="", color=ACCENT_DANGER, size_hint_y=None, height=20)
        box.add_widget(err)
        popup = Popup(title="Подключение к узлу", content=box, size_hint=(0.85, 0.5))

        def _submit(*_):
            try:
                port = int(port_in.text.strip())
            except ValueError:
                err.text = "Некорректный порт."
                return
            self.connect_to_peer(addr_in.text.strip(), port)
            popup.dismiss()

        submit_btn = Button(text="Подключиться", size_hint_y=None, height=44,
                             background_normal="", background_color=ACCENT_LINK, color=hex_("#06231F"))
        submit_btn.bind(on_release=_submit)
        box.add_widget(submit_btn)
        popup.open()

    # ------------------------------------------------------------------ #
    # Мелочи UI
    # ------------------------------------------------------------------ #

    @mainthread
    def toast(self, message: str) -> None:
        popup = Popup(
            title="",
            content=Label(text=message, color=TEXT_PRIMARY),
            size_hint=(0.8, None),
            height=100,
            separator_height=0,
        )
        popup.open()
        Clock.schedule_once(lambda *_: popup.dismiss(), 2.0)


def run_kivy_app() -> int:
    WireApp().run()
    return 0
