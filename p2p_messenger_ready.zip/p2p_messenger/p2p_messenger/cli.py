"""
Консольный интерфейс мессенджера. Полностью рабочий, без внешних зависимостей
кроме `cryptography`. Поддерживаемые команды описаны в HELP_TEXT.
"""

from __future__ import annotations

import argparse
import getpass
import logging
import shlex
import sys

from .auth import AccountStore, AuthError
from .config import CONFIG
from .peer import Peer

HELP_TEXT = """
Доступные команды:
  /connect <адрес> <порт>     - подключиться к пиру напрямую
  /peers                      - показать пиров, найденных автообнаружением в LAN
  /sessions                   - показать активные (подключённые) сессии
  /msg <имя> <текст>          - отправить сообщение подключённому пиру
  /file <имя> <путь_к_файлу>  - отправить файл подключённому пиру
  /history <имя>              - показать историю переписки с пиром
  /help                       - показать эту справку
  /quit                       - выйти из программы

Для отправки сообщения собеседнику, который сейчас выбран как "активный"
(последний, с кем вы говорили), можно просто ввести текст без команды.
"""


def _setup_logging(verbose: bool) -> None:
    logging.basicConfig(
        level=logging.DEBUG if verbose else logging.WARNING,
        format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
    )


class ChatCLI:
    def __init__(self, peer: Peer):
        self.peer = peer
        self.active_peer: str | None = None
        peer.on_chat_message = self._on_chat_message
        peer.on_event = self._on_event
        peer.on_discovery_update = self._on_discovery_update

    def _on_chat_message(self, sender: str, text: str) -> None:
        print(f"\n[{sender}] {text}\n> ", end="", flush=True)
        self.active_peer = sender

    def _on_event(self, kind: str, message: str) -> None:
        print(f"\n*** [{kind}] {message}\n> ", end="", flush=True)

    def _on_discovery_update(self, peer) -> None:  # noqa: ANN001 - DiscoveredPeer
        pass  # можно раскомментировать для подробного вывода при желании

    def run(self) -> None:
        print(f"=== p2p_messenger — вы вошли как '{self.peer.name}', порт {self.peer.tcp_port} ===")
        print("Введите /help для списка команд.")
        while True:
            try:
                line = input("> ").strip()
            except (EOFError, KeyboardInterrupt):
                print()
                break
            if not line:
                continue
            if line.startswith("/"):
                if not self._handle_command(line):
                    break
            else:
                self._send_to_active(line)

    def _handle_command(self, line: str) -> bool:
        """Возвращает False, если нужно завершить работу."""
        try:
            parts = shlex.split(line)
        except ValueError as exc:
            print(f"Ошибка разбора команды: {exc}")
            return True
        cmd = parts[0].lower()

        if cmd in ("/quit", "/exit"):
            return False

        if cmd == "/help":
            print(HELP_TEXT)

        elif cmd == "/connect":
            if len(parts) != 3:
                print("Использование: /connect <адрес> <порт>")
            else:
                self._do_connect(parts[1], int(parts[2]))

        elif cmd == "/peers":
            peers = self.peer.get_discovered_peers()
            if not peers:
                print("Пиры пока не обнаружены в локальной сети.")
            for p in peers:
                print(f"  {p.name}  {p.address}:{p.tcp_port}  (обновлено {int(p.last_seen)}s)")

        elif cmd == "/sessions":
            sessions = self.peer.get_active_sessions()
            print("Активные сессии:", ", ".join(sessions) if sessions else "нет")

        elif cmd == "/msg":
            if len(parts) < 3:
                print("Использование: /msg <имя> <текст>")
            else:
                name, text = parts[1], " ".join(parts[2:])
                self._send_message(name, text)

        elif cmd == "/file":
            if len(parts) != 3:
                print("Использование: /file <имя> <путь_к_файлу>")
            else:
                self._send_file(parts[1], parts[2])

        elif cmd == "/history":
            if len(parts) != 2:
                print("Использование: /history <имя>")
            else:
                for rec in self.peer.history.read_all(parts[1]):
                    arrow = "->" if rec["direction"] == "out" else "<-"
                    print(f"  {arrow} {rec['text']}")

        else:
            print(f"Неизвестная команда: {cmd}. Введите /help.")

        return True

    def _do_connect(self, address: str, port: int) -> None:
        print(f"Подключение к {address}:{port}...")
        try:
            name = self.peer.connect_to(address, port)
        except (OSError, TimeoutError) as exc:
            print(f"Не удалось подключиться: {exc}")
            return
        self.active_peer = name
        print(f"Подключено и защищено шифрованием: {name}")

    def _send_to_active(self, text: str) -> None:
        if not self.active_peer:
            print("Нет активного собеседника. Используйте /connect или /msg <имя> <текст>.")
            return
        self._send_message(self.active_peer, text)

    def _send_message(self, name: str, text: str) -> None:
        try:
            self.peer.send_chat(name, text)
            self.active_peer = name
        except ConnectionError as exc:
            print(f"Ошибка: {exc}")

    def _send_file(self, name: str, path: str) -> None:
        try:
            self.peer.send_file(name, path)
        except (ConnectionError, FileNotFoundError) as exc:
            print(f"Ошибка: {exc}")


def build_arg_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="p2p_messenger — децентрализованный чат")
    # --name не обязателен на уровне argparse: он не нужен для --web (там ник
    # вводится в форме входа/регистрации в браузере), а для консольного режима
    # без --web мы запросим его интерактивно через input(), если не передан.
    # Раньше --name был required=True, из-за чего запуск без аргументов
    # (например, кнопкой "Run" в Pydroid 3, которая не передаёт argv) падал
    # с ошибкой argparse ещё до того, как успевал показаться веб-интерфейс.
    parser.add_argument("--name", default=None, help="Ваш ник (если не указан — будет запрошен)")
    parser.add_argument("--password", help="Пароль аккаунта (если не указан — будет запрошен скрыто)")
    parser.add_argument("--port", type=int, default=CONFIG.tcp_port, help="TCP-порт для входящих соединений")
    parser.add_argument("--verbose", action="store_true", help="Подробное логирование")
    parser.add_argument("--gui", action="store_true", help="Запустить графический интерфейс вместо консольного")
    parser.add_argument("--web", action="store_true", help="Запустить веб-интерфейс в браузере")
    return parser


def _login_or_register(name: str, password: str | None, port: int) -> str:
    """Возвращает подтверждённый пароль: логинит в существующий аккаунт или
    создаёт новый по нику+паролю (см. auth.py)."""
    store = AccountStore()
    if password is None:
        password = getpass.getpass(f"Пароль для '{name}': ")

    if store.exists(name):
        store.verify(name, password)
    else:
        confirm = getpass.getpass("Ника ещё нет. Придумайте пароль ещё раз для подтверждения: ")
        if confirm != password:
            raise AuthError("Пароли не совпадают.")
        store.register(name, password, port)
        print(f"Аккаунт '{name}' зарегистрирован.")
    return password


def main(argv: list[str] | None = None) -> int:
    raw_argv = sys.argv[1:] if argv is None else argv

    # Запуск без единого аргумента — типичная ситуация для кнопки "Run" в
    # Pydroid 3 (там нет удобного способа передать флаги командной строки).
    # Вместо того чтобы молча выбирать что-то одно за пользователя, спросим
    # прямо в консоли, какой интерфейс нужен.
    forced_gui = False
    if not raw_argv:
        print("Аргументы не переданы. Какой интерфейс запустить?")
        print("  1 - Веб-интерфейс в браузере (по умолчанию)")
        print("  2 - Графическое приложение (окно, tkinter)")
        print("  3 - Консольный режим")
        try:
            choice = input("Введите 1, 2 или 3 (Enter = 1): ").strip()
        except (EOFError, KeyboardInterrupt):
            print()
            choice = "1"

        if choice == "2":
            forced_gui = True
        elif choice == "3":
            pass  # обычный консольный режим, ник запросим ниже
        else:
            from .webapp import run_web_app

            return run_web_app()

        args = build_arg_parser().parse_args([])
    else:
        args = build_arg_parser().parse_args(argv)

    _setup_logging(args.verbose)

    if args.web:
        from .webapp import run_web_app

        return run_web_app()

    name = args.name
    if not name:
        try:
            name = input("Ваш ник: ").strip()
        except (EOFError, KeyboardInterrupt):
            print()
            return 1
        if not name:
            print("Ник не может быть пустым.")
            return 1

    try:
        password = _login_or_register(name, args.password, args.port)
    except AuthError as exc:
        print(f"Ошибка входа: {exc}")
        return 1

    peer = Peer(name=name, tcp_port=args.port, key_password=password)
    peer.start()

    try:
        if args.gui or forced_gui:
            try:
                from .gui import run_gui  # локальный импорт: tkinter может отсутствовать в headless-окружении
            except ImportError as exc:
                print(f"Не удалось загрузить графический интерфейс (tkinter): {exc}")
                print("Попробуйте веб-интерфейс: запустите заново и выберите вариант 1.")
                return 1

            try:
                run_gui(peer)
            except Exception as exc:  # noqa: BLE001 - например, нет доступного дисплея
                print(f"Не удалось открыть окно приложения: {exc}")
                print("Попробуйте веб-интерфейс: запустите заново и выберите вариант 1.")
                return 1
        else:
            ChatCLI(peer).run()
    finally:
        peer.stop()
    return 0


if __name__ == "__main__":
    sys.exit(main())
