"""
Криптографический слой.

Схема (классический гибридный шифр, как в TLS):

1. У каждого узла есть долговременная пара RSA-ключей (генерируется один раз
   и кэшируется на диске).
2. При установлении соединения узлы обмениваются публичными RSA-ключами.
3. Инициатор соединения генерирует случайный сессионный AES-256 ключ,
   шифрует его публичным RSA-ключом собеседника (RSA-OAEP) и отправляет.
4. Дальше вся переписка внутри сессии шифруется симметрично AES-256-GCM
   (быстро + аутентификация целостности "из коробки" через тег GCM).

Пароль аккаунта — не просто "замок на входе": он используется как ключ,
которым на диске зашифрован приватный RSA-ключ пользователя (AES-256-GCM,
ключ шифрования выводится из пароля через PBKDF2-HMAC-SHA256 с солью).
Это значит, что без правильного пароля приватный ключ невозможно
использовать, даже если получить доступ к файлам на диске.

Используется библиотека `cryptography` (реализация OpenSSL), а не
самописные примитивы — это осознанный выбор: писать свою криптографию
небезопасно и не нужно.
"""

from __future__ import annotations

import hashlib
import os
from pathlib import Path
from typing import Tuple

from cryptography.hazmat.primitives import hashes, serialization
from cryptography.hazmat.primitives.asymmetric import padding, rsa
from cryptography.hazmat.primitives.ciphers.aead import AESGCM

from .config import CONFIG

NONCE_SIZE = 12  # рекомендованный размер nonce для AES-GCM
PBKDF2_ITERATIONS = 200_000


class CryptoError(Exception):
    """Ошибка на криптографическом уровне (не удалось расшифровать и т.п.)."""


# --------------------------------------------------------------------------- #
# Вывод ключа из пароля (используется и для account-auth, и для шифрования
# приватного ключа на диске)
# --------------------------------------------------------------------------- #

def derive_key_from_password(password: str, salt: bytes, length: int = 32) -> bytes:
    """PBKDF2-HMAC-SHA256: превращает пароль + соль в криптографический ключ."""
    return hashlib.pbkdf2_hmac("sha256", password.encode("utf-8"), salt, PBKDF2_ITERATIONS, dklen=length)


# --------------------------------------------------------------------------- #
# RSA: долговременная идентичность узла, приватный ключ хранится на диске
# зашифрованным паролем аккаунта
# --------------------------------------------------------------------------- #

def load_or_create_rsa_keypair(
    identity_name: str,
    password: str,
) -> Tuple[rsa.RSAPrivateKey, rsa.RSAPublicKey]:
    """
    Загрузить пару RSA-ключей узла с диска (расшифровав приватный ключ
    паролем), либо сгенерировать новую пару и сохранить приватный ключ
    зашифрованным этим же паролем. Так связка ник+пароль становится
    настоящей криптографической личностью, а не просто формой входа.
    """
    CONFIG.ensure_dirs()
    priv_path = CONFIG.keys_dir / f"{identity_name}_private.enc"
    pub_path = CONFIG.keys_dir / f"{identity_name}_public.pem"
    salt_path = CONFIG.keys_dir / f"{identity_name}.salt"

    if priv_path.exists() and pub_path.exists() and salt_path.exists():
        salt = salt_path.read_bytes()
        key = derive_key_from_password(password, salt)
        blob = priv_path.read_bytes()
        nonce, ct = blob[:NONCE_SIZE], blob[NONCE_SIZE:]
        try:
            pem_bytes = AESGCM(key).decrypt(nonce, ct, None)
        except Exception as exc:  # noqa: BLE001
            raise CryptoError("Неверный пароль: не удалось расшифровать приватный ключ") from exc
        private_key = serialization.load_pem_private_key(pem_bytes, password=None)
        public_key = serialization.load_pem_public_key(pub_path.read_bytes())
        return private_key, public_key

    private_key = rsa.generate_private_key(public_exponent=65537, key_size=CONFIG.rsa_key_size)
    public_key = private_key.public_key()

    pem_bytes = private_key.private_bytes(
        encoding=serialization.Encoding.PEM,
        format=serialization.PrivateFormat.PKCS8,
        encryption_algorithm=serialization.NoEncryption(),
    )
    salt = os.urandom(16)
    key = derive_key_from_password(password, salt)
    nonce = os.urandom(NONCE_SIZE)
    ct = AESGCM(key).encrypt(nonce, pem_bytes, None)

    salt_path.write_bytes(salt)
    priv_path.write_bytes(nonce + ct)
    pub_path.write_bytes(
        public_key.public_bytes(
            encoding=serialization.Encoding.PEM,
            format=serialization.PublicFormat.SubjectPublicKeyInfo,
        )
    )
    # На unix-подобных системах ограничиваем доступ к файлам ключа.
    for p in (priv_path, salt_path):
        try:
            os.chmod(p, 0o600)
        except OSError:
            pass
    return private_key, public_key


def public_key_to_pem(public_key: rsa.RSAPublicKey) -> str:
    return public_key.public_bytes(
        encoding=serialization.Encoding.PEM,
        format=serialization.PublicFormat.SubjectPublicKeyInfo,
    ).decode("ascii")


def public_key_from_pem(pem: str) -> rsa.RSAPublicKey:
    return serialization.load_pem_public_key(pem.encode("ascii"))


def rsa_encrypt(public_key: rsa.RSAPublicKey, data: bytes) -> bytes:
    return public_key.encrypt(
        data,
        padding.OAEP(
            mgf=padding.MGF1(algorithm=hashes.SHA256()),
            algorithm=hashes.SHA256(),
            label=None,
        ),
    )


def rsa_decrypt(private_key: rsa.RSAPrivateKey, data: bytes) -> bytes:
    try:
        return private_key.decrypt(
            data,
            padding.OAEP(
                mgf=padding.MGF1(algorithm=hashes.SHA256()),
                algorithm=hashes.SHA256(),
                label=None,
            ),
        )
    except ValueError as exc:
        raise CryptoError(f"Не удалось расшифровать RSA-payload: {exc}") from exc


# --------------------------------------------------------------------------- #
# AES-GCM: шифрование трафика внутри установленной сессии
# --------------------------------------------------------------------------- #

def generate_session_key() -> bytes:
    return AESGCM.generate_key(bit_length=CONFIG.aes_key_size * 8)


class SessionCipher:
    """Обёртка над AES-GCM для конкретной сессии с одним пиром."""

    def __init__(self, key: bytes):
        self._aead = AESGCM(key)

    def encrypt(self, plaintext: bytes, associated_data: bytes | None = None) -> str:
        """Возвращает base64-независимую hex-строку 'nonce:ciphertext'."""
        nonce = os.urandom(NONCE_SIZE)
        ct = self._aead.encrypt(nonce, plaintext, associated_data)
        return (nonce + ct).hex()

    def decrypt(self, blob_hex: str, associated_data: bytes | None = None) -> bytes:
        try:
            blob = bytes.fromhex(blob_hex)
            nonce, ct = blob[:NONCE_SIZE], blob[NONCE_SIZE:]
            return self._aead.decrypt(nonce, ct, associated_data)
        except Exception as exc:  # noqa: BLE001 - хотим обернуть любую ошибку
            raise CryptoError(f"Не удалось расшифровать сообщение: {exc}") from exc
