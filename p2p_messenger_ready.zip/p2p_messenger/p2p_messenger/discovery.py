"""
Обнаружение пиров в локальной сети через UDP broadcast.

Идея: каждый узел периодически рассылает широковещательный UDP-пакет вида
{"type": "p2p_discovery", "name": ..., "tcp_port": ...} и одновременно
слушает такие же пакеты от других узлов. Получив чужой анонс, узел
регистрирует его в списке "видимых" пиров с TTL — если анонс не обновлялся
дольше discovery_timeout, пир считается offline и удаляется из списка.

Это не требует никакого центрального сервера — обнаружение полностью P2P.
"""

from __future__ import annotations

import json
import socket
import threading
import time
from dataclasses import dataclass
from typing import Callable, Optional

from .config import CONFIG

DISCOVERY_MAGIC = "p2p_messenger_discovery_v1"


@dataclass
class DiscoveredPeer:
    name: str
    address: str
    tcp_port: int
    last_seen: float

    def is_stale(self, timeout: float) -> bool:
        return (time.time() - self.last_seen) > timeout


class PeerDiscovery:
    """
    Фоновый сервис, который рассылает анонсы о себе и слушает анонсы
    других узлов сети. Потокобезопасен: список пиров защищён локом.
    """

    def __init__(
        self,
        my_name: str,
        tcp_port: int,
        on_peer_updated: Optional[Callable[[DiscoveredPeer], None]] = None,
    ):
        self.my_name = my_name
        self.tcp_port = tcp_port
        self.on_peer_updated = on_peer_updated

        self._peers: dict[str, DiscoveredPeer] = {}
        self._lock = threading.Lock()
        self._stop_event = threading.Event()
        self._threads: list[threading.Thread] = []

        self._sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        self._sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        self._sock.setsockopt(socket.SOL_SOCKET, socket.SO_BROADCAST, 1)
        # На некоторых системах позволяет нескольким процессам слушать один порт.
        if hasattr(socket, "SO_REUSEPORT"):
            try:
                self._sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEPORT, 1)
            except OSError:
                pass
        self._sock.bind(("", CONFIG.udp_discovery_port))
        self._sock.settimeout(1.0)

    # --------------------------------------------------------------- #
    # Публичный API
    # --------------------------------------------------------------- #

    def start(self) -> None:
        listener = threading.Thread(target=self._listen_loop, daemon=True, name="discovery-listen")
        announcer = threading.Thread(target=self._announce_loop, daemon=True, name="discovery-announce")
        reaper = threading.Thread(target=self._reap_loop, daemon=True, name="discovery-reap")
        self._threads = [listener, announcer, reaper]
        for t in self._threads:
            t.start()

    def stop(self) -> None:
        self._stop_event.set()
        try:
            self._sock.close()
        except OSError:
            pass

    def get_peers(self) -> list[DiscoveredPeer]:
        with self._lock:
            return list(self._peers.values())

    # --------------------------------------------------------------- #
    # Внутренние потоки
    # --------------------------------------------------------------- #

    def _announce_loop(self) -> None:
        payload = json.dumps(
            {
                "magic": DISCOVERY_MAGIC,
                "type": "announce",
                "name": self.my_name,
                "tcp_port": self.tcp_port,
            }
        ).encode("utf-8")

        while not self._stop_event.is_set():
            try:
                self._sock.sendto(payload, (CONFIG.broadcast_addr, CONFIG.udp_discovery_port))
            except OSError:
                pass  # сеть может быть временно недоступна - не критично
            self._stop_event.wait(CONFIG.discovery_interval_sec)

    def _listen_loop(self) -> None:
        while not self._stop_event.is_set():
            try:
                data, addr = self._sock.recvfrom(4096)
            except socket.timeout:
                continue
            except OSError:
                break
            self._handle_datagram(data, addr[0])

    def _handle_datagram(self, data: bytes, from_addr: str) -> None:
        try:
            msg = json.loads(data.decode("utf-8"))
        except (json.JSONDecodeError, UnicodeDecodeError):
            return
        if msg.get("magic") != DISCOVERY_MAGIC or msg.get("type") != "announce":
            return
        name = msg.get("name")
        tcp_port = msg.get("tcp_port")
        if not name or not tcp_port or name == self.my_name:
            return

        peer = DiscoveredPeer(
            name=name, address=from_addr, tcp_port=int(tcp_port), last_seen=time.time()
        )
        with self._lock:
            self._peers[name] = peer
        if self.on_peer_updated:
            self.on_peer_updated(peer)

    def _reap_loop(self) -> None:
        """Периодически убирает из списка пиров, от которых давно нет вестей."""
        while not self._stop_event.is_set():
            self._stop_event.wait(CONFIG.discovery_interval_sec)
            with self._lock:
                stale = [
                    name
                    for name, p in self._peers.items()
                    if p.is_stale(CONFIG.discovery_timeout_sec * 3)
                ]
                for name in stale:
                    del self._peers[name]
