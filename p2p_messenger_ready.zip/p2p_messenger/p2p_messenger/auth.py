"""
Регистрация и вход по нику и паролю.

Важно: это не просто "экран-заглушка" перед мессенджером. Пароль аккаунта
используется как ключ шифрования приватного RSA-ключа узла (см.
crypto_utils.load_or_create_rsa_keypair) — то есть ник+пароль буквально
и есть криптографическая личность пользователя в сети. Сами пароли нигде
не хранятся: хранится только PBKDF2-хэш с уникальной солью, сверить пароль
можно, а восстановить его из хранилища — нет.
"""

from __future__ import annotations

import hashlib
import json
import os
import re
import threading
import time
from dataclasses import dataclass, asdict

from .config import CONFIG
from .crypto_utils import PBKDF2_ITERATIONS

NICKNAME_RE = re.compile(r"^[A-Za-zА-Яа-яЁё0-9_\-]{3,24}$")
MIN_PASSWORD_LEN = 6


class AuthError(Exception):
    """Ошибка регистрации/входа с сообщением, пригодным для показа пользователю."""


MAX_AVATAR_B64_LEN = 300_000  # ~220 КБ картинки в base64 — достаточно для аватарки, но не раздувает accounts.json
MAX_BIO_LEN = 280


@dataclass
class Account:
    nickname: str
    salt_hex: str
    hash_hex: str
    created_at: float
    tcp_port: int
    bio: str = ""
    avatar: str = ""  # data:image/...;base64,... либо пусто (тогда используются инициалы)


def validate_nickname(nickname: str) -> None:
    if not NICKNAME_RE.match(nickname or ""):
        raise AuthError(
            "Ник должен быть от 3 до 24 символов: буквы, цифры, дефис и подчёркивание."
        )


def validate_password(password: str) -> None:
    if not password or len(password) < MIN_PASSWORD_LEN:
        raise AuthError(f"Пароль должен быть не короче {MIN_PASSWORD_LEN} символов.")


def _hash_password(password: str, salt: bytes) -> str:
    return hashlib.pbkdf2_hmac("sha256", password.encode("utf-8"), salt, PBKDF2_ITERATIONS).hex()


class AccountStore:
    """Файловое хранилище аккаунтов (ник -> хэш пароля) в accounts.json."""

    def __init__(self):
        CONFIG.ensure_dirs()
        self._path = CONFIG.data_dir / "accounts.json"
        self._lock = threading.Lock()
        if not self._path.exists():
            self._write({})

    def _read(self) -> dict:
        if not self._path.exists():
            return {}
        raw = self._path.read_text(encoding="utf-8").strip()
        return json.loads(raw) if raw else {}

    def _write(self, data: dict) -> None:
        self._path.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")
        try:
            os.chmod(self._path, 0o600)
        except OSError:
            pass

    @staticmethod
    def _key(nickname: str) -> str:
        return nickname.strip().lower()

    def exists(self, nickname: str) -> bool:
        with self._lock:
            return self._key(nickname) in self._read()

    def register(self, nickname: str, password: str, tcp_port: int) -> Account:
        validate_nickname(nickname)
        validate_password(password)
        with self._lock:
            data = self._read()
            key = self._key(nickname)
            if key in data:
                raise AuthError(f"Ник '{nickname}' уже занят.")
            salt = os.urandom(16)
            account = Account(
                nickname=nickname,
                salt_hex=salt.hex(),
                hash_hex=_hash_password(password, salt),
                created_at=time.time(),
                tcp_port=tcp_port,
            )
            data[key] = asdict(account)
            self._write(data)
            return account

    def verify(self, nickname: str, password: str) -> Account:
        with self._lock:
            data = self._read()
            entry = data.get(self._key(nickname))
        if entry is None:
            raise AuthError("Такого ника нет. Проверьте написание или зарегистрируйтесь.")
        salt = bytes.fromhex(entry["salt_hex"])
        if _hash_password(password, salt) != entry["hash_hex"]:
            raise AuthError("Неверный пароль.")
        return Account(**entry)

    def get(self, nickname: str) -> Account | None:
        with self._lock:
            entry = self._read().get(self._key(nickname))
        return Account(**entry) if entry else None

    def update_profile(self, nickname: str, bio: str | None = None, avatar: str | None = None) -> Account:
        """Обновляет описание и/или аватарку аккаунта (профиль, не криптоключи)."""
        if bio is not None and len(bio) > MAX_BIO_LEN:
            raise AuthError(f"Описание не должно быть длиннее {MAX_BIO_LEN} символов.")
        if avatar is not None and len(avatar) > MAX_AVATAR_B64_LEN:
            raise AuthError("Изображение слишком большое. Выберите файл поменьше.")
        with self._lock:
            data = self._read()
            key = self._key(nickname)
            entry = data.get(key)
            if entry is None:
                raise AuthError("Аккаунт не найден.")
            if bio is not None:
                entry["bio"] = bio
            if avatar is not None:
                entry["avatar"] = avatar
            data[key] = entry
            self._write(data)
            return Account(**entry)
