"""
Графический интерфейс на tkinter (входит в стандартную библиотеку Python,
дополнительно ставить ничего не нужно).

Запуск: python main.py --name Alice --gui
"""

from __future__ import annotations

import queue
import threading
import tkinter as tk
from tkinter import filedialog, messagebox, simpledialog, ttk

from .discovery import DiscoveredPeer
from .peer import Peer

REFRESH_MS = 500


class MessengerGUI:
    def __init__(self, root: tk.Tk, peer: Peer):
        self.root = root
        self.peer = peer
        self.active_peer: str | None = None

        # Очередь нужна, потому что колбэки Peer вызываются из сетевых
        # потоков, а Tkinter требует, чтобы все обновления UI шли из
        # главного потока. Колбэки просто кладут события в очередь,
        # а _poll_queue() в главном потоке их разбирает.
        self._events: "queue.Queue[tuple]" = queue.Queue()

        peer.on_chat_message = lambda name, text: self._events.put(("chat", name, text))
        peer.on_event = lambda kind, msg: self._events.put(("event", kind, msg))
        peer.on_discovery_update = lambda p: self._events.put(("discovery", p))

        self._build_ui()
        self._poll_queue()

    # ------------------------------------------------------------------ #
    # Построение интерфейса
    # ------------------------------------------------------------------ #

    def _build_ui(self) -> None:
        self.root.title(f"p2p_messenger — {self.peer.name} (порт {self.peer.tcp_port})")
        self.root.geometry("820x520")

        main_pane = ttk.Panedwindow(self.root, orient=tk.HORIZONTAL)
        main_pane.pack(fill=tk.BOTH, expand=True)

        # --- Левая панель: обнаруженные пиры и подключение --------------
        left = ttk.Frame(main_pane, width=220)
        main_pane.add(left, weight=1)

        ttk.Label(left, text="Пиры в сети:").pack(anchor="w", padx=4, pady=(4, 0))
        self.peer_list = tk.Listbox(left)
        self.peer_list.pack(fill=tk.BOTH, expand=True, padx=4, pady=4)
        self.peer_list.bind("<Double-Button-1>", self._on_peer_double_click)

        ttk.Button(left, text="Подключиться вручную...", command=self._manual_connect).pack(
            fill=tk.X, padx=4, pady=2
        )
        ttk.Button(left, text="Обновить сессии", command=self._refresh_sessions).pack(
            fill=tk.X, padx=4, pady=2
        )

        ttk.Label(left, text="Активные сессии:").pack(anchor="w", padx=4, pady=(8, 0))
        self.session_list = tk.Listbox(left, height=6)
        self.session_list.pack(fill=tk.BOTH, padx=4, pady=4)
        self.session_list.bind("<<ListboxSelect>>", self._on_session_select)

        # --- Правая панель: чат ------------------------------------------
        right = ttk.Frame(main_pane)
        main_pane.add(right, weight=3)

        self.chat_label = ttk.Label(right, text="Выберите собеседника", font=("Segoe UI", 11, "bold"))
        self.chat_label.pack(anchor="w", padx=6, pady=4)

        self.chat_box = tk.Text(right, state="disabled", wrap="word")
        self.chat_box.pack(fill=tk.BOTH, expand=True, padx=6, pady=4)

        bottom = ttk.Frame(right)
        bottom.pack(fill=tk.X, padx=6, pady=6)

        self.entry = ttk.Entry(bottom)
        self.entry.pack(side=tk.LEFT, fill=tk.X, expand=True)
        self.entry.bind("<Return>", lambda _e: self._send_current())

        ttk.Button(bottom, text="Отправить", command=self._send_current).pack(side=tk.LEFT, padx=4)
        ttk.Button(bottom, text="Файл...", command=self._send_file_dialog).pack(side=tk.LEFT)

        self.status = ttk.Label(self.root, text="Готов", anchor="w")
        self.status.pack(fill=tk.X, side=tk.BOTTOM)

    # ------------------------------------------------------------------ #
    # Обработка событий из очереди (вызывается таймером в главном потоке)
    # ------------------------------------------------------------------ #

    def _poll_queue(self) -> None:
        try:
            while True:
                event = self._events.get_nowait()
                self._handle_event(event)
        except queue.Empty:
            pass
        self.root.after(REFRESH_MS, self._poll_queue)

    def _handle_event(self, event: tuple) -> None:
        kind = event[0]
        if kind == "chat":
            _, sender, text = event
            self._append_line(sender, f"[{sender}]: {text}")
            if self.active_peer is None:
                self.active_peer = sender
                self.chat_label.config(text=f"Чат с {sender}")
        elif kind == "event":
            _, ev_kind, message = event
            self.status.config(text=f"[{ev_kind}] {message}")
            if ev_kind in ("connect", "disconnect"):
                self._refresh_sessions()
        elif kind == "discovery":
            _, discovered = event
            self._refresh_discovered([discovered])

    # ------------------------------------------------------------------ #
    # Обработчики UI
    # ------------------------------------------------------------------ #

    def _manual_connect(self) -> None:
        address = simpledialog.askstring("Подключение", "Адрес пира (IP):", parent=self.root)
        if not address:
            return
        port_str = simpledialog.askstring("Подключение", "TCP-порт пира:", parent=self.root)
        if not port_str:
            return
        try:
            port = int(port_str)
        except ValueError:
            messagebox.showerror("Ошибка", "Порт должен быть числом")
            return

        def worker() -> None:
            try:
                name = self.peer.connect_to(address, port)
                self._events.put(("event", "connect", f"Подключено к {name}"))
                self.active_peer = name
            except (OSError, TimeoutError) as exc:
                self._events.put(("event", "error", f"Не удалось подключиться: {exc}"))

        threading.Thread(target=worker, daemon=True).start()

    def _on_peer_double_click(self, _evt) -> None:
        selection = self.peer_list.curselection()
        if not selection:
            return
        text = self.peer_list.get(selection[0])
        name = text.split("  ")[0]
        discovered = next((p for p in self.peer.get_discovered_peers() if p.name == name), None)
        if discovered:
            threading.Thread(
                target=self._connect_and_report, args=(discovered.address, discovered.tcp_port), daemon=True
            ).start()

    def _connect_and_report(self, address: str, port: int) -> None:
        try:
            name = self.peer.connect_to(address, port)
            self._events.put(("event", "connect", f"Подключено к {name}"))
        except (OSError, TimeoutError) as exc:
            self._events.put(("event", "error", str(exc)))

    def _refresh_discovered(self, updates: list[DiscoveredPeer]) -> None:
        existing = {self.peer_list.get(i).split("  ")[0] for i in range(self.peer_list.size())}
        for p in updates:
            if p.name not in existing:
                self.peer_list.insert(tk.END, f"{p.name}  ({p.address}:{p.tcp_port})")

    def _refresh_sessions(self) -> None:
        self.session_list.delete(0, tk.END)
        for name in self.peer.get_active_sessions():
            self.session_list.insert(tk.END, name)

    def _on_session_select(self, _evt) -> None:
        selection = self.session_list.curselection()
        if not selection:
            return
        name = self.session_list.get(selection[0])
        self.active_peer = name
        self.chat_label.config(text=f"Чат с {name}")
        self._load_history(name)

    def _load_history(self, name: str) -> None:
        self.chat_box.configure(state="normal")
        self.chat_box.delete("1.0", tk.END)
        for rec in self.peer.history.read_all(name):
            prefix = "Вы" if rec["direction"] == "out" else name
            self.chat_box.insert(tk.END, f"{prefix}: {rec['text']}\n")
        self.chat_box.configure(state="disabled")
        self.chat_box.see(tk.END)

    def _append_line(self, peer_name: str, line: str) -> None:
        if self.active_peer != peer_name:
            return
        self.chat_box.configure(state="normal")
        self.chat_box.insert(tk.END, line + "\n")
        self.chat_box.configure(state="disabled")
        self.chat_box.see(tk.END)

    def _send_current(self) -> None:
        text = self.entry.get().strip()
        if not text:
            return
        if not self.active_peer:
            messagebox.showinfo("Нет собеседника", "Сначала подключитесь к пиру или выберите сессию.")
            return
        try:
            self.peer.send_chat(self.active_peer, text)
            self._append_line(self.active_peer, f"Вы: {text}")
            self.entry.delete(0, tk.END)
        except ConnectionError as exc:
            messagebox.showerror("Ошибка отправки", str(exc))

    def _send_file_dialog(self) -> None:
        if not self.active_peer:
            messagebox.showinfo("Нет собеседника", "Сначала подключитесь к пиру.")
            return
        path = filedialog.askopenfilename()
        if not path:
            return

        def worker() -> None:
            try:
                self.peer.send_file(self.active_peer, path)
            except (ConnectionError, FileNotFoundError) as exc:
                self._events.put(("event", "error", str(exc)))

        threading.Thread(target=worker, daemon=True).start()


def run_gui(peer: Peer) -> None:
    root = tk.Tk()
    MessengerGUI(root, peer)
    root.mainloop()
