[app]

# (str) Title of your application
title = WIRE P2P Messenger

# (str) Package name
package.name = wirep2p

# (str) Package domain (needed for android/ios packaging)
package.domain = org.wire.p2p

# (str) Source code where the main.py lives
source.dir = .

# (list) Source files to include (let empty to include all the files)
source.include_exts = py,png,jpg,kv,atlas,html,css,js,ico,svg

# (str) Application versioning
version = 1.0

# (list) Application requirements
# flask тянет за собой werkzeug/jinja2/markupsafe/itsdangerous/click/blinker —
# перечислены явно, чтобы сборка не зависела от резолвера версий p4a.
requirements = python3,flask,werkzeug,jinja2,markupsafe,itsdangerous,click,blinker,cryptography

# (str) Presplash / icon — положите свои файлы рядом с buildozer.spec и раскомментируйте:
#icon.filename = %(source.dir)s/icon.png
#presplash.filename = %(source.dir)s/presplash.png

# (list) Permissions
# INTERNET/ACCESS_NETWORK_STATE/ACCESS_WIFI_STATE — для локального веб-сервера
# (WebView -> 127.0.0.1) и обычного TCP; CHANGE_WIFI_MULTICAST_STATE — чтобы
# UDP-широковещательное автообнаружение узлов надёжно работало в Wi-Fi сетях.
android.permissions = INTERNET,ACCESS_NETWORK_STATE,ACCESS_WIFI_STATE,CHANGE_WIFI_MULTICAST_STATE

# (int) Target Android API, минимум и архитектуры
android.api = 34
android.minapi = 24
android.archs = arm64-v8a,armeabi-v7a

# (str) Жёстко фиксируем build-tools: последние версии, которые ставит
# sdkmanager по умолчанию, иногда не содержат бинарник aidl для Linux —
# p4a падает с "Aidl не найден". 34.0.0 — версия, для которой это надёжно
# работает.
android.build_tools_version = 34.0.0

# (bool) Разрешить обычный (нешифрованный) локальный HTTP-трафик на 127.0.0.1
# начиная с Android 9 (API 28) это по умолчанию запрещено для внешних хостов,
# но обязательно для loopback-адреса, на котором висит наш Flask-сервер.
android.allow_backup = True

# (str) Какой "бутстрап" p4a использовать — webview рисует единственный экран
# с системным WebView, указывающим на локальный Flask-сервер. Именно это
# нужно для приложения, у которого весь UI — это HTML/CSS/JS в static/templates.
p4a.bootstrap = webview

# (int) Порт на localhost, который откроет WebView. ДОЛЖЕН совпадать с
# P2P_WEB_PORT, который main.py выставляет для Android (см. main.py).
p4a.port = 8765

[buildozer]

# (int) Log level (0 = только ошибки, 1 = инфо, 2 = подробно)
log_level = 2

# (int) Спрашивать подтверждение перед выполнением опасных команд
warn_on_root = 1
