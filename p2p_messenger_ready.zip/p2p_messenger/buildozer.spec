[app]

# (str) Title of your application
title = WIRE P2P Messenger

# (str) Package name
package.name = wirep2p

# (str) Package domain (needed for android/ios packaging)
package.domain = org.wire.p2p

# (str) Source code where the main.py lives
source.dir = .

# (list) Source files to include (let empty to include all the files)
source.include_exts = py,png,jpg,kv,atlas,html,css,js,ico,svg

# (str) Application versioning
version = 1.0

# (list) Application requirements
# flask тянет за собой werkzeug/jinja2/markupsafe/itsdangerous/click/blinker —
# перечислены явно, чтобы сборка не зависела от резолвера версий p4a.
# ВАЖНО: cryptography ЖЁСТКО закреплён на 3.3.2 — это последняя версия ДО
# перехода cryptography на Rust (maturin). Начиная с 3.5+ для сборки нужен
# Rust-кросс-тулчейн под Android, которого в p4a v2024.01.21 нет "из коробки"
# (Rust-рецепты появились в p4a позже) — попытка собрать современную
# cryptography здесь падает с "Backend subprocess exited when trying to
# invoke build_wheel" (это как раз maturin). 3.3.2 собирается через
# cffi + уже готовые в p4a рецепты openssl/libffi, без Rust — поэтому именно
# эта версия и указана.
requirements = python3,flask,werkzeug,jinja2,markupsafe,itsdangerous,click,blinker,cryptography==3.3.2

# (str) Presplash / icon — положите свои файлы рядом с buildozer.spec и раскомментируйте:
#icon.filename = %(source.dir)s/icon.png
#presplash.filename = %(source.dir)s/presplash.png

# (list) Permissions
# INTERNET/ACCESS_NETWORK_STATE/ACCESS_WIFI_STATE — для локального веб-сервера
# (WebView -> 127.0.0.1) и обычного TCP; CHANGE_WIFI_MULTICAST_STATE — чтобы
# UDP-широковещательное автообнаружение узлов надёжно работало в Wi-Fi сетях.
android.permissions = INTERNET,ACCESS_NETWORK_STATE,ACCESS_WIFI_STATE,CHANGE_WIFI_MULTICAST_STATE

# (int) Target Android API, минимум и архитектуры
# ВАЖНО: buildozer 1.5.0 по умолчанию тянет свой собственный NDK r25b,
# который поддерживает максимум android-33 (см. ошибку сборки:
# "Android NDK: android-34 is above the maximum supported version
# android-33. ... Aborting"). Поэтому android.api должен быть <= 33,
# пока явно не задана более новая android.ndk (например 25c/26+).
android.api = 33
android.minapi = 24
android.archs = arm64-v8a,armeabi-v7a

# (str) Жёстко фиксируем build-tools: последние версии, которые ставит
# sdkmanager по умолчанию, иногда не содержат бинарник aidl для Linux —
# p4a падает с "Aidl не найден". 34.0.0 — версия, для которой это надёжно
# работает.
android.build_tools_version = 34.0.0

# (bool) Автоматически принимать лицензии Android SDK. Без этого sdkmanager
# в неинтерактивном режиме (CI) пропускает установку пакетов (в т.ч.
# build-tools), из-за чего затем "не находится" aidl — хотя дело не в aidl,
# а в том, что сам build-tools не был установлен.
android.accept_sdk_license = True

# (bool) Разрешает Android делать авто-бэкап данных приложения (Auto Backup,
# API >=23). К cleartext-трафику эта настройка отношения НЕ имеет (это было
# ошибкой в предыдущей версии файла) — просто стандартная опция buildozer.
android.allow_backup = True

# (bool) Разрешить обычный (нешифрованный) HTTP-трафик на 127.0.0.1.
# Начиная с Android 9 (API 28) это запрещено ПО УМОЛЧАНИЮ, включая соединения
# WebView -> loopback, а мы билдим под android.api = 34 — без этой настройки
# встроенный WebView покажет пустой экран / net::ERR_CLEARTEXT_NOT_PERMITTED
# при попытке открыть http://127.0.0.1:8765. Правильный способ в buildozer —
# добавить атрибут android:usesCleartextTraffic="true" на тег <application>
# через android.extra_manifest_application_arguments (см. файл ниже).
android.extra_manifest_application_arguments = %(source.dir)s/android/extra_manifest_application_arguments.xml

# (str) Какой "бутстрап" p4a использовать — webview рисует единственный экран
# с системным WebView, указывающим на локальный Flask-сервер. Именно это
# нужно для приложения, у которого весь UI — это HTML/CSS/JS в static/templates.
p4a.bootstrap = webview

# (str) Жёстко фиксируем python-for-android на v2024.01.21 через git-тег.
# ЭТО ОБЯЗАТЕЛЬНО: без явного p4a.branch buildozer игнорирует версию,
# поставленную через pip в CI (даже если она там прописана), и сам тянет
# свежую/dev-версию p4a — с Python 3.14, NDK r28c и Rust-рецептами. Старая
# cryptography==3.3.2 (собирается через cffi, без Rust — см. requirements
# выше) не совместима с таким окружением и падает на компиляции _openssl.c.
# Тег v2024.01.21 — последний официальный релиз, использующий Python 3.11
# и NDK, под который и рассчитан весь остальной конфиг ниже.
p4a.branch = v2024.01.21

# (int) Порт на localhost, который откроет WebView. ДОЛЖЕН совпадать с
# P2P_WEB_PORT, который main.py выставляет для Android (см. main.py).
p4a.port = 8765

[buildozer]

# (int) Log level (0 = только ошибки, 1 = инфо, 2 = подробно)
log_level = 2

# (int) Спрашивать подтверждение перед выполнением опасных команд
warn_on_root = 1
