[app]

# (str) Title of your application
title = WIRE P2P Messenger

# (str) Package name
package.name = wirep2p

# (str) Package domain (needed for android/ios packaging)
package.domain = org.wire.p2p

# (str) Source code where the main.py lives
source.dir = .

# (list) Source files to include (let empty to include all the files)
source.include_exts = py,png,jpg,kv,atlas,html,css,js,ico,svg

# (str) Application versioning
version = 1.0

# (list) Application requirements
# Интерфейс теперь нативный, на Kivy (см. p2p_messenger/kivy_ui.py) —
# flask/werkzeug/jinja2 и т.п. больше не нужны, WebView не используется.
# plyer — для выбора файла (кнопка "прикрепить" в чате).
# ВАЖНО про cryptography: версия НЕ закреплена (было cryptography==3.3.2).
# Жёсткий пин на 3.3.2 ломал сборку под NDK r25b ошибкой
# "ld: error: unable to find library -lpthread": когда версия в requirements
# указана явно, p4a собирает ИМЕННО её через голый setup.py пакета
# cryptography, а его старый (до-Rust) build_openssl.py безусловно
# добавляет "-lpthread" в команду линковки. NDK r23+ больше не содержит
# отдельной libpthread.so/.a (функциональность слита в libc), поэтому
# линковка падает. Без явной версии p4a использует свой собственный
# recipe cryptography (pythonforandroid/recipes/cryptography) — он собирает
# через cffi + уже готовые в p4a рецепты openssl/libffi, без Rust и без
# лишнего -lpthread. Это штатный, поддерживаемый p4a способ сборки
# cryptography под Android.
requirements = python3,kivy,plyer,cryptography

# (str) Presplash / icon — файл icon.png должен лежать рядом с buildozer.spec.
icon.filename = %(source.dir)s/icon.png
#presplash.filename = %(source.dir)s/presplash.png

# (list) Permissions
# INTERNET/ACCESS_NETWORK_STATE/ACCESS_WIFI_STATE — для обычного TCP-обмена
# сообщениями; CHANGE_WIFI_MULTICAST_STATE — чтобы UDP-широковещательное
# автообнаружение узлов надёжно работало в Wi-Fi сетях.
android.permissions = INTERNET,ACCESS_NETWORK_STATE,ACCESS_WIFI_STATE,CHANGE_WIFI_MULTICAST_STATE

# (int) Target Android API, минимум и архитектуры
# ВАЖНО: buildozer 1.5.0 по умолчанию тянет свой собственный NDK r25b,
# который поддерживает максимум android-33 (см. ошибку сборки:
# "Android NDK: android-34 is above the maximum supported version
# android-33. ... Aborting"). Поэтому android.api должен быть <= 33,
# пока явно не задана более новая android.ndk (например 25c/26+).
android.api = 33
android.minapi = 24
android.archs = arm64-v8a,armeabi-v7a

# (str) Жёстко фиксируем build-tools: последние версии, которые ставит
# sdkmanager по умолчанию, иногда не содержат бинарник aidl для Linux —
# p4a падает с "Aidl не найден". 34.0.0 — версия, для которой это надёжно
# работает.
android.build_tools_version = 34.0.0

# (bool) Автоматически принимать лицензии Android SDK. Без этого sdkmanager
# в неинтерактивном режиме (CI) пропускает установку пакетов (в т.ч.
# build-tools), из-за чего затем "не находится" aidl — хотя дело не в aidl,
# а в том, что сам build-tools не был установлен.
android.accept_sdk_license = True

# (bool) Разрешает Android делать авто-бэкап данных приложения (Auto Backup,
# API >=23). К cleartext-трафику эта настройка отношения НЕ имеет (это было
# ошибкой в предыдущей версии файла) — просто стандартная опция buildozer.
android.allow_backup = True

# (str) Жёстко фиксируем python-for-android на v2024.01.21 через git-тег.
# ЭТО ОБЯЗАТЕЛЬНО: без явного p4a.branch buildozer игнорирует версию,
# поставленную через pip в CI (даже если она там прописана), и сам тянет
# свежую/dev-версию p4a — с Python 3.14, NDK r28c и Rust-рецептами. Старая
# cryptography==3.3.2 (собирается через cffi, без Rust — см. requirements
# выше) не совместима с таким окружением и падает на компиляции _openssl.c.
# Тег v2024.01.21 — последний официальный релиз, использующий Python 3.11
# и NDK, под который и рассчитан весь остальной конфиг ниже.
p4a.branch = v2024.01.21

# (str) Бутстрап по умолчанию (sdl2) — то, что нужно нативному Kivy-интерфейсу.
# Явно не указываем, buildozer сам подставит sdl2, когда requirements
# содержит kivy.

[buildozer]

# (int) Log level (0 = только ошибки, 1 = инфо, 2 = подробно)
log_level = 2

# (int) Спрашивать подтверждение перед выполнением опасных команд
warn_on_root = 1
