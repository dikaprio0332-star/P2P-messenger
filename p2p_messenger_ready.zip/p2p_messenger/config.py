"""
Централизованная конфигурация приложения.

Все "магические числа" и настройки собраны здесь, чтобы при рефакторинге
не искать их по всему коду.
"""

from __future__ import annotations

import os
from dataclasses import dataclass, field
from pathlib import Path


@dataclass(frozen=True)
class Config:
    # --- Сеть -----------------------------------------------------------
    tcp_port: int = int(os.environ.get("P2P_TCP_PORT", 5100))
    udp_discovery_port: int = int(os.environ.get("P2P_UDP_PORT", 5101))
    broadcast_addr: str = "255.255.255.255"
    discovery_interval_sec: float = 5.0
    discovery_timeout_sec: float = 2.0
    socket_buffer_size: int = 65536
    connect_timeout_sec: float = 5.0
    max_message_size: int = 10 * 1024 * 1024  # 10 MB защита от DoS

    # --- Криптография -----------------------------------------------------
    rsa_key_size: int = 2048
    aes_key_size: int = 32  # AES-256

    # --- Хранилище --------------------------------------------------------
    # На Android (сборка buildozer/p4a) ANDROID_PRIVATE указывает на приватную
    # директорию приложения — только туда гарантированно можно писать без
    # дополнительных разрешений на хранилище. На десктопе/Pydroid 3 просто
    # используем домашнюю папку пользователя, как раньше.
    data_dir: Path = field(
        default_factory=lambda: (
            Path(os.environ["ANDROID_PRIVATE"]) / ".p2p_messenger"
            if os.environ.get("ANDROID_PRIVATE")
            else Path.home() / ".p2p_messenger"
        )
    )

    @property
    def keys_dir(self) -> Path:
        return self.data_dir / "keys"

    @property
    def history_dir(self) -> Path:
        return self.data_dir / "history"

    @property
    def contacts_file(self) -> Path:
        return self.data_dir / "contacts.json"

    def ensure_dirs(self) -> None:
        self.data_dir.mkdir(parents=True, exist_ok=True)
        self.keys_dir.mkdir(parents=True, exist_ok=True)
        self.history_dir.mkdir(parents=True, exist_ok=True)


CONFIG = Config()
