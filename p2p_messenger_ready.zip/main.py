#!/usr/bin/env python3
"""
Точка входа в приложение.

Примеры запуска:

    python main.py --web              # веб-интерфейс (рекомендуется)
    python main.py --name Alice        # консольный интерфейс

При первом запуске введите ник и пароль — это и есть регистрация:
пароль защищает ваш приватный ключ на диске, второй раз вводить его
не нужно только на этом же устройстве и с этим же паролем.

Два узла в одной локальной сети автоматически найдут друг друга через
UDP-обнаружение (см. p2p_messenger/discovery.py). Также можно подключиться
вручную по IP:порту — командой /connect в CLI, кнопкой в веб-интерфейсе.
"""

import os
import sys

# На Android (сборка через buildozer/python-for-android, бутстрап "webview")
# у процесса всегда есть переменная окружения ANDROID_ARGUMENT, которую
# ставит сам p4a. В этом случае никаких сторонних GUI-тулкитов — поднимаем
# тот же Flask-сервер, что используется в десктопном "python main.py --web",
# прямо на телефоне (127.0.0.1:5000), а показывает его системная WebView
# бутстрапа "webview" (см. buildozer.spec: p4a.bootstrap = webview).
# Сервер реально работает НА устройстве — это тот самый "каждый человек это
# сервер": никакого стороннего хостинга, только локальный процесс на телефоне.
if "ANDROID_ARGUMENT" in os.environ:
    from p2p_messenger.webapp import run_android_webapp

    sys.exit(run_android_webapp())

_MISSING_DEP_HELP = """
Не найден пакет '{module}'.

В Pydroid 3 поставьте зависимости через встроенный менеджер пакетов
(значок "Pip" в боковом меню, не через обычный терминал Android):

    cryptography
    flask

Либо выполните в консоли Pydroid 3 (вкладка "Terminal" внутри самого
приложения Pydroid 3, значок консоли, а НЕ системный терминал Android):

    pip install cryptography flask

После установки запустите main.py ещё раз (кнопка ▶ Run).
""".strip()

try:
    from p2p_messenger.cli import main
except ImportError as exc:
    missing = (exc.name or str(exc)).split(".")[0]
    print(_MISSING_DEP_HELP.format(module=missing))
    sys.exit(1)

if __name__ == "__main__":
    sys.exit(main())
