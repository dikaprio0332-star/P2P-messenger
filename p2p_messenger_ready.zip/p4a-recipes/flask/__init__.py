# -*- coding: utf-8 -*-
"""
Локальный recipe "flask", переопределяющий встроенный (сломанный) recipe
python-for-android v2024.01.21 (см. p4a.local_recipes в buildozer.spec —
recipe с тем же именем в этой папке имеет приоритет над встроенным).

ПРОБЛЕМА ВСТРОЕННОГО RECIPE:
Встроенный pythonforandroid/recipes/flask — это обычный PythonRecipe,
который просто запускает "setup.py install" на скачанном исходнике.
Начиная с Flask 2.3/3.0 пакет собирается только через pyproject.toml
(flit_core), и setup.py в исходниках/архиве больше нет вообще — отсюда
падение сборки с "can't open file '.../flask/setup.py': No such file
or directory".

РЕШЕНИЕ:
Flask — чистый Python (компилируемых компонентов нет), поэтому нет
никакой необходимости в "родном" сборочном бэкенде flit_core. Recipe
ниже качает исходники Flask с GitHub по тегу версии (стабильный,
предсказуемый URL — в отличие от pythonhosted.org, где путь к sdist
содержит непредсказуемый хэш) и перед сборкой сам дописывает в них
минимальный setup.py, которого не хватает. Дальше всё идёт как в любом
другом классическом PythonRecipe: "setup.py install" в hostpython.

ВАЖНО: синтетический setup.py собран ТОЛЬКО на stdlib (distutils +
os.walk вместо setuptools.setup/find_packages). hostpython3 — это
отдельный, минимальный python, которым p4a запускает setup.py-скрипты
рецептов внутри сборки, и setuptools в нём не установлен (только
стандартная библиотека) — "from setuptools import ..." там падает с
"ModuleNotFoundError: No module named 'setuptools'". distutils же —
часть stdlib и в Python 3.11 (используется здесь) ещё присутствует.

Репозиторий Flask использует src-layout (исходники лежат в src/flask/,
а не flask/ в корне) — это учтено в package_dir/packages ниже.

Рантайм-зависимости Flask (werkzeug, jinja2, click, itsdangerous,
markupsafe, blinker) сюда намеренно НЕ включены (install_requires
distutils не поддерживает, но нам это и не нужно) — они перечислены
отдельно в requirements= buildozer.spec и ставятся p4a обычным pip'ом
(у них самих нет своего recipe и с ними всё в порядке).
"""

from os.path import join, exists

from pythonforandroid.recipe import PythonRecipe


class FlaskRecipe(PythonRecipe):
    # Держите в синхроне с версией flask в requirements (buildozer.spec).
    version = '3.0.3'
    url = 'https://github.com/pallets/flask/archive/refs/tags/{version}.tar.gz'
    site_packages_name = 'flask'
    call_hostpython_via_targetpython = False

    def prebuild_arch(self, arch):
        super().prebuild_arch(arch)
        build_dir = self.get_build_dir(arch.arch)
        setup_py = join(build_dir, 'setup.py')
        if exists(setup_py):
            # На случай если апстрим когда-нибудь вернёт setup.py сам —
            # тогда наш синтетический не нужен, используем родной.
            return
        with open(setup_py, 'w') as f:
            f.write(
                "# Автосгенерировано p4a-recipes/flask/__init__.py — специально\n"
                "# без setuptools (см. комментарий в __init__.py этого recipe):\n"
                "# hostpython3, которым p4a запускает этот файл, содержит только\n"
                "# стандартную библиотеку.\n"
                "import os\n"
                "from distutils.core import setup\n"
                "\n"
                "\n"
                "def find_packages(src_dir, top):\n"
                "    packages = []\n"
                "    base = os.path.join(src_dir, top)\n"
                "    for root, _dirs, files in os.walk(base):\n"
                "        if '__init__.py' not in files:\n"
                "            continue\n"
                "        rel = os.path.relpath(root, src_dir)\n"
                "        packages.append(rel.replace(os.sep, '.'))\n"
                "    return packages\n"
                "\n"
                "\n"
                "setup(\n"
                "    name='flask',\n"
                "    version={version!r},\n"
                "    package_dir={{'': 'src'}},\n"
                "    packages=find_packages('src', 'flask'),\n"
                ")\n".format(version=self.version)
            )


recipe = FlaskRecipe()
