[app]

# (str) Title of your application
title = WIRE P2P Messenger

# (str) Package name
package.name = wirep2p

# (str) Package domain (needed for android/ios packaging)
package.domain = org.wire.p2p

# (str) Source code where the main.py lives
source.dir = .

# (list) Source files to include (let empty to include all the files)
# "kv" сюда не входит осознанно: Kivy-разметки в проекте нет, интерфейс
# полностью веб-based (html/css/js), см. p4a.bootstrap = webview ниже.
source.include_exts = py,png,jpg,html,css,js,ico,svg

# (str) Application versioning
version = 1.0

# (list) Application requirements
# ИНТЕРФЕЙС ПЕРЕДЕЛАН: больше НЕ Kivy и НЕ tkinter. Теперь на телефоне
# реально запускается локальный Flask-сервер (127.0.0.1:5000, см.
# p2p_messenger/webapp.py: run_android_webapp() и main.py) — тот же самый
# веб-интерфейс, что и в десктопном "python main.py --web". Показывает его
# системная Android WebView через бутстрап p4a "webview" (см. p4a.bootstrap
# ниже) — без сторонних GUI-тулкитов вообще, только HTML/CSS/JS.
# ВАЖНО про cryptography: версия НЕ закреплена (было cryptography==3.3.2).
# Жёсткий пин на 3.3.2 ломал сборку под NDK r25b ошибкой
# "ld: error: unable to find library -lpthread": когда версия в requirements
# указана явно, p4a собирает ИМЕННО её через голый setup.py пакета
# cryptography, а его старый (до-Rust) build_openssl.py безусловно
# добавляет "-lpthread" в команду линковки. NDK r23+ больше не содержит
# отдельной libpthread.so/.a (функциональность слита в libc), поэтому
# линковка падает. Без явной версии p4a использует свой собственный
# recipe cryptography (pythonforandroid/recipes/cryptography) — он собирает
# через cffi + уже готовые в p4a рецепты openssl/libffi, без Rust и без
# лишнего -lpthread. Это штатный, поддерживаемый p4a способ сборки
# cryptography под Android.
requirements = python3,flask,cryptography

# (str) Presplash / icon — файл icon.png должен лежать рядом с buildozer.spec.
icon.filename = %(source.dir)s/icon.png
#presplash.filename = %(source.dir)s/presplash.png

# (list) Permissions
# INTERNET/ACCESS_NETWORK_STATE/ACCESS_WIFI_STATE — для обычного TCP-обмена
# сообщениями (в т.ч. локального Flask-сервера, который WebView открывает
# по 127.0.0.1) и для UDP-обнаружения; CHANGE_WIFI_MULTICAST_STATE — чтобы
# UDP-широковещательное автообнаружение узлов надёжно работало в Wi-Fi сетях.
android.permissions = INTERNET,ACCESS_NETWORK_STATE,ACCESS_WIFI_STATE,CHANGE_WIFI_MULTICAST_STATE

# (int) Target Android API, минимум и архитектуры
# ВАЖНО: buildozer 1.5.0 по умолчанию тянет свой собственный NDK r25b,
# который поддерживает максимум android-33 (см. ошибку сборки:
# "Android NDK: android-34 is above the maximum supported version
# android-33. ... Aborting"). Поэтому android.api должен быть <= 33,
# пока явно не задана более новая android.ndk (например 25c/26+).
android.api = 33
android.minapi = 24
android.archs = arm64-v8a,armeabi-v7a

# (str) Ориентация экрана — жёстко вертикальная (portrait). Приложение не
# поворачивается в горизонтальную ориентацию даже при повороте устройства.
orientation = portrait
android.orientation = portrait
fullscreen = 0

# (str) Жёстко фиксируем build-tools: последние версии, которые ставит
# sdkmanager по умолчанию, иногда не содержат бинарник aidl для Linux —
# p4a падает с "Aidl не найден". 34.0.0 — версия, для которой это надёжно
# работает.
android.build_tools_version = 34.0.0

# (bool) Автоматически принимать лицензии Android SDK. Без этого sdkmanager
# в неинтерактивном режиме (CI) пропускает установку пакетов (в т.ч.
# build-tools), из-за чего затем "не находится" aidl — хотя дело не в aidl,
# а в том, что сам build-tools не был установлен.
android.accept_sdk_license = True

# (bool) Разрешает Android делать авто-бэкап данных приложения (Auto Backup,
# API >=23). К cleartext-трафику эта настройка отношения НЕ имеет (это было
# ошибкой в предыдущей версии файла) — просто стандартная опция buildozer.
android.allow_backup = True

# (str) Добавляет android:usesCleartextTraffic="true" внутрь тега <application>
# AndroidManifest.xml (через android/extra_manifest_application_arguments.xml).
# ОБЯЗАТЕЛЬНО для этого приложения: начиная с Android 9 (API 28) cleartext
# HTTP-трафик заблокирован по умолчанию для ЛЮБОГО хоста, включая 127.0.0.1 —
# WebView-бутстрап открывает как раз http://127.0.0.1:5000 (см. webapp.py:
# run_android_webapp), поэтому без этой строки WebView получает
# "CLEARTEXT communication to 127.0.0.1 not permitted" и приложение либо
# зависает на белом/loading-экране, либо падает при первой попытке WebView
# показать страницу — именно это и был баг "приложение не запускается" на
# реальных телефонах (в отличие от сборки, которая всегда проходит успешно,
# т.к. это чисто рантайм-ограничение Android, а не ошибка компиляции).
android.extra_manifest_application_arguments = %(source.dir)s/android/extra_manifest_application_arguments.xml

# (str) Жёстко фиксируем python-for-android на v2024.01.21 через git-тег.
# ЭТО ОБЯЗАТЕЛЬНО: без явного p4a.branch buildozer игнорирует версию,
# поставленную через pip в CI (даже если она там прописана), и сам тянет
# свежую/dev-версию p4a — с Python 3.14, NDK r28c и Rust-рецептами. Старая
# cryptography==3.3.2 (собирается через cffi, без Rust — см. requirements
# выше) не совместима с таким окружением и падает на компиляции _openssl.c.
# Тег v2024.01.21 — последний официальный релиз, использующий Python 3.11
# и NDK, под который и рассчитан весь остальной конфиг ниже.
p4a.branch = v2024.01.21

# (str) Бутстрап "webview" — вместо "sdl2" (который требовался Kivy).
# Никакого Kivy/pygame/SDL2 в APK больше нет: p4a поднимает нативную
# Android-активность с системной WebView, которая просто открывает адрес,
# заданный в p2p_messenger/webapp.py (http://127.0.0.1:5000, куда сам же
# Python-процесс приложения и подаёт Flask-сервер). Если после сборки
# WebView остаётся пустой/белой — почти наверняка порт в webapp.py
# (run_android_webapp) разошёлся с портом, который эта версия бутстрапа
# webview ожидает по умолчанию: тогда нужно свериться с исходником
# pythonforandroid/bootstraps/webview из тега v2024.01.21 и поправить порт
# в обоих местах на совпадающий.
p4a.bootstrap = webview

[buildozer]

# (int) Log level (0 = только ошибки, 1 = инфо, 2 = подробно)
log_level = 2

# (int) Спрашивать подтверждение перед выполнением опасных команд
warn_on_root = 1
